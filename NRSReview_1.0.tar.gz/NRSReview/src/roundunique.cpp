#include <Rcpp.h>
using namespace Rcpp;
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */

IntegerVector roundunique1Cpp(NumericVector unilist1, int dimension, int size) {
  NumericVector unilist2 = unilist1 * (size - 1);
  IntegerVector roundedlist1(unilist2.size());

  for (int i = 0; i < unilist2.size(); ++i) {
    roundedlist1[i] = std::round(unilist2[i]) + 1;
  }

  IntegerVector unique_vals = IntegerVector::create(roundedlist1[0]);
  for (int i = 1; i < roundedlist1.size(); ++i) {
    if (roundedlist1[i] != unique_vals[unique_vals.size() - 1]) {
      unique_vals.push_back(roundedlist1[i]);
    }
  }

  if (unique_vals.length() < dimension) {
    return IntegerVector(dimension, 0);
  } else if (unique_vals.length() > dimension) {
    return IntegerVector::create(0);
  } else {
    return unique_vals;
  }
}
// [[Rcpp::export]]
NumericMatrix batchapply1Cpp(NumericMatrix quni1, int dimension, int size) {
  int nrow = quni1.nrow();
  int ncol = quni1.ncol();
  NumericMatrix res(nrow, ncol);
  for (int i = 0; i < nrow; i++) {
    res(i, _) = roundunique1Cpp(quni1(i, _), dimension, size);
  }
  return res;
}
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */
