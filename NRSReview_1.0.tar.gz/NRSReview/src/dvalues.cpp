#include <Rcpp.h>
using namespace Rcpp;

double interpolate(double kurt1, double infn2, double supn2, double d1, double d2) {
  if (supn2 == infn2) {
    return d1;
  } else {
    return ((d2 - d1) * ((kurt1 - infn2) / (supn2 - infn2))) + d1;
  }
}

// [[Rcpp::export]]
double d_adjust_kurt(int size, int dtype, double kurt1, DataFrame dlist, int etype) {
  NumericVector sizes = dlist[0];
  NumericVector dtypes = dlist[1];
  NumericVector kurtx = dlist[2];
  NumericVector skewx = dlist[3];
  NumericVector etype_column = dlist[etype - 1];
  
  int nrows = dlist.nrows();
  std::vector<int> indices;
  for (int i = 0; i < nrows; ++i) {
    if (dtypes[i] == dtype) {
      indices.push_back(i);
    }
  }
  
  double result1 = 0.0;
  
  if (std::find(sizes.begin(), sizes.end(), size) != sizes.end()) {
    bool found = false;
    for (int i : indices) {
      if (sizes[i] == size && kurtx[i] == kurt1) {
        result1 = etype_column[i];
        found = true;
        break;
      }
    }
    
    if (!found) {
      double infn2 = -std::numeric_limits<double>::infinity();
      double supn2 = std::numeric_limits<double>::infinity();
      double d1 = 0.0;
      double d2 = 0.0;
      for (int i : indices) {
        if (sizes[i] == size) {
          if (kurtx[i] < kurt1) {
            infn2 = std::max(infn2, kurtx[i]);
          } else {
            supn2 = std::min(supn2, kurtx[i]);
          }
        }
      }
      
      if (infn2 == -std::numeric_limits<double>::infinity()) {
        infn2 = *std::min_element(kurtx.begin(), kurtx.end());
      }
      
      if (supn2 == std::numeric_limits<double>::infinity()) {
        supn2 = *std::max_element(kurtx.begin(), kurtx.end());
      }
      
      for (int i : indices) {
        if (sizes[i] == size && kurtx[i] == infn2) {
          d1 = etype_column[i];
        }
        if (sizes[i] == size && kurtx[i] == supn2) {
          d2 = etype_column[i];
        }
      }
      
      result1 = interpolate(kurt1, infn2, supn2, d1, d2);
    }
  } else {
    double infn = -std::numeric_limits<double>::infinity();
    double supn = std::numeric_limits<double>::infinity();
    double da = 0.0;
    double db = 0.0;
    
    for (int i : indices) {
      if (sizes[i] < size) {
        infn = std::max(infn, sizes[i]);
      } else {
        supn = std::min(supn, sizes[i]);
      }
    }
    
    if (infn == -std::numeric_limits<double>::infinity()) {
      infn = *std::min_element(sizes.begin(), sizes.end());
    }
    
    if (supn == std::numeric_limits<double>::infinity()) {
      supn = *std::max_element(sizes.begin(), sizes.end());
    }
    
    for (int i : indices) {
      if (sizes[i] == infn || sizes[i] == supn){
        double infn2 = -std::numeric_limits<double>::infinity();
        double supn2 = std::numeric_limits<double>::infinity();
        double d1 = 0.0;
        double d2 = 0.0;
        
        for (int j : indices) {
          if (sizes[j] == sizes[i]) {
            if (kurtx[j] < kurt1) {
              infn2 = std::max(infn2, kurtx[j]);
            } else {
              supn2 = std::min(supn2, kurtx[j]);
            }
          }
        }
        
        if (infn2 == -std::numeric_limits<double>::infinity()) {
          infn2 = *std::min_element(kurtx.begin(), kurtx.end());
        }
        
        if (supn2 == std::numeric_limits<double>::infinity()) {
          supn2 = *std::max_element(kurtx.begin(), kurtx.end());
        }
        
        for (int j : indices) {
          if (sizes[j] == sizes[i] && kurtx[j] == infn2) {
            d1 = etype_column[j];
          }
          if (sizes[j] == sizes[i] && kurtx[j] == supn2) {
            d2 = etype_column[j];
          }
        }
        
        if (sizes[i] == infn) {
          da = interpolate(kurt1, infn2, supn2, d1, d2);
        } else {
          db = interpolate(kurt1, infn2, supn2, d1, d2);
        }
      }
    }
    
    result1 = interpolate(size, infn, supn, da, db);
  }
  
  return result1;
}

                                 


// [[Rcpp::export]]
double d_adjust_skew(int size, int dtype, double skew1, DataFrame dlist, int etype) {
  skew1 = std::abs(skew1);

  NumericVector sizes = dlist[0];
  NumericVector dtypes = dlist[1];
  NumericVector kurtx = dlist[2];
  NumericVector skewx = dlist[3];
  NumericVector etype_column = dlist[etype - 1];

  int nrows = dlist.nrows();
  std::vector<int> indices;
  for (int i = 0; i < nrows; ++i) {
    if (dtypes[i] == dtype) {
      indices.push_back(i);
    }
  }

  double result1 = 0.0;

  if (std::find(sizes.begin(), sizes.end(), size) != sizes.end()) {
    bool found = false;
    for (int i : indices) {
      if (sizes[i] == size && skewx[i] == skew1) {
        result1 = etype_column[i];
        found = true;
        break;
      }
    }

    if (!found) {
      double infn2 = -std::numeric_limits<double>::infinity();
      double supn2 = std::numeric_limits<double>::infinity();
      double d1 = 0.0;
      double d2 = 0.0;
      for (int i : indices) {
        if (sizes[i] == size) {
          if (skewx[i] < skew1) {
            infn2 = std::max(infn2, skewx[i]);
          } else {
            supn2 = std::min(supn2, skewx[i]);
          }
        }
      }

      if (infn2 == -std::numeric_limits<double>::infinity()) {
        infn2 = *std::min_element(skewx.begin(), skewx.end());
      }

      if (supn2 == std::numeric_limits<double>::infinity()) {
        supn2 = *std::max_element(skewx.begin(), skewx.end());
      }

      for (int i : indices) {
        if (sizes[i] == size && skewx[i] == infn2) {
          d1 = etype_column[i];
        }
        if (sizes[i] == size && skewx[i] == supn2) {
          d2 = etype_column[i];
        }
      }

      result1 = interpolate(skew1, infn2, supn2, d1, d2);
    }
  } else {
    double infn = -std::numeric_limits<double>::infinity();
    double supn = std::numeric_limits<double>::infinity();
    double da = 0.0;
    double db = 0.0;

    for (int i : indices) {
      if (sizes[i] < size) {
        infn = std::max(infn, sizes[i]);
      } else {
        supn = std::min(supn, sizes[i]);
      }
    }

    if (infn == -std::numeric_limits<double>::infinity()) {
      infn = *std::min_element(sizes.begin(), sizes.end());
    }
    
    if (supn == std::numeric_limits<double>::infinity()) {
      supn = *std::max_element(sizes.begin(), sizes.end());
    }
    
    for (int i : indices) {
      if (sizes[i] == infn || sizes[i] == supn) {
        double infn2 = -std::numeric_limits<double>::infinity();
        double supn2 = std::numeric_limits<double>::infinity();
        double d1 = 0.0;
        double d2 = 0.0;

        for (int j : indices) {
          if (sizes[j] == sizes[i]) {
            if (skewx[j] < skew1) {
              infn2 = std::max(infn2, skewx[j]);
            } else {
              supn2 = std::min(supn2, skewx[j]);
            }
          }
        }

        if (infn2 == -std::numeric_limits<double>::infinity()) {
          infn2 = *std::min_element(skewx.begin(), skewx.end());
        }

        if (supn2 == std::numeric_limits<double>::infinity()) {
          supn2 = *std::max_element(skewx.begin(), skewx.end());
        }

        for (int j : indices) {
          if (sizes[j] == sizes[i] && skewx[j] == infn2) {
            d1 = etype_column[j];
          }
          if (sizes[j] == sizes[i] && skewx[j] == supn2) {
            d2 = etype_column[j];
          }
        }

        if (sizes[i] == infn) {
          da = interpolate(skew1, infn2, supn2, d1, d2);
        } else {
          db = interpolate(skew1, infn2, supn2, d1, d2);
        }
      }
    }

    result1 = interpolate(size, infn, supn, da, db);
  }

  return result1;
}



/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it in any conditions.
 */
