#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double hlkernel(NumericVector vector) {
  int n = vector.size();
  double sum = std::accumulate(vector.begin(), vector.end(), 0.0);
  return sum / n;
}

// [[Rcpp::export]]
NumericVector apply_hl(NumericMatrix matrix) {
  int n_rows = matrix.nrow();
  NumericVector result(n_rows);

  for (int i = 0; i < n_rows; ++i) {
    NumericVector row = matrix(i, _);
    result[i] = hlkernel(row);
  }

  return result;
}
