#include <Rcpp.h>
using namespace Rcpp;
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */

double getvar(NumericVector x) {
  return pow(x[0] - x[1], 2) / 2;
}

// [[Rcpp::export]]
NumericVector varapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = getvar(mat.row(i));
  }
  return out;
}

double gettm(NumericVector x) {
  double res = ((1.0/6.0)*(2*x[0]-x[1]-x[2])*(-1*x[0]+2*x[1]-x[2])*(-x[0]-x[1]+2*x[2]));
  return res;
}

// [[Rcpp::export]]
NumericVector tmapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gettm(mat.row(i));
  }
  return out;
}

double getfm(NumericVector x) {
  double res = ((1.0/12.0)*(3*pow(x[0],4)+3*pow(x[1],4)+3*pow(x[2],4)+6*pow(x[1],2)*x[2]*x[3]-4*pow(x[2],3)*x[3]-
                4*x[2]*pow(x[3],3)+3*pow(x[3],4)-4*pow(x[1],3)*(x[2]+x[3])-4*pow(x[0],3)*(x[1]+x[2]+x[3])+
                x[1]*(-4*pow(x[2],3)+6*pow(x[2],2)*x[3]+6*x[2]*pow(x[3],2)-4*pow(x[3],3))+
                6*pow(x[0],2)*((x[2] * x[3]) + x[1] * (x[2] +x[3])) +
                x[0] *(-4*pow(x[1],3)-4*pow(x[2],3)+6*pow(x[2],2)*x[3]+6*pow(x[3], 2)*x[2]-4 * pow(x[3], 3)+
                6*pow(x[1], 2)*(x[2]+x[3])+6*(x[1])*(pow(x[2], 2)-6*x[3]*(x[2])+pow(x[3], 2)
                ))));
  return res;
}

// [[Rcpp::export]]
NumericVector fmapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = getfm(mat.row(i));
  }
  return out;
}


double gethl(NumericVector x) {
  return (x[0] + x[1])/2;
}

// [[Rcpp::export]]
NumericVector hlapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl(mat.row(i));
  }
  return out;
}

double gethl3(NumericVector x) {
  return (x[0] + x[1] + x[2])/3;
}

// [[Rcpp::export]]
NumericVector hl3apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl3(mat.row(i));
  }
  return out;
}


double gethl4(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3])/4;
}

// [[Rcpp::export]]
NumericVector hl4apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl4(mat.row(i));
  }
  return out;
}


double gethl5(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4])/5;
}

// [[Rcpp::export]]
NumericVector hl5apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl5(mat.row(i));
  }
  return out;
}


double gethl6(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4]+ x[5])/6;
}

// [[Rcpp::export]]
NumericVector hl6apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl6(mat.row(i));
  }
  return out;
}



double gethl7(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4]+ x[5]+ x[6])/7;
}

// [[Rcpp::export]]
NumericVector hl7apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl7(mat.row(i));
  }
  return out;
}



double gethl8(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4]+ x[5]+ x[6]+ x[7])/8;
}

// [[Rcpp::export]]
NumericVector hl8apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl8(mat.row(i));
  }
  return out;
}


double gethl9(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4]+ x[5]+ x[6]+ x[7]+x[8])/9;
}

// [[Rcpp::export]]
NumericVector hl9apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl9(mat.row(i));
  }
  return out;
}






double gethl10(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4]+ x[5]+ x[6]+ x[7]+ x[8]+ x[9])/10;
}

// [[Rcpp::export]]
NumericVector hl10apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl10(mat.row(i));
  }
  return out;
}



double gethl11(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4]+ x[5]+ x[6]+ x[7]+ x[8]+ x[9]+ x[10])/11;
}

// [[Rcpp::export]]
NumericVector hl11apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl11(mat.row(i));
  }
  return out;
}

// [[Rcpp::export]]
NumericMatrix sample_and_sort(const NumericVector& sortedx, int order, int times) {
    int n = sortedx.size();
    NumericMatrix result(times, order);

    for (int i = 0; i < times; ++i) {
        IntegerVector indices = sample(n, order, false) - 1;

        NumericVector temp(order);
        for (int j = 0; j < order; ++j) {
            temp[j] = sortedx[indices[j]];
        }

        temp.sort();
        result.row(i) = temp;
    }

    return result;
}


/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it in any conditions.
 */
