#include <Rcpp.h>
using namespace Rcpp;
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */

// [[Rcpp::export]]
NumericVector extract1(IntegerVector orderlist1, NumericVector sortedx, int dimension) {
  int n = orderlist1.length();
  NumericVector result(dimension);
  
  for (int i = 0; i < dimension; i++) {
    if (i < n) {
      result[i] = sortedx[orderlist1[i] - 1];
    } else {
      result[i] = NA_REAL;
    }
  }
  
  return result;
}

// [[Rcpp::export]]
NumericMatrix bootbatch1(IntegerMatrix orderlist11, NumericVector sortedx, int dimension) {
  int nrow = orderlist11.nrow();
  NumericMatrix result(nrow, dimension);
  
  for (int i = 0; i < nrow; i++) {
    result(i, _) = extract1(orderlist11(i, _), sortedx, dimension);
  }
  
  return result;
}
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */
