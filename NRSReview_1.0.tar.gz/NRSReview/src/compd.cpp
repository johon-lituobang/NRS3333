#include <Rcpp.h>
using namespace Rcpp;
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */

// [[Rcpp::export]]
List compd(double expectanalytic, double expecttrue, double expectboot,
             double SWA1, double median1, double mx1,
             double quatileexpectanalytic, double quatileexpecttrue, double quatileexpectboot) {

  double dqm1boot, dqm1analytic, dqm1true, drm1boot, drm1analytic, drm1true;

  if (mx1 > 0.5) {
    dqm1boot = (quatileexpectboot - mx1) / (mx1 - 0.5);
    dqm1analytic = (quatileexpectanalytic - mx1) / (mx1 - 0.5);
    dqm1true = (quatileexpecttrue - mx1) / (mx1 - 0.5);
  } else if (mx1 == 0.5) {
    dqm1boot = 0;
    dqm1analytic = 0;
    dqm1true = 0;
  } else {
    quatileexpectboot = 1 - quatileexpectboot;
    quatileexpectanalytic = 1 - quatileexpectanalytic;
    quatileexpecttrue = 1 - quatileexpecttrue;
    mx1 = 1 - mx1;
    dqm1boot = (quatileexpectboot - mx1) / (mx1 - 0.5);
    dqm1analytic = (quatileexpectanalytic - mx1) / (mx1 - 0.5);
    dqm1true = (quatileexpecttrue - mx1) / (mx1 - 0.5);
  }
  drm1boot = (expectboot - SWA1) / (SWA1 - median1);
  drm1analytic = (expectanalytic - SWA1) / (SWA1 - median1);
  drm1true = (expecttrue - SWA1) / (SWA1 - median1);

  return List::create(Named("drm1analytic") = drm1analytic,
                      Named("drm1true") = drm1true,
                      Named("drm1boot") = drm1boot,
                      Named("dqm1analytic") = dqm1analytic,
                      Named("dqm1true") = dqm1true,
                      Named("dqm1boot") = dqm1boot);
}
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */
