#include <Rcpp.h>
#include <algorithm>
#include <random>
using namespace Rcpp;

// [[Rcpp::export]]
double median_of_means(NumericVector x, int korder=4) {
  int n = x.size();
  if (korder <= 0 || korder > n) {
    stop("The block size must be positive and less than or equal to the data size.");
  }
  
  int num_blocks = n / korder;
  int remainder = n % korder;
  
  std::random_device rd;
  std::mt19937 g(rd());
  std::shuffle(x.begin(), x.end(), g);
  
  NumericVector block_means(num_blocks + (remainder > 0 ? 1 : 0));
  
  int idx = 0;
  for (int i = 0; i < num_blocks; ++i) {
    double sum = 0;
    for (int j = 0; j < korder; ++j) {
      sum += x[idx];
      ++idx;
    }
    block_means[i] = sum / korder;
  }
  
  if (remainder > 0) {
    double sum = 0;
    for (int j = 0; j < remainder; ++j) {
      sum += x[idx];
      ++idx;
    }
    block_means[num_blocks] = sum / remainder;
  }
  
  std::sort(block_means.begin(), block_means.end());
  double median;
  int num_elements = block_means.size();
  if (num_elements % 2 == 0) {
    median = (block_means[num_elements / 2 - 1] + block_means[num_elements / 2]) / 2;
  } else {
    median = block_means[num_elements / 2];
  }
  
  return median;
}





/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it in any conditions.
 */
