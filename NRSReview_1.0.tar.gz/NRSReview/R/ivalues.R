#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.




mmmprocessrm<-function(SWA,median,drm=0.375){
  rm1<--drm*median+SWA+drm*SWA
  names(rm1)<-NULL
  output1<-c(rm=rm1)
  return(output1)
}

mmmprocessqm<-function(x,percentage,pc1,dqm=0.567,sorted=TRUE,beNA=FALSE){
  if(sorted){
    x<-x
  }else{
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if (pc1==0.5){
    quatiletarget<-0.5
  }else if (pc1>0.5){
    quatiletarget<-pc1+(pc1-0.5)*dqm
  }else{
    pc1<-1-pc1
    quatiletarget<-pc1+(pc1-0.5)*dqm
    quatiletarget<-1-quatiletarget
  }
  upper1<-(1-percentage)
  lower1<-percentage
  if(quatiletarget>upper1){
    if (beNA){
      return(NA)
    }else{
      quatiletarget=upper1
    }
  }else if(quatiletarget<lower1){
    if (beNA){
      return(NA)
    }else{
      quatiletarget=lower1
    }
  }
  qm1<-quantilefunction(x,quatiletarget,sorted=TRUE)
  output1<-c(qm=qm1)
  return(output1)
}


d_kurt_list<-function(size,dtype,kurt1,dlist){
  dlist<-dlist[dlist[,2] == dtype,]
  if(size%in% dlist[,1]){
    if (kurt1%in% dlist[dlist[,1] == size,3]){
      result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,3])
      tryCatch({
        infn2 <- max(rown2[rown2 <= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
        message(custom_warning)
        infn2<<- min(rown2)
      })
      tryCatch({
        supn2 <- min(rown2[rown2 >= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
        message(custom_warning)
        supn2<<-max(rown2)
      })
      
      if(supn2==infn2){
        result1<-dlist[dlist[,1]==size & dlist[,3]==infn2,]
      }else{
        d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,]
        d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,]
        result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )
    
    rown2<-as.numeric(dlist[dlist[,1] == infn,3])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <-sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    if(supn2==infn2){
      da<-dlist[dlist[,1]==infn & dlist[,3]==infn2,]
    }else{
      d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,]
      d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,]
      
      da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
    
    rown2<-as.numeric(dlist[dlist[,1] == supn,3])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    
    if(supn2==infn2){
      db<-dlist[dlist[,1]==supn & dlist[,3]==infn2,]
    }else{
      d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,]
      d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,]
      
      db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
    if(supn==infn){
      result1<-db
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}
d_skew_list<-function(size,dtype,skew1,dlist){
  dlist<-dlist[dlist[,2] == dtype,]
  if(size%in% dlist[,1]){
    if (skew1%in% dlist[dlist[,1] == size,4]){
      result1<-dlist[dlist[,1] == size & dlist[,4]==skew1,]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,4])
      tryCatch({
        infn2 <- max(rown2[rown2 <= skew1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
        message(custom_warning)
        infn2<<- min(rown2)
      })
      tryCatch({
        supn2 <- min(rown2[rown2 >= skew1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
        message(custom_warning)
        supn2<<-max(rown2)
      })
      
      if(supn2==infn2){
        result1<-dlist[dlist[,1]==size & dlist[,4]==infn2,]
      }else{
        d1<-dlist[dlist[,1]==size & dlist[,4]==infn2,]
        d2<-dlist[dlist[,1]==size & dlist[,4]==supn2,]
        result1<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )
    
    rown2<-as.numeric(dlist[dlist[,1] == infn,4])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= skew1])
    },
    warning = function(w) {
      custom_warning <-sprintf("The skewness is too large (%f), out of range supported.", skew1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    if(supn2==infn2){
      da<-dlist[dlist[,1]==infn & dlist[,4]==infn2,]
    }else{
      d1<-dlist[dlist[,1]==infn & dlist[,4]==infn2,]
      d2<-dlist[dlist[,1]==infn & dlist[,4]==supn2,]
      
      da<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }
    
    rown2<-as.numeric(dlist[dlist[,1] == supn,4])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    
    if(supn2==infn2){
      db<-dlist[dlist[,1]==supn & dlist[,4]==infn2,]
    }else{
      d1<-dlist[dlist[,1]==supn & dlist[,4]==infn2,]
      d2<-dlist[dlist[,1]==supn & dlist[,4]==supn2,]
      
      db<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }
    if(supn==infn){
      result1<-db
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}






rqmoments<-function (x,start_kurt,start_skew,dtype1=1,releaseall=FALSE,standist_d=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_hlsmall=NULL,orderlist1_hllarge=NULL,percentage=1/24,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  x<-c()
  lengthx<-length(sortedx)
  if(is.null(standist_d)){
    data(d_values)
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)
    
    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample3<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    
    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample4<-c()
    
  }
  max_dim=6
  
  SWA_mean<-SWA(x=sortedx,percentage=percentage,batch=batch,sorted=TRUE,rand = TRUE)
  
  SWHLM_mean<-SWHLM(x=sortedx,max_dim=max_dim,orderlists=orderlist1_hlsmall,percentage=percentage,batch=batch,boot=TRUE)
  SWHLM_mean<-unlist(lapply(SWHLM_mean, remove_first))
  orderlist1_hlsmall<-c()
  orderlist1_sorted20<-c()
  orderlist1_sorted30<-c()
  orderlist1_sorted40<-c()
  
  CDF_SWA_mean <- sapply(SWA_mean[2:(length(SWA_mean)-1)], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_mean) <- paste0("pc_mean", names(SWA_mean)[2:(length(SWA_mean)-1)])
  
  CDF_SWHLM_mean <- sapply(SWHLM_mean, function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_mean) <- paste0("pc_mean", names(SWHLM_mean))
  
  SWAvar<-SWA(x=dp2varx,percentage=1-(1-percentage)^2,batch="auto",sorted=TRUE)
  
  SWHLM_var<-SWHLM(x=dp2varx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^2,batch=batch,boot=TRUE)
  SWHLM_var<-(lapply(SWHLM_var, remove_first))
  SWHLM_var<-unlist(SWHLM_var)
  
  CDF_SWA_var <- sapply(SWAvar[2:(length(SWAvar)-1)], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_var) <- paste0("pc_var", names(SWAvar)[2:(length(SWAvar)-1)])
  
  CDF_SWHLM_var <- sapply(SWHLM_var, function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_var) <- paste0("pc_var", names(SWHLM_var))
  
  SWAtm<-SWA(x=dp3tmx,percentage=1-(1-percentage)^3,batch="auto",sorted=TRUE)
  
  SWHLM_tm<-SWHLM(x=dp3tmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^3,batch=batch,boot=TRUE)
  SWHLM_tm<-(lapply(SWHLM_tm, remove_first))
  SWHLM_tm<-unlist(SWHLM_tm)
  
  CDF_SWA_tm <- sapply(SWHLM_tm[2:(length(SWAtm)-1)], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_tm) <- paste0("pc_tm", names(SWAtm)[2:(length(SWAtm)-1)])
  
  CDF_SWHLM_tm <- sapply(SWHLM_tm, function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_tm) <- paste0("pc_tm", names(SWHLM_tm))
  
  SWAfm<-SWA(x=dp4fmx,percentage=1-(1-percentage)^4,batch="auto",sorted=TRUE)
  SWHLM_fm<-SWHLM(x=dp4fmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^4,batch=batch,boot=TRUE)
  SWHLM_fm<-(lapply(SWHLM_fm, remove_first))
  SWHLM_fm<-unlist(SWHLM_fm)
  
  orderlist1_hllarge<-c()
  CDF_SWA_fm <- sapply(SWAfm[2:(length(SWAfm)-1)], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_fm) <- paste0("pc_fm", names(SWAfm)[2:(length(SWAfm)-1)])
  
  CDF_SWHLM_fm <- sapply(SWHLM_fm, function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_fm) <- paste0("pc_fm", names(SWHLM_fm))
  
  
  allds_start<-d_kurt_list(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d)
  
  vardvalueindices1<-77
  vardvalueindices2<-128
  fmdvalueindices1<-169
  fmdvalueindices2<-196
  
  var_ds_rm<-allds_start[seq(from=vardvalueindices1, to=vardvalueindices2, by=2)]
  
  varSWAall<-c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var)
  
  rvarall<-var_ds_rm*varSWAall+varSWAall-var_ds_rm*SWAvar[length(SWAvar)]
  
  fmSWAall<-c(SWAfm[2:(length(SWAfm)-1)],SWHLM_fm)
  
  fm_ds_rm<-allds_start[seq(from=fmdvalueindices1, to=fmdvalueindices2, by=2)]
  
  rfmall<-fm_ds_rm*fmSWAall+fmSWAall-fm_ds_rm*SWAfm[length(SWAfm)]
  kurtfunction<- function(x, y) {
    return(x /(y^2))
  }
  rkurtall <- t(outer(as.numeric(rfmall), as.numeric(rvarall), FUN =kurtfunction))
  
  #exp_qm
  
  var_ds_qm<-allds_start[seq(from=vardvalueindices1+1, to=vardvalueindices2, by=2)]
  
  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)
  
  fm_ds_qm<-allds_start[seq(from=fmdvalueindices1+1, to=fmdvalueindices2, by=2)]
  
  CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWHLM_fm)
  
  qvarall<-c()
  for(i in (1:length(CDF_varSWAall))){
    qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=var_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qvarall)<-names(CDF_varSWAall)
  qvarall<-unlist(qvarall)
  
  qfmall<-c()
  for(i in (1:length(CDF_fmSWAall))){
    qfmall<-c(qfmall,mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[i],dqm=fm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qfmall)<-names(CDF_fmSWAall)
  
  qkurtall <- t(outer(as.numeric(qfmall), as.numeric(qvarall), FUN =kurtfunction))
  
  #exp_rm
  
  tmdvalueindices1<-129
  tmdvalueindices2<-168
  
  tm_ds_rm<-allds_start[seq(from=tmdvalueindices1, to=tmdvalueindices2, by=2)]
  
  tmSWAall<-c(SWAtm[2:(length(SWAtm)-1)],SWHLM_tm)
  
  rtmall<-tm_ds_rm*tmSWAall+tmSWAall-tm_ds_rm*SWAtm[length(SWAtm)]
  
  skewfunction<- function(x, y) {
    return(x /(y^(3/2)))
  }
  rskewall <- t(outer(as.numeric(rtmall), as.numeric(rvarall), FUN =skewfunction))
  
  tm_ds_qm<-allds_start[seq(from=tmdvalueindices1+1, to=tmdvalueindices2, by=2)]
  
  CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWHLM_tm)
  
  qtmall<-c()
  for(i in (1:length(CDF_tmSWAall))){
    qtmall<-c(qtmall,mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[i],dqm=tm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qtmall)<-names(CDF_tmSWAall)
  
  qskewall <- t(outer(as.numeric(qtmall), as.numeric(qvarall), FUN =kurtfunction))
  
  meandvalueindices1<-5
  meandvalueindices2<-76
  
  mean_ds_rm<-allds_start[seq(from=meandvalueindices1, to=meandvalueindices2, by=2)]
  
  meanSWAall<-c(SWA_mean[2:(length(SWA_mean)-1)],SWHLM_mean)
  
  rmall<-mean_ds_rm*meanSWAall+meanSWAall-mean_ds_rm*SWA_mean[length(SWA_mean)]
  
  mean_ds_qm<-allds_start[seq(from=meandvalueindices1+1, to=meandvalueindices2, by=2)]
  
  CDF_meanSWAall<-c(CDF_SWA_mean,CDF_SWHLM_mean)
  
  qmall<-c()
  for(i in (1:length(CDF_meanSWAall))){
    qmall<-c(qmall,mmmprocessqm(x=sortedx,percentage=percentage,pc1=CDF_meanSWAall[i],dqm=mean_ds_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qmall)<-names(CDF_meanSWAall)
  qmall<-unlist(qmall)
  
  
  meandvalueindices1<-5
  meandvalueindices2<-76
  vardvalueindices1<-77
  vardvalueindices2<-128
  tmdvalueindices1<-129
  tmdvalueindices2<-168
  fmdvalueindices1<-169
  fmdvalueindices2<-196
  
  kurt1=18
  skew1=2.67
  rkurtall_Weibull<-calculate_rkurtall(startkurt=kurt1,nrows=length(varSWAall),ncols=length(fmSWAall),varSWAall,fmSWAall,SWAvar,SWAfm,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,criterion,stepsize)
  
  qkurtall_Weibull<-calculate_qkurtall(startkurt=kurt1,nrows=length(CDF_varSWAall),ncols=length(CDF_fmSWAall), lengthx, dtype1, standist_d, vardvalueindices1, fmdvalueindices1, dp2varx, percentage, CDF_varSWAall, dp4fmx, CDF_fmSWAall, criterion, stepsize) 
  
  rskewall_Weibull<-calculate_rskewall(start_skew=skew1,nrows=length(varSWAall),ncols=length(tmSWAall), lengthx, dtype1, standist_d, vardvalueindices1, tmdvalueindices1, varSWAall, SWAvar, tmSWAall, SWAtm, criterion, stepsize) 
  
  qskewall_Weibull<-calculate_qskewall(start_skew=skew1,nrows=length(CDF_varSWAall),ncols=length(CDF_tmSWAall), lengthx, dtype1, standist_d, vardvalueindices1, tmdvalueindices1, CDF_varSWAall, CDF_tmSWAall, dp2varx, dp3tmx, percentage, criterion, stepsize)
  
  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))
  
  allresults1<-c(rkurtall=rkurtall,qkurtall=qkurtall,rskewall=rskewall,qskewall=qskewall,rmall=rmall,qmall=qmall,rvarall=rvarall,qvarall=qvarall,rtmall=rtmall,qtmall=qtmall,rfmall=rfmall,qfmall=qfmall,rkurtall_Weibull=rkurtall_Weibull,qkurtall_Weibull=qkurtall_Weibull,rskewall_Weibull=rskewall_Weibull,qskewall_Weibull=qskewall_Weibull)
  
  if(releaseall){
    finallall<-c(SWA_mean=SWA_mean,
                 SWHLM_mean=SWHLM_mean,
                 CDF_SWA_mean=CDF_SWA_mean,
                 CDF_SWHLM_mean=CDF_SWHLM_mean,
                 SWAvar=SWAvar,
                 SWHLM_var=SWHLM_var,
                 CDF_SWA_var=CDF_SWA_var,
                 CDF_SWHLM_var=CDF_SWHLM_var,
                 SWAtm=SWAtm,
                 SWHLM_tm=SWHLM_tm,
                 CDF_SWA_tm=CDF_SWA_tm,
                 CDF_SWHLM_tm=CDF_SWHLM_tm,
                 SWAfm=SWAfm,
                 SWHLM_fm=SWHLM_fm,
                 CDF_SWA_fm=CDF_SWA_fm,
                 CDF_SWHLM_fm=CDF_SWHLM_fm,
                 sdall=sdall)
    return(c(allresults1,finallall))
  }else{
    return(c(allresults1))
  }
}



rqmoments2<-function (x,iall1=NULL,dtype1=1,Iskewtype1=4,Ikurttype1=5,releaseall=FALSE,standist_d=NULL,standist_I=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,percentage=1/24,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  x<-c()
  lengthx<-length(sortedx)
  if(is.null(standist_d)||is.null(standist_I)){
    data(d_values)
    data(I_values)
    standist_I<-I_values
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)
    
    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
    
    orderlist1_sorted20<-c()
    orderlist1_sorted30<-c()
    orderlist1_sorted40<-c()
    
    
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample3<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    
    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample4<-c()
    
  }
  
  SWA_mean<-unlist(iall1[3729:3736])
  
  SWHLM_mean=unlist(iall1[3737:3766])
  
  CDF_SWA_mean <- unlist(iall1[3767:3772])
  
  CDF_SWHLM_mean <- unlist(iall1[3773:3802])
  
  SWAvar<-unlist(iall1[3803:3810])
  
  SWHLM_var<-unlist(iall1[3811:3830])
  
  CDF_SWA_var <- unlist(iall1[3831:3836])
  
  CDF_SWHLM_var <- unlist(iall1[3837:3856])
  
  SWAtm<-unlist(iall1[3857:3864])
  
  SWHLM_tm<-unlist(iall1[3865:3878])
  
  CDF_SWA_tm <- unlist(iall1[3879:3884])
  
  CDF_SWHLM_tm <-unlist( iall1[3885:3898])
  
  SWAfm<-unlist(iall1[3899:3905])
  SWHLM_fm<-unlist(iall1[3906:3914])
  
  CDF_SWA_fm <- unlist(iall1[3915:3919])
  
  CDF_SWHLM_fm <- unlist(iall1[3920:3928])
  
  meandvalueindices1<-5
  meandvalueindices2<-76
  vardvalueindices1<-77
  vardvalueindices2<-128
  tmdvalueindices1<-129
  tmdvalueindices2<-168
  fmdvalueindices1<-169
  fmdvalueindices2<-196
  
  IkurtI_values<-standist_I[,c(1:4,5:732)]
  ikurtendindex<-732
  IskewI_values<-standist_I[,c(1:4,(1461):2500)]
  iskewendindex2<-1044
  
  rqkurtsall1<-function(start_kurt){
    
    allds_start<-d_kurt_list(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d)
    
    var_ds_rm<-allds_start[seq(from=vardvalueindices1, to=vardvalueindices2, by=2)]
    
    varSWAall<-unlist(c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var))
    
    rvarall<-var_ds_rm*varSWAall+varSWAall-var_ds_rm*SWAvar[length(SWAvar)]
    
    fmSWAall<-c(SWAfm[2:(length(SWAfm)-1)],SWHLM_fm)
    
    fm_ds_rm<-allds_start[seq(from=fmdvalueindices1, to=fmdvalueindices2, by=2)]
    
    rfmall<-fm_ds_rm*fmSWAall+fmSWAall-fm_ds_rm*SWAfm[length(SWAfm)]
    kurtfunction<- function(x, y) {
      return(x /(y^2))
    }
    rkurtall <- t(outer(as.numeric(rfmall), as.numeric(rvarall), FUN =kurtfunction))
    
    var_ds_qm<-allds_start[seq(from=vardvalueindices1+1, to=vardvalueindices2, by=2)]
    
    CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)
    
    fm_ds_qm<-allds_start[seq(from=fmdvalueindices1+1, to=fmdvalueindices2, by=2)]
    
    CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWHLM_fm)
    
    qvarall<-c()
    for(i in (1:length(CDF_varSWAall))){
      qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=var_ds_qm[i],sorted=TRUE,beNA=TRUE))
    }
    names(qvarall)<-names(CDF_varSWAall)
    qvarall<-unlist(qvarall)
    
    qfmall<-c()
    for(i in (1:length(CDF_fmSWAall))){
      qfmall<-c(qfmall,mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[i],dqm=fm_ds_qm[i],sorted=TRUE,beNA=TRUE))
    }
    names(qfmall)<-names(CDF_fmSWAall)
    
    qkurtall <- t(outer(as.numeric(qfmall), as.numeric(qvarall), FUN =kurtfunction))
    c(rkurtall=rkurtall,qkurtall=qkurtall)
  }
  
  ikurt1 <- 18
  
  Kappa1<-function(kurt1){
    rqkurtall<-rqkurtsall1(start_kurt=kurt1)
    
    Ikurt1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=kurt1,Ilist=IkurtI_values)
    
    if(typeof(Ikurt1)=="list"){
      na_cols <- which(is.na(rqkurtall))
      Ikurt1$I1[5:ikurtendindex][na_cols]<-NA
      Ikurt1$I2[5:ikurtendindex][na_cols]<-NA
      ikurt11<-rqkurtall[which.min(Ikurt1$I1[5:ikurtendindex])]
      ikurt12<-rqkurtall[which.min(Ikurt1$I2[5:ikurtendindex])]
      if(ikurt11==ikurt12){
        ikurt110<-ikurt12
      }else{
        ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
      }
    }else{
      na_cols <- which(is.na(rqkurtall))
      Ikurt1[5:ikurtendindex][na_cols]<-NA
      ikurt110<-rqkurtall[which.min(Ikurt1[5:ikurtendindex])]
    }
    
    ikurt110
  }
  
  step1 <- 0
  
  repeat {
    step1 <- step1 + 1
    
    ikurt2 <- Kappa1(ikurt1)
    
    if ((abs(ikurt1 - ikurt2)) < criterion || (step1 == stepsize)) {
      if((step1 == stepsize)) {
        print(stepsize)
      }
      break
    }
    
    ikurt1<-ikurt2
  }
  
  rqskewsall1<-function(start_skew){
    
    allds_start<-d_skew_list(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d)
    
    var_ds_rm<-allds_start[seq(from=vardvalueindices1, to=vardvalueindices2, by=2)]
    
    varSWAall<-c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var)
    
    rvarall<-var_ds_rm*varSWAall+varSWAall-var_ds_rm*SWAvar[length(SWAvar)]
    
    var_ds_qm<-allds_start[seq(from=vardvalueindices1+1, to=vardvalueindices2, by=2)]
    
    CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)
    
    qvarall<-c()
    for(i in (1:length(CDF_varSWAall))){
      qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=var_ds_qm[i],sorted=TRUE,beNA=TRUE))
    }
    names(qvarall)<-names(CDF_varSWAall)
    qvarall<-unlist(qvarall)
    
    tm_ds_rm<-allds_start[seq(from=tmdvalueindices1, to=tmdvalueindices2, by=2)]
    
    tmSWAall<-c(SWAtm[2:(length(SWAtm)-1)],SWHLM_tm)
    
    rtmall<-tm_ds_rm*tmSWAall+tmSWAall-tm_ds_rm*SWAtm[length(SWAtm)]
    
    skewfunction<- function(x, y) {
      return(x /(y^(3/2)))
    }
    rskewall <- t(outer(as.numeric(rtmall), as.numeric(rvarall), FUN =skewfunction))
    
    tm_ds_qm<-allds_start[seq(from=tmdvalueindices1+1, to=tmdvalueindices2, by=2)]
    
    CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWHLM_tm)
    
    qtmall<-c()
    for(i in (1:length(CDF_tmSWAall))){
      qtmall<-c(qtmall,mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[i],dqm=tm_ds_qm[i],sorted=TRUE,beNA=TRUE))
    }
    names(qtmall)<-names(CDF_tmSWAall)
    
    qskewall <- t(outer(as.numeric(qtmall), as.numeric(qvarall), FUN =skewfunction))
    
    c(rskewall=rskewall,qskewall=qskewall)
  }
  
  
  Skew1_SE<-function(start_skew1,ikurt1=NA){
    rqskewall1<-rqskewsall1(start_skew=start_skew1)
    if(Iskewtype1!=5){
      Iskew1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=start_skew1,Ilist=IskewI_values)
    }else{
      Iskew1<-I_adjust_kurt(size=lengthx,dtype=Iskewtype1,kurt1=ikurt1,Ilist=IskewI_values)
    }
    if(typeof(Iskew1)=="list"){
      na_cols <- which(is.na(rqskewall1))
      Iskew1$I1[5:iskewendindex2][na_cols]<-NA
      Iskew1$I2[5:iskewendindex2][na_cols]<-NA
      iskew11<-rqskewall1[which.min(Iskew1$I1[5:iskewendindex2])]
      iskew12<-rqskewall1[which.min(Iskew1$I2[5:iskewendindex2])]
      if(iskew11==iskew12){
        iskew110<-iskew12
      }else{
        iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
      }
    }else{
      na_cols <- which(is.na(rqskewall1))
      Iskew1[5:iskewendindex2][na_cols]<-NA
      iskew110<-rqskewall1[which.min(Iskew1[5:iskewendindex2])]
    }
    
    iskew110
  }
  
  iskew1<-2.67
  
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    iskew2<-Skew1_SE(iskew1,ikurt1=ikurt1)
    
    if ((abs(iskew1-iskew2))<criterion || (step1 == stepsize)){
      
      break
    }
    iskew1<-iskew2
  }
  iskew1<-as.numeric(iskew1)
  
  
  ikurtselect_Weibull<-unlist(c(iall1[c(1961:2688)]))
  iskewselect_Weibull<-unlist(c(iall1[c(2689:3728)]))
  
  
  #Weibull
  
  ikurt0<-18
  
  iskew0<-2.67
  
  IkurtI_values<-standist_I[,c(1:4,733:1460)]
  IskewI_values<-standist_I[,c(1:4,(2500+1):3540)]
  ikurtendindex2<-732
  iskewendindex2<-1044
  Kappa1_SE<-function(kurt1){
    
    Ikurt1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=kurt1,Ilist=IkurtI_values)
    
    if(typeof(Ikurt1)=="list"){
      na_cols <- which(is.na(ikurtselect_Weibull))
      Ikurt1$I1[5:ikurtendindex2][na_cols]<-NA
      Ikurt1$I2[5:ikurtendindex2][na_cols]<-NA
      ikurt11<-ikurtselect_Weibull[which.min(Ikurt1$I1[5:ikurtendindex2])]
      ikurt12<-ikurtselect_Weibull[which.min(Ikurt1$I2[5:ikurtendindex2])]
      if(ikurt11==ikurt12){
        ikurt110<-ikurt12
      }else{
        ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
      }
    }else{
      na_cols <- which(is.na(ikurtselect_Weibull))
      Ikurt1[5:ikurtendindex2][na_cols]<-NA
      ikurt110<-ikurtselect_Weibull[which.min(Ikurt1[5:ikurtendindex2])]
    }
    
    ikurt110
  }
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    ikurt2<-Kappa1_SE(ikurt0)
    
    if ((abs(ikurt0-ikurt2))<criterion || (step1 == stepsize)){
      
      break
    }
    ikurt0<-ikurt2
  }
  ikurt0<-as.numeric(ikurt0)
  Skew1_SE<-function(start_skew1,ikurt1=NA){
    
    if(Iskewtype1!=5){
      Iskew1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=start_skew1,Ilist=IskewI_values)
    }else{
      Iskew1<-I_adjust_kurt(size=lengthx,dtype=Iskewtype1,kurt1=ikurt1,Ilist=IskewI_values)
    }
    
    if(typeof(Iskew1)=="list"){
      na_cols <- which(is.na(iskewselect_Weibull))
      Iskew1$I1[5:iskewendindex2][na_cols]<-NA
      Iskew1$I2[5:iskewendindex2][na_cols]<-NA
      iskew11<-iskewselect_Weibull[which.min(Iskew1$I1[5:iskewendindex2])]
      iskew12<-iskewselect_Weibull[which.min(Iskew1$I2[5:iskewendindex2])]
      if(iskew11==iskew12){
        iskew110<-iskew12
      }else{
        iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
      }
    }else{
      na_cols <- which(is.na(iskewselect_Weibull))
      Iskew1[5:iskewendindex2][na_cols]<-NA
      iskew110<-iskewselect_Weibull[which.min(Iskew1[5:iskewendindex2])]
    }
    iskew110
  }
  
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    iskew2<-Skew1_SE(iskew0,ikurt1=ikurt1)
    
    if ((abs(iskew0-iskew2))<criterion || (step1 == stepsize)){
      
      break
    }
    iskew0<-iskew2
  }
  iskew0<-as.numeric(iskew0)
  
  return(c(ikurt1=ikurt1,iskew1=iskew1,ikurt2=ikurt0,iskew2=iskew0))
}





rqmoments3<-function (x,iall1=NULL,dtype1=1,Iskewtype1=4,Ikurttype1=5,releaseall=FALSE,standist_d=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,percentage=1/24,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  x<-c()
  lengthx<-length(sortedx)
  if(is.null(standist_d)){
    data(d_values)
    data(I_values)
    standist_I<-I_values
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)
    
    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
    
    orderlist1_sorted20<-c()
    orderlist1_sorted30<-c()
    orderlist1_sorted40<-c()
    
    
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample3<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    
    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample4<-c()
    
  }
  
  SWA_mean<-unlist(iall1[3729:3736])
  
  SWHLM_mean=unlist(iall1[3737:3766])
  
  CDF_SWA_mean <- unlist(iall1[3767:3772])
  
  CDF_SWHLM_mean <- unlist(iall1[3773:3802])
  
  SWAvar<-unlist(iall1[3803:3810])
  
  SWHLM_var<-unlist(iall1[3811:3830])
  
  CDF_SWA_var <- unlist(iall1[3831:3836])
  
  CDF_SWHLM_var <- unlist(iall1[3837:3856])
  
  SWAtm<-unlist(iall1[3857:3864])
  
  SWHLM_tm<-unlist(iall1[3865:3878])
  
  CDF_SWA_tm <- unlist(iall1[3879:3884])
  
  CDF_SWHLM_tm <-unlist( iall1[3885:3898])
  
  SWAfm<-unlist(iall1[3899:3905])
  SWHLM_fm<-unlist(iall1[3906:3914])
  
  CDF_SWA_fm <- unlist(iall1[3915:3919])
  
  CDF_SWHLM_fm <- unlist(iall1[3920:3928])
  
  meandvalueindices1<-5
  meandvalueindices2<-76
  vardvalueindices1<-77
  vardvalueindices2<-128
  tmdvalueindices1<-129
  tmdvalueindices2<-168
  fmdvalueindices1<-169
  fmdvalueindices2<-196
  
  ikurtselect_Weibull<-Rfast::Sort(x=unlist(c(iall1[c(1961:2688)])),descending=FALSE,na.last=TRUE)
  ikurtselect_Weibull<-na.omit(ikurtselect_Weibull)
  iskewselect_Weibull<-Rfast::Sort(x=unlist(c(iall1[c(2689:3728)])),descending=FALSE,partial=NULL,stable=FALSE,na.last=TRUE)
  iskewselect_Weibull<-na.omit(iskewselect_Weibull)
  ikurt11<-quantilefunction(x=ikurtselect_Weibull,quatiletarget=1/5,sorted=TRUE)
  ikurt22<-quantilefunction(x=ikurtselect_Weibull,quatiletarget=4/5,sorted=TRUE)
  iskew11<-quantilefunction(x=iskewselect_Weibull,quatiletarget=1/5,sorted=TRUE)
  iskew22<-quantilefunction(x=iskewselect_Weibull,quatiletarget=4/5,sorted=TRUE)
  
  iskewall<-seq(from=iskew11,to=iskew22,length.out=10)
  ikurtall<-seq(from=ikurt11,to=ikurt22,length.out=10)
  
  rqmoments <- list()
  
  for (i in 1:10) {
    rqmoments[[i]] <- rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
                                          CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[i], ikurt0=ikurtall[i], standist_d, meandvalueindices1, vardvalueindices1,
                                          tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  }
  
  # rqmoments_1<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[1], ikurt0=ikurtall[1], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_2<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[2], ikurt0=ikurtall[2], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_3<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[3], ikurt0=ikurtall[3], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_4<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[4], ikurt0=ikurtall[4], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_5<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[5], ikurt0=ikurtall[5], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_6<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[6], ikurt0=ikurtall[6], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_7<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[7], ikurt0=ikurtall[7], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_8<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[8], ikurt0=ikurtall[8], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_9<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[9], ikurt0=ikurtall[9], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_10<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[10], ikurt0=ikurtall[10], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_11<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[11], ikurt0=ikurtall[11], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_12<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[12], ikurt0=ikurtall[12], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_13<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[13], ikurt0=ikurtall[13], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_14<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[14], ikurt0=ikurtall[14], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_15<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[15], ikurt0=ikurtall[15], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_16<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[16], ikurt0=ikurtall[16], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_17<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[17], ikurt0=ikurtall[17], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_18<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[18], ikurt0=ikurtall[18], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # 
  # rqmoments_19<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[19], ikurt0=ikurtall[19], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_20<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[20], ikurt0=ikurtall[20], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  return(unlist(rqmoments))
  #return(c(ism1=rqmoments_1,ism2=rqmoments_2,ism3=rqmoments_3,ism4=rqmoments_4,ism5=rqmoments_5,ism6=rqmoments_6,ism7=rqmoments_7,ism8=rqmoments_8,ism9=rqmoments_9,ism10=rqmoments_10,ism11=rqmoments_11,ism12=rqmoments_12,ism13=rqmoments_13,ism14=rqmoments_14,ism15=rqmoments_15,ism16=rqmoments_16,ism17=rqmoments_17,ism18=rqmoments_18,ism19=rqmoments_19,ism20=rqmoments_20))
}




imoments<-function (x,dtype1=1,Iskewtype1=4,Ikurttype1=5,releaseall=FALSE,standist_d=NULL,standist_I=NULL,standist_Ismoments=NULL,standist_Imoments=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_hlsmall=NULL,orderlist1_hllarge=NULL,percentage=1/24,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){

  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  x<-c()
  lengthx<-length(sortedx)
  if(is.null(standist_d)){
    data(d_values)
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted20)||is.null(orderlist1_sorted30)||is.null(orderlist1_sorted40)||is.null(orderlist1_hlsmall)||is.null(orderlist1_hllarge)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      largesize1<-2048*9

      orderlist1_sorted20<-createorderlist(quni1=quasiuni_sorted2,size=lengthx,interval=16,dimension=2)
      orderlist1_sorted20<-orderlist1_sorted20[1:largesize1,]
      orderlist1_sorted30<-createorderlist(quni1=quasiuni_sorted3,size=lengthx,interval=16,dimension=3)
      orderlist1_sorted30<-orderlist1_sorted30[1:largesize1,]
      orderlist1_sorted40<-createorderlist(quni1=quasiuni_sorted4,size=lengthx,interval=16,dimension=4)
      orderlist1_sorted40<-orderlist1_sorted40[1:largesize1,]

      orderlist1_sorted2<-createorderlist(quni1=quasiuni_sorted2,size=largesize1,interval=16,dimension=2)
      orderlist1_sorted2<-orderlist1_sorted2[1:largesize1,]
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_sorted3,size=largesize1,interval=16,dimension=3)
      orderlist1_sorted3<-orderlist1_sorted3[1:largesize1,]
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_sorted4,size=largesize1,interval=16,dimension=4)
      orderlist1_sorted4<-orderlist1_sorted4[1:largesize1,]
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }
  max_dim=6

  SWA_mean<-SWA(x=sortedx,percentage=percentage,batch=batch,sorted=TRUE,rand = TRUE)

  SWHLM_mean<-SWHLM(x=sortedx,max_dim=max_dim,orderlists=orderlist1_hlsmall,percentage=percentage,batch=batch,boot=TRUE)
  SWHLM_mean<-unlist(lapply(SWHLM_mean, remove_first))
  orderlist1_hlsmall<-c()
  orderlist1_sorted20<-c()
  orderlist1_sorted30<-c()
  orderlist1_sorted40<-c()

  CDF_SWA_mean <- sapply(SWA_mean[2:(length(SWA_mean)-1)], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_mean) <- paste0("pc_mean", names(SWA_mean)[2:(length(SWA_mean)-1)])

  CDF_SWHLM_mean <- sapply(SWHLM_mean, function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_mean) <- paste0("pc_mean", names(SWHLM_mean))

  SWAvar<-SWA(x=dp2varx,percentage=1-(1-percentage)^2,batch="auto",sorted=TRUE)

  SWHLM_var<-SWHLM(x=dp2varx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^2,batch=batch,boot=TRUE)
  SWHLM_var<-(lapply(SWHLM_var, remove_first))
  SWHLM_var<-unlist(SWHLM_var)

  CDF_SWA_var <- sapply(SWAvar[2:(length(SWAvar)-1)], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_var) <- paste0("pc_var", names(SWAvar)[2:(length(SWAvar)-1)])

  CDF_SWHLM_var <- sapply(SWHLM_var, function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_var) <- paste0("pc_var", names(SWHLM_var))

  SWAtm<-SWA(x=dp3tmx,percentage=1-(1-percentage)^3,batch="auto",sorted=TRUE)

  SWHLM_tm<-SWHLM(x=dp3tmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^3,batch=batch,boot=TRUE)
  SWHLM_tm<-(lapply(SWHLM_tm, remove_first))
  SWHLM_tm<-unlist(SWHLM_tm)

  CDF_SWA_tm <- sapply(SWHLM_tm[2:(length(SWAtm)-1)], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_tm) <- paste0("pc_tm", names(SWAtm)[2:(length(SWAtm)-1)])

  CDF_SWHLM_tm <- sapply(SWHLM_tm, function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_tm) <- paste0("pc_tm", names(SWHLM_tm))

  SWAfm<-SWA(x=dp4fmx,percentage=1-(1-percentage)^4,batch="auto",sorted=TRUE)
  SWHLM_fm<-SWHLM(x=dp4fmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^4,batch=batch,boot=TRUE)
  SWHLM_fm<-(lapply(SWHLM_fm, remove_first))
  SWHLM_fm<-unlist(SWHLM_fm)

  orderlist1_hllarge<-c()
  CDF_SWA_fm <- sapply(SWAfm[2:(length(SWAfm)-1)], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_fm) <- paste0("pc_fm", names(SWAfm)[2:(length(SWAfm)-1)])

  CDF_SWHLM_fm <- sapply(SWHLM_fm, function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_fm) <- paste0("pc_fm", names(SWHLM_fm))


  varSWAall<-c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var)

  fmSWAall<-c(SWAfm[2:(length(SWAfm)-1)],SWHLM_fm)

  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)

  CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWHLM_fm)

  tmSWAall<-c(SWAtm[2:(length(SWAtm)-1)],SWHLM_tm)

  CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWHLM_tm)

  meanSWAall<-c(SWA_mean[2:(length(SWA_mean)-1)],SWHLM_mean)

  CDF_meanSWAall<-c(CDF_SWA_mean,CDF_SWHLM_mean)

  meandvalueindices1<-5
  meandvalueindices2<-76
  vardvalueindices1<-77
  vardvalueindices2<-128
  tmdvalueindices1<-129
  tmdvalueindices2<-168
  fmdvalueindices1<-169
  fmdvalueindices2<-196
# 
#   IkurtI_values<-standist_I[,c(1:4,5:732)]
#   ikurtendindex<-732
#   IskewI_values<-standist_I[,c(1:4,(1461):2500)]
#   iskewendindex2<-1044
# 
#   rqkurtsall1<-function(start_kurt){
# 
#     allds_start<-d_kurt_list(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d)
# 
#     var_ds_rm<-allds_start[seq(from=vardvalueindices1, to=vardvalueindices2, by=2)]
# 
#     varSWAall<-unlist(c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var))
# 
#     rvarall<-var_ds_rm*varSWAall+varSWAall-var_ds_rm*SWAvar[length(SWAvar)]
# 
#     fmSWAall<-c(SWAfm[2:(length(SWAfm)-1)],SWHLM_fm)
# 
#     fm_ds_rm<-allds_start[seq(from=fmdvalueindices1, to=fmdvalueindices2, by=2)]
# 
#     rfmall<-fm_ds_rm*fmSWAall+fmSWAall-fm_ds_rm*SWAfm[length(SWAfm)]
#     kurtfunction<- function(x, y) {
#       return(x /(y^2))
#     }
#     rkurtall <- t(outer(as.numeric(rfmall), as.numeric(rvarall), FUN =kurtfunction))
# 
#     var_ds_qm<-allds_start[seq(from=vardvalueindices1+1, to=vardvalueindices2, by=2)]
# 
#     CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)
# 
#     fm_ds_qm<-allds_start[seq(from=fmdvalueindices1+1, to=fmdvalueindices2, by=2)]
# 
#     CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWHLM_fm)
# 
#     qvarall<-c()
#     for(i in (1:length(CDF_varSWAall))){
#       qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=var_ds_qm[i],sorted=TRUE,beNA=TRUE))
#     }
#     names(qvarall)<-names(CDF_varSWAall)
#     qvarall<-unlist(qvarall)
# 
#     qfmall<-c()
#     for(i in (1:length(CDF_fmSWAall))){
#       qfmall<-c(qfmall,mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[i],dqm=fm_ds_qm[i],sorted=TRUE,beNA=TRUE))
#     }
#     names(qfmall)<-names(CDF_fmSWAall)
# 
#     qkurtall <- t(outer(as.numeric(qfmall), as.numeric(qvarall), FUN =kurtfunction))
#     c(rkurtall=rkurtall,qkurtall=qkurtall)
#   }
# 
#   ikurt1 <- 18
# 
#   Kappa1<-function(kurt1){
#     rqkurtall<-rqkurtsall1(start_kurt=kurt1)
# 
#     Ikurt1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=kurt1,Ilist=IkurtI_values)
# 
#     if(typeof(Ikurt1)=="list"){
#       na_cols <- which(is.na(rqkurtall))
#       Ikurt1$I1[5:ikurtendindex][na_cols]<-NA
#       Ikurt1$I2[5:ikurtendindex][na_cols]<-NA
#       ikurt11<-rqkurtall[which.min(Ikurt1$I1[5:ikurtendindex])]
#       ikurt12<-rqkurtall[which.min(Ikurt1$I2[5:ikurtendindex])]
#       if(ikurt11==ikurt12){
#         ikurt110<-ikurt12
#       }else{
#         ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
#       }
#     }else{
#       na_cols <- which(is.na(rqkurtall))
#       Ikurt1[5:ikurtendindex][na_cols]<-NA
#       ikurt110<-rqkurtall[which.min(Ikurt1[5:ikurtendindex])]
#     }
# 
#     ikurt110
#   }
# 
#   step1 <- 0
# 
#   repeat {
#     step1 <- step1 + 1
# 
#     ikurt2 <- Kappa1(ikurt1)
# 
#     if ((abs(ikurt1 - ikurt2)) < criterion || (step1 == stepsize)) {
#       if((step1 == stepsize)) {
#         print(stepsize)
#       }
#       break
#     }
# 
#     ikurt1<-ikurt2
#   }
# 
#   rqskewsall1<-function(start_skew){
# 
#     allds_start<-d_skew_list(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d)
# 
#     var_ds_rm<-allds_start[seq(from=vardvalueindices1, to=vardvalueindices2, by=2)]
# 
#     varSWAall<-c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var)
# 
#     rvarall<-var_ds_rm*varSWAall+varSWAall-var_ds_rm*SWAvar[length(SWAvar)]
# 
#     var_ds_qm<-allds_start[seq(from=vardvalueindices1+1, to=vardvalueindices2, by=2)]
# 
#     CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)
# 
#     qvarall<-c()
#     for(i in (1:length(CDF_varSWAall))){
#       qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=var_ds_qm[i],sorted=TRUE,beNA=TRUE))
#     }
#     names(qvarall)<-names(CDF_varSWAall)
#     qvarall<-unlist(qvarall)
# 
#     tm_ds_rm<-allds_start[seq(from=tmdvalueindices1, to=tmdvalueindices2, by=2)]
# 
#     tmSWAall<-c(SWAtm[2:(length(SWAtm)-1)],SWHLM_tm)
# 
#     rtmall<-tm_ds_rm*tmSWAall+tmSWAall-tm_ds_rm*SWAtm[length(SWAtm)]
# 
#     skewfunction<- function(x, y) {
#       return(x /(y^(3/2)))
#     }
#     rskewall <- t(outer(as.numeric(rtmall), as.numeric(rvarall), FUN =skewfunction))
# 
#     tm_ds_qm<-allds_start[seq(from=tmdvalueindices1+1, to=tmdvalueindices2, by=2)]
# 
#     CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWHLM_tm)
# 
#     qtmall<-c()
#     for(i in (1:length(CDF_tmSWAall))){
#       qtmall<-c(qtmall,mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[i],dqm=tm_ds_qm[i],sorted=TRUE,beNA=TRUE))
#     }
#     names(qtmall)<-names(CDF_tmSWAall)
# 
#     qskewall <- t(outer(as.numeric(qtmall), as.numeric(qvarall), FUN =skewfunction))
# 
#     c(rskewall=rskewall,qskewall=qskewall)
#   }
# 
#   Skew1_SE<-function(start_skew1,ikurt1=NA){
#     rqskewall1<-rqskewsall1(start_skew=start_skew1)
#     if(Iskewtype1!=5){
#       Iskew1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=start_skew1,Ilist=IskewI_values)
#     }else{
#       Iskew1<-I_adjust_kurt(size=lengthx,dtype=Iskewtype1,kurt1=ikurt1,Ilist=IskewI_values)
#     }
# 
#     if(typeof(Iskew1)=="list"){
#       na_cols <- which(is.na(rqskewall1))
#       Iskew1$I1[5:iskewendindex2][na_cols]<-NA
#       Iskew1$I2[5:iskewendindex2][na_cols]<-NA
#       iskew11<-rqskewall1[which.min(Iskew1$I1[5:iskewendindex2])]
#       iskew12<-rqskewall1[which.min(Iskew1$I2[5:iskewendindex2])]
#       if(iskew11==iskew12){
#         iskew110<-iskew12
#       }else{
#         iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
#       }
#     }else{
#       na_cols <- which(is.na(rqskewall1))
#       Iskew1[5:iskewendindex2][na_cols]<-NA
#       iskew110<-rqskewall1[which.min(Iskew1[5:iskewendindex2])]
#     }
# 
#     iskew110
#   }
# 
#   iskew1<-3.68
# 
#   step1 <- 0
# 
#   repeat {
#     step1 <-step1 + 1
# 
#     iskew2<-Skew1_SE(iskew1,ikurt1=ikurt1)
# 
#     if ((abs(iskew1-iskew2))<criterion || (step1 == stepsize)){
# 
#       break
#     }
#     iskew1<-iskew2
#   }
#   iskew1<-as.numeric(iskew1)
# 
# 
#   kurt1=18
#   skew1=2.67
#   rkurtall_Weibull<-calculate_rkurtall(startkurt=kurt1,nrows=length(varSWAall),ncols=length(fmSWAall),varSWAall,fmSWAall,SWAvar,SWAfm,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,criterion,stepsize)
# 
#   qkurtall_Weibull<-calculate_qkurtall(startkurt=kurt1,nrows=length(CDF_varSWAall),ncols=length(CDF_fmSWAall), lengthx, dtype1, standist_d, vardvalueindices1, fmdvalueindices1, dp2varx, percentage, CDF_varSWAall, dp4fmx, CDF_fmSWAall, criterion, stepsize)
# 
#   rskewall_Weibull<-calculate_rskewall(start_skew=skew1,nrows=length(varSWAall),ncols=length(tmSWAall), lengthx, dtype1, standist_d, vardvalueindices1, tmdvalueindices1, varSWAall, SWAvar, tmSWAall, SWAtm, criterion, stepsize)
# 
#   qskewall_Weibull<-calculate_qskewall(start_skew=skew1,nrows=length(CDF_varSWAall),ncols=length(CDF_tmSWAall), lengthx, dtype1, standist_d, vardvalueindices1, tmdvalueindices1, CDF_varSWAall, CDF_tmSWAall, dp2varx, dp3tmx, percentage, criterion, stepsize)
# 
#   ikurtselect_Weibull<-unlist(c(rkurtall_Weibull=rkurtall_Weibull,qkurtall_Weibull=qkurtall_Weibull))
#   iskewselect_Weibull<-unlist(c(rskewall_Weibull=rskewall_Weibull,qskewall_Weibull=qskewall_Weibull))
# 
#   #Weibull
# 
#   ikurt0<-18
# 
#   iskew0<-2.67
# 
#   IkurtI_values<-standist_I[,c(1:4,733:1460)]
#   IskewI_values<-standist_I[,c(1:4,(2500+1):3540)]
#   ikurtendindex2<-732
#   iskewendindex2<-1044
#   Kappa1_SE<-function(kurt1){
# 
#     Ikurt1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=kurt1,Ilist=IkurtI_values)
# 
#     if(typeof(Ikurt1)=="list"){
#       na_cols <- which(is.na(ikurtselect_Weibull))
#       Ikurt1$I1[5:ikurtendindex2][na_cols]<-NA
#       Ikurt1$I2[5:ikurtendindex2][na_cols]<-NA
#       ikurt11<-ikurtselect_Weibull[which.min(Ikurt1$I1[5:ikurtendindex2])]
#       ikurt12<-ikurtselect_Weibull[which.min(Ikurt1$I2[5:ikurtendindex2])]
#       if(ikurt11==ikurt12){
#         ikurt110<-ikurt12
#       }else{
#         ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
#       }
#     }else{
#       na_cols <- which(is.na(ikurtselect_Weibull))
#       Ikurt1[5:ikurtendindex2][na_cols]<-NA
#       ikurt110<-ikurtselect_Weibull[which.min(Ikurt1[5:ikurtendindex2])]
#     }
# 
#     ikurt110
#   }
#   step1 <- 0
# 
#   repeat {
#     step1 <-step1 + 1
# 
#     ikurt2<-Kappa1_SE(ikurt0)
# 
#     if ((abs(ikurt0-ikurt2))<criterion || (step1 == stepsize)){
# 
#       break
#     }
#     ikurt0<-ikurt2
#   }
#   ikurt0<-as.numeric(ikurt0)
#   Skew1_SE<-function(start_skew1,ikurt1=NA){
#     if(Iskewtype1!=5){
#       Iskew1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=start_skew1,Ilist=IskewI_values)
#     }else{
#       Iskew1<-I_adjust_kurt(size=lengthx,dtype=Iskewtype1,kurt1=ikurt1,Ilist=IskewI_values)
#     }
#     if(typeof(Iskew1)=="list"){
#       na_cols <- which(is.na(iskewselect_Weibull))
#       Iskew1$I1[5:iskewendindex2][na_cols]<-NA
#       Iskew1$I2[5:iskewendindex2][na_cols]<-NA
#       iskew11<-iskewselect_Weibull[which.min(Iskew1$I1[5:iskewendindex2])]
#       iskew12<-iskewselect_Weibull[which.min(Iskew1$I2[5:iskewendindex2])]
#       if(iskew11==iskew12){
#         iskew110<-iskew12
#       }else{
#         iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
#       }
#     }else{
#       na_cols <- which(is.na(iskewselect_Weibull))
#       Iskew1[5:iskewendindex2][na_cols]<-NA
#       iskew110<-iskewselect_Weibull[which.min(Iskew1[5:iskewendindex2])]
#     }
#     iskew110
#   }
# 
#   step1 <- 0
# 
#   repeat {
#     step1 <-step1 + 1
# 
#     iskew2<-Skew1_SE(iskew0,ikurt1=ikurt0)
# 
#     if ((abs(iskew0-iskew2))<criterion || (step1 == stepsize)){
# 
#       break
#     }
#     iskew0<-iskew2
#   }
#   iskew0<-as.numeric(iskew0)
# 
# 
#   ikurtselect_Weibull2<-unlist(c(ikurt1=ikurt1,ikurt2=ikurt0))
#   iskewselect_Weibull2<-unlist(c(iskew1=iskew1,iskew2=iskew0))
# 
#   #Weibull
# 
#   ikurt0<-max(standist_Ismoments[,3])
# 
#   iskew0<-max(standist_Ismoments[,4])
# 
#   IkurtI_values<-standist_Ismoments[,c(1:4,5,6)]
#   IskewI_values<-standist_Ismoments[,c(1:4,7,8)]
#   ikurtendindex2<-6
#   iskewendindex2<-6
#   Kappa1_SE<-function(kurt1){
# 
#     Ikurt1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=kurt1,Ilist=IkurtI_values)
# 
#     if(typeof(Ikurt1)=="list"){
#       na_cols <- which(is.na(ikurtselect_Weibull2))
#       Ikurt1$I1[5:ikurtendindex2][na_cols]<-NA
#       Ikurt1$I2[5:ikurtendindex2][na_cols]<-NA
#       ikurt11<-ikurtselect_Weibull2[which.min(Ikurt1$I1[5:ikurtendindex2])]
#       ikurt12<-ikurtselect_Weibull2[which.min(Ikurt1$I2[5:ikurtendindex2])]
#       if(ikurt11==ikurt12){
#         ikurt110<-ikurt12
#       }else{
#         ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
#       }
#     }else{
#       na_cols <- which(is.na(ikurtselect_Weibull2))
#       Ikurt1[5:ikurtendindex2][na_cols]<-NA
#       ikurt110<-ikurtselect_Weibull2[which.min(Ikurt1[5:ikurtendindex2])]
#     }
# 
#     ikurt110
#   }
#   step1 <- 0
# 
#   repeat {
#     step1 <-step1 + 1
# 
#     ikurt2<-Kappa1_SE(ikurt0)
# 
#     if ((abs(ikurt0-ikurt2))<criterion || (step1 == stepsize)){
# 
#       break
#     }
#     ikurt0<-ikurt2
#   }
#   ikurt0<-as.numeric(ikurt0)
#   Skew1_SE<-function(start_skew1,ikurt1=NA){
#     if(Iskewtype1!=5){
#       Iskew1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=start_skew1,Ilist=IskewI_values)
#     }else{
#       Iskew1<-I_adjust_kurt(size=lengthx,dtype=Iskewtype1,kurt1=ikurt1,Ilist=IskewI_values)
#     }
#     if(typeof(Iskew1)=="list"){
#       na_cols <- which(is.na(iskewselect_Weibull2))
#       Iskew1$I1[5:iskewendindex2][na_cols]<-NA
#       Iskew1$I2[5:iskewendindex2][na_cols]<-NA
#       iskew11<-iskewselect_Weibull2[which.min(Iskew1$I1[5:iskewendindex2])]
#       iskew12<-iskewselect_Weibull2[which.min(Iskew1$I2[5:iskewendindex2])]
#       if(iskew11==iskew12){
#         iskew110<-iskew12
#       }else{
#         iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
#       }
#     }else{
#       na_cols <- which(is.na(iskewselect_Weibull2))
#       Iskew1[5:iskewendindex2][na_cols]<-NA
#       iskew110<-iskewselect_Weibull2[which.min(Iskew1[5:iskewendindex2])]
#     }
#     iskew110
#   }
# 
#   step1 <- 0
# 
#   repeat {
#     step1 <-step1 + 1
# 
#     iskew2<-Skew1_SE(iskew0,ikurt1=ikurt0)
# 
#     if ((abs(iskew0-iskew2))<criterion || (step1 == stepsize)){
# 
#       break
#     }
#     iskew0<-iskew2
#   }
#   iskew0<-as.numeric(iskew0)
# 
#   ikurtselect_Weibullq<-Rfast::Sort(x=ikurtselect_Weibull,descending=FALSE,na.last=TRUE)
#   ikurtselect_Weibullq<-na.omit(ikurtselect_Weibullq)
#   iskewselect_Weibullq<-Rfast::Sort(x=iskewselect_Weibull,descending=FALSE,partial=NULL,stable=FALSE,na.last=TRUE)
#   iskewselect_Weibullq<-na.omit(iskewselect_Weibullq)
# 
#   ikurt11<-quantilefunction(x=ikurtselect_Weibullq,quatiletarget=1/5,sorted=TRUE)
#   ikurt22<-quantilefunction(x=ikurtselect_Weibullq,quatiletarget=4/5,sorted=TRUE)
#   iskew11<-quantilefunction(x=iskewselect_Weibullq,quatiletarget=1/5,sorted=TRUE)
#   iskew22<-quantilefunction(x=iskewselect_Weibullq,quatiletarget=4/5,sorted=TRUE)
# 
#   iskewall<-seq(from=iskew11,to=iskew22,length.out=10)
#   ikurtall<-seq(from=ikurt11,to=ikurt22,length.out=10)

  # rqmoments_1<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[1], ikurt0=ikurtall[1], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_2<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[2], ikurt0=ikurtall[2], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_3<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[3], ikurt0=ikurtall[3], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_4<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[4], ikurt0=ikurtall[4], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_5<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[5], ikurt0=ikurtall[5], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_6<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[6], ikurt0=ikurtall[6], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_7<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[7], ikurt0=ikurtall[7], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_8<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[8], ikurt0=ikurtall[8], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_9<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[9], ikurt0=ikurtall[9], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  #
  # rqmoments_10<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                  CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[10], ikurt0=ikurtall[10], standist_d, meandvalueindices1, vardvalueindices1,
  #                                  tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  #
  # rqmoments_11<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[11], ikurt0=ikurtall[11], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  #
  # rqmoments_12<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                   CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[12], ikurt0=ikurtall[12], standist_d, meandvalueindices1, vardvalueindices1,
  #                                   tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  #
  #
  # rqselect_Weibull_all <- list()
  # 
  # for (i in 1:10) {
  #   rqselect_Weibull_all[[i]] <- rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                         CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=iskewall[i], ikurt0=ikurtall[i], standist_d, meandvalueindices1, vardvalueindices1,
  #                                         tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # }
  #rqselect_Weibull_all<-c(ikurt0=ikurt0,iskew0=iskew0,unlist(rqselect_Weibull_all))
  # # rqselect_Weibull_all<-unlist(c(ikurt0=ikurt0,iskew0=iskew0,ism1=rqmoments_1,ism2=rqmoments_2,ism3=rqmoments_3,ism4=rqmoments_4,ism5=rqmoments_5,ism6=rqmoments_6,ism7=rqmoments_7,ism8=rqmoments_8,ism9=rqmoments_9,ism10=rqmoments_10,ism11=rqmoments_11,ism12=rqmoments_12))
  # #
  # imeanselect1<-rqselect_Weibull_all[c(3:74,195:266,387:458,579:650,771:842,963:1034,1155:1226,1347:1418,1539:1610,1731:1802,1923:1994,2115:2186)]
  # ivarselect1<-rqselect_Weibull_all[c(75:126,267:318,459:510,651:702,843:894,1035:1086,1227:1278,1419:1470,1611:1662,1803:1854,1995:2046,2187:2238)]
  # itmselect1<-rqselect_Weibull_all[c(127:166,319:358,511:550,703:742,895:934,1087:1126,1279:1318,1471:1510,1663:1702,1855:1894,2047:2086,2239:2278)]
  # ifmselect1<-rqselect_Weibull_all[c(167:194,359:386,551:578,743:770,935:962,1127:1154,1319:1346,1511:1538,1703:1730,1895:1922,2087:2114,2279:2306)]
  # #
  # generate_indices <- function(start, end, step = 192,step2=71) {
  #   indices <- c()
  #   for (i in seq(start, end, step)) {
  #     indices <- c(indices, seq(i, i + step2))
  #   }
  #   return(indices)
  # }
  # #
  # imean_indices <- generate_indices(start=3, end=192*25-1+3-27-39-1-51-1-71-1, step = 192,step2=71)
  # ivar_indices <- generate_indices(start=75, end=192*25-1+3-27-39-1-51-1, step = 192,step2=51)
  # itm_indices <- generate_indices(start=127, end=192*25-1+3-27-39-1, step = 192,step2=39)
  # ifm_indices <- generate_indices(start=167, end=192*25-1+3-27, step = 192,step2=27)
  #
  # imeanselect1 <- rqselect_Weibull_all[imean_indices]
  # ivarselect1 <- rqselect_Weibull_all[ivar_indices]
  # itmselect1 <- rqselect_Weibull_all[itm_indices]
  # ifmselect1 <- rqselect_Weibull_all[ifm_indices]
#
#   ImeanImoments<-standist_Imoments[,c(1:4,5:(length(imean_indices)+4))]
#
#   Imean1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=iskew0,Ilist=ImeanImoments)
#   if(typeof(Imean1)=="list"){
#     if(length(Imean1)==4){
#       na_cols <- which(is.na(imeanselect1))
#       Imean1$I1[5:(length(imean_indices)+4)][na_cols]<-NA
#       Imean1$I2[5:(length(imean_indices)+4)][na_cols]<-NA
#       imean11<-imeanselect1[which.min(Imean1$I1[5:(length(imean_indices)+4)])]
#       imean12<-imeanselect1[which.min(Imean1$I2[5:(length(imean_indices)+4)])]
#       if(imean11==imean12){
#         imean110<-imean12
#       }else{
#         imean110<-(((imean12-imean11)*((iskew0-Imean1$infn2)/(Imean1$supn2-Imean1$infn2)))+imean11)
#       }
#     }else{
#       na_cols <- which(is.na(imeanselect1))
#       Imean1$I11[5:(length(imean_indices)+4)][na_cols]<-NA
#       Imean1$I21[5:(length(imean_indices)+4)][na_cols]<-NA
#       Imean1$I12[5:(length(imean_indices)+4)][na_cols]<-NA
#       Imean1$I22[5:(length(imean_indices)+4)][na_cols]<-NA
#
#       imean111<-imeanselect1[which.min(Imean1$I11[5:(length(imean_indices)+4)])]
#       imean121<-imeanselect1[which.min(Imean1$I21[5:(length(imean_indices)+4)])]
#       imean112<-imeanselect1[which.min(Imean1$I12[5:(length(imean_indices)+4)])]
#       imean122<-imeanselect1[which.min(Imean1$I22[5:(length(imean_indices)+4)])]
#       if(imean121==imean111){
#         imean11a<-imean111
#       }else{
#         imean11a<-(((imean121-imean111)*((iskew0-Imean1$infn2)/(Imean1$supn2-Imean1$infn2)))+imean111)
#       }
#       if(imean122==imean112){
#         imean11b<-imean112
#       }else{
#         imean11b<-(((imean122-imean112)*((iskew0-Imean1$infn3)/(Imean1$supn3-Imean1$infn3)))+imean112)
#       }
#
#       if(imean11a==imean11b){
#         imean110<-imean11a
#       }else{
#         imean110<-(((imean11b-imean11a)*((iskew0-Imean1$infn)/(Imean1$supn-Imean1$infn)))+imean11b)
#       }
#     }
#
#   }else{
#     na_cols <- which(is.na(imeanselect1))
#     Imean1[5:(length(imean_indices)+4)][na_cols]<-NA
#     imean110<-imeanselect1[which.min(Imean1[5:(length(imean_indices)+4)])]
#   }
#
#   IvarImoments<-standist_Imoments[,c(1:4,(length(imean_indices)+5):(length(imean_indices)+length(ivar_indices)+4))]
#
#   Ivar1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=ikurt0,Ilist=IvarImoments)
#   if(typeof(Ivar1)=="list"){
#     if(length(Ivar1)==4){
#       na_cols <- which(is.na(ivarselect1))
#       Ivar1$I1[5:(length(ivar_indices)+4)][na_cols]<-NA
#       Ivar1$I2[5:(length(ivar_indices)+4)][na_cols]<-NA
#       ivar11<-ivarselect1[which.min(Ivar1$I1[5:(length(ivar_indices)+4)])]
#       ivar12<-ivarselect1[which.min(Ivar1$I2[5:(length(ivar_indices)+4)])]
#       if(ivar11==ivar12){
#         ivar110<-ivar12
#       }else{
#         ivar110<-(((ivar12-ivar11)*((ikurt0-Ivar1$infn2)/(Ivar1$supn2-Ivar1$infn2)))+ivar11)
#       }
#     }else{
#       na_cols <- which(is.na(ivarselect1))
#       Ivar1$I11[5:(length(ivar_indices)+4)][na_cols]<-NA
#       Ivar1$I21[5:(length(ivar_indices)+4)][na_cols]<-NA
#       Ivar1$I12[5:(length(ivar_indices)+4)][na_cols]<-NA
#       Ivar1$I22[5:(length(ivar_indices)+4)][na_cols]<-NA
#       ivar111<-ivarselect1[which.min(Ivar1$I11[5:(length(ivar_indices)+4)])]
#       ivar121<-ivarselect1[which.min(Ivar1$I21[5:(length(ivar_indices)+4)])]
#       ivar112<-ivarselect1[which.min(Ivar1$I12[5:(length(ivar_indices)+4)])]
#       ivar122<-ivarselect1[which.min(Ivar1$I22[5:(length(ivar_indices)+4)])]
#       if(ivar121==ivar111){
#         ivar11a<-ivar111
#       }else{
#         ivar11a<-(((ivar121-ivar111)*((ikurt0-Ivar1$infn2)/(Ivar1$supn2-Ivar1$infn2)))+ivar111)
#       }
#       if(ivar122==ivar112){
#         ivar11b<-ivar112
#       }else{
#         ivar11b<-(((ivar122-ivar112)*((ikurt0-Ivar1$infn3)/(Ivar1$supn3-Ivar1$infn3)))+ivar112)
#       }
#
#       if(ivar11a==ivar11b){
#         ivar110<-ivar11a
#       }else{
#         ivar110<-(((ivar11b-ivar11a)*((ikurt0-Ivar1$infn)/(Ivar1$supn-Ivar1$infn)))+ivar11b)
#       }
#     }
#
#   }else{
#     na_cols <- which(is.na(ivarselect1))
#     Ivar1[5:(length(ivar_indices)+4)][na_cols]<-NA
#     ivar110<-ivarselect1[which.min(Ivar1[5:(length(ivar_indices)+4)])]
#   }
#
#   ItmImoments<-standist_Imoments[,c(1:4,(length(imean_indices)+length(ivar_indices)+5):(length(imean_indices)+length(ivar_indices)+length(itm_indices)+4))]
#
#   Itm1<-I_adjust_skew(size=lengthx,dtype=Iskewtype1,skew1=iskew0,Ilist=ItmImoments)
#   if(typeof(Itm1)=="list"){
#     if(length(Itm1)==4){
#       na_cols <- which(is.na(itmselect1))
#       Itm1$I1[5:(length(itm_indices)+4)][na_cols]<-NA
#       Itm1$I2[5:(length(itm_indices)+4)][na_cols]<-NA
#       itm11<-itmselect1[which.min(Itm1$I1[5:(length(itm_indices)+4)])]
#       itm12<-itmselect1[which.min(Itm1$I2[5:(length(itm_indices)+4)])]
#       if(itm11==itm12){
#         itm110<-itm12
#       }else{
#         itm110<-(((itm12-itm11)*((iskew0-Itm1$infn2)/(Itm1$supn2-Itm1$infn2)))+itm11)
#       }
#     }else{
#       na_cols <- which(is.na(itmselect1))
#       Itm1$I11[5:(length(itm_indices)+4)][na_cols]<-NA
#       Itm1$I21[5:(length(itm_indices)+4)][na_cols]<-NA
#       Itm1$I12[5:(length(itm_indices)+4)][na_cols]<-NA
#       Itm1$I22[5:(length(itm_indices)+4)][na_cols]<-NA
#
#       itm111<-itmselect1[which.min(Itm1$I11[5:(length(itm_indices)+4)])]
#       itm121<-itmselect1[which.min(Itm1$I21[5:(length(itm_indices)+4)])]
#       itm112<-itmselect1[which.min(Itm1$I12[5:(length(itm_indices)+4)])]
#       itm122<-itmselect1[which.min(Itm1$I22[5:(length(itm_indices)+4)])]
#       if(itm111==itm121){
#         itm1a<-itm111
#       }else{
#         itm1a<-(((itm121-itm111)*((iskew0-Itm1$infn2)/(Itm1$supn2-Itm1$infn2)))+itm111)
#       }
#       if(itm122==itm112){
#         itm1b<-itm112
#       }else{
#         itm1b<-(((itm122-itm112)*((iskew0-Itm1$infn3)/(Itm1$supn3-Itm1$infn3)))+itm112)
#       }
#
#       if(itm1a==itm1b){
#         itm110<-itm1a
#       }else{
#         itm110<-(((itm1b-itm1a)*((iskew0-Itm1$infn)/(Itm1$supn-Itm1$infn)))+itm1b)
#       }
#     }
#
#   }else{
#     na_cols <- which(is.na(itmselect1))
#     Itm1[5:(length(itm_indices)+4)][na_cols]<-NA
#     itm110<-itmselect1[which.min(Itm1[5:(length(itm_indices)+4)])]
#   }
#
#   IfmImoments<-standist_Imoments[,c(1:4,(length(imean_indices)+length(ivar_indices)+length(itm_indices)+5):(length(imean_indices)+length(ivar_indices)+length(itm_indices)+length(ifm_indices)+4))]
#   Ifm1<-I_adjust_kurt(size=lengthx,dtype=Ikurttype1,kurt1=ikurt0,Ilist=IfmImoments)
#   if(typeof(Ifm1)=="list"){
#
#     if(length(Ifm1)==4){
#       na_cols <- which(is.na(ifmselect1))
#       Ifm1$I1[5:(length(ifm_indices)+4)][na_cols]<-NA
#       Ifm1$I2[5:(length(ifm_indices)+4)][na_cols]<-NA
#       ifm11<-ifmselect1[which.min(Ifm1$I1[5:(length(ifm_indices)+4)])]
#       ifm12<-ifmselect1[which.min(Ifm1$I2[5:(length(ifm_indices)+4)])]
#       if(ifm11==ifm12){
#         ifm110<-ifm12
#       }else{
#         ifm110<-(((ifm12-ifm11)*((ikurt0-Ifm1$infn2)/(Ifm1$supn2-Ifm1$infn2)))+ifm11)
#       }
#     }else{
#       na_cols <- which(is.na(ifmselect1))
#       Ifm1$I11[5:(length(ifm_indices)+4)][na_cols]<-NA
#       Ifm1$I21[5:(length(ifm_indices)+4)][na_cols]<-NA
#       Ifm1$I12[5:(length(ifm_indices)+4)][na_cols]<-NA
#       Ifm1$I22[5:(length(ifm_indices)+4)][na_cols]<-NA
#       ifm111<-ifmselect1[which.min(Ifm1$I11[5:(length(ifm_indices)+4)])]
#       ifm121<-ifmselect1[which.min(Ifm1$I21[5:(length(ifm_indices)+4)])]
#       ifm112<-ifmselect1[which.min(Ifm1$I12[5:(length(ifm_indices)+4)])]
#       ifm122<-ifmselect1[which.min(Ifm1$I22[5:(length(ifm_indices)+4)])]
#       if(ifm121==ifm111){
#         ifm11a<-ifm111
#       }else{
#         ifm11a<-(((ifm121-ifm111)*((ikurt0-Ifm1$infn2)/(Ifm1$supn2-Ifm1$infn2)))+ifm111)
#       }
#       if(ifm122==ifm112){
#         ifm11b<-ifm112
#       }else{
#         ifm11b<-(((ifm122-ifm112)*((ikurt0-Ifm1$infn3)/(Ifm1$supn3-Ifm1$infn3)))+ifm112)
#       }
#
#       if(ifm11a==ifm11b){
#         ifm110<-ifm11a
#       }else{
#         ifm110<-(((ifm11b-ifm11a)*((ikurt0-Ifm1$infn)/(Ifm1$supn-Ifm1$infn)))+ifm11b)
#       }
#     }
#
#   }else{
#     na_cols <- which(is.na(ifmselect1))
#     Ifm1[5:(length(ifm_indices)+4)][na_cols]<-NA
#     ifm110<-ifmselect1[which.min(Ifm1[5:(length(ifm_indices)+4)])]
#   }
#
#   imomentsall<-c(imean=imean110,ivar=ivar110,itm=itm110,ifm=ifm110,iskew=iskew0,ikurt=ikurt0)

#   rqmoments_rSQM<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
#                                       CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=rskewall_Weibull[2,2], ikurt0=rkurtall_Weibull[2,1], standist_d, meandvalueindices1, vardvalueindices1,
#                                       tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
#   rqmoments_qSQM<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
#                                       CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=qskewall_Weibull[2,2], ikurt0=qkurtall_Weibull[2,1], standist_d, meandvalueindices1, vardvalueindices1,
#                                       tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
#
  # rqmoments_rSWHLM4WMkurt_rSWHLM4WMskew<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                                            CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=rskewall_Weibull[21,18], ikurt0=rkurtall_Weibull[18,12], standist_d, meandvalueindices1, vardvalueindices1,
  #                                                            tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  # rqmoments_qSWHLM4WM_qSWHLM4WMskew<-rqmomentsallprocess(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm,
  #                                                        CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0=qskewall_Weibull[21,18], ikurt0=qkurtall_Weibull[18,12], standist_d, meandvalueindices1, vardvalueindices1,
  #                                                        tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx)
  #
  #



  if(releaseall){
    sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))

    finallall<-c(SWA_mean=SWA_mean,
                 SWHLM_mean=SWHLM_mean,
                 CDF_SWA_mean=CDF_SWA_mean,
                 CDF_SWHLM_mean=CDF_SWHLM_mean,
                 SWAvar=SWAvar,
                 SWHLM_var=SWHLM_var,
                 CDF_SWA_var=CDF_SWA_var,
                 CDF_SWHLM_var=CDF_SWHLM_var,
                 SWAtm=SWAtm,
                 SWHLM_tm=SWHLM_tm,
                 CDF_SWA_tm=CDF_SWA_tm,
                 CDF_SWHLM_tm=CDF_SWHLM_tm,
                 SWAfm=SWAfm,
                 SWHLM_fm=SWHLM_fm,
                 CDF_SWA_fm=CDF_SWA_fm,
                 CDF_SWHLM_fm=CDF_SWHLM_fm,
                 sdall=sdall)

    kurtskew1<-c(kurt_U=(SWAfm[1]/(SWAvar[1]^2)),skew_U=(SWAtm[1]/(SWAvar[1]^(3/2))))
    return(c(imomentsall,ikurtselect_Weibull,ikurtselect_Weibull2,iskewselect_Weibull,iskewselect_Weibull2,imeanselect2,ivarselect2,itmselect2,ifmselect2,finallall,kurtskew1))
  }else{
    return(c(imomentsall))
  }
}

rqmomentsallprocess<-function(SWA_mean, SWHLM_mean, SWAvar, SWHLM_var, SWAtm, SWHLM_tm, SWAfm, SWHLM_fm, 
                              CDF_SWA_mean, CDF_SWHLM_mean, CDF_SWA_var, CDF_SWHLM_var, CDF_SWA_tm, CDF_SWHLM_tm, CDF_SWA_fm, CDF_SWHLM_fm, dtype1, iskew0, ikurt0, standist_d, meandvalueindices1, vardvalueindices1, 
                              tmdvalueindices1, fmdvalueindices1, lengthx, percentage, sortedx, dp2varx, dp3tmx, dp4fmx){
  
  meanSWAall<-unlist(c(SWA_mean[2:(length(SWA_mean)-1)],SWHLM_mean))
  median_mean<-SWA_mean[(length(SWA_mean))]
  rmall<-c()
  for (i in 1:length(meanSWAall)) {
    d_rm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew0,dlist=standist_d,etype=meandvalueindices1+i*2-2)
    rmall<-c(rmall,d_rm*meanSWAall[i]+meanSWAall[i]-d_rm*median_mean)
    
  }
  names(rmall)<-names(meanSWAall)
  
  mean_CDF_SWAall<-unlist(c(CDF_SWA_mean,CDF_SWHLM_mean))
  
  qmall<-c()
  for (i in 1:length(mean_CDF_SWAall)) {
    d_qm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew0,dlist=standist_d,etype=meandvalueindices1+i*2-1)
    qmall<-c(qmall,mmmprocessqm(x=sortedx,percentage=percentage,pc1=mean_CDF_SWAall[i],dqm=d_qm,sorted=TRUE,beNA=TRUE))
    
  }
  names(qmall)<-names(mean_CDF_SWAall)
  
  varSWAall<-unlist(c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var))
  median_var<-SWAvar[(length(SWAvar))]
  rvarall<-c()
  for (i in 1:length(varSWAall)) {
    d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt0,dlist=standist_d,etype=vardvalueindices1+i*2-2)
    rvarall<-c(rvarall,d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*median_var)
    
  }
  names(rvarall)<-names(varSWAall)
  
  CDF_varSWAall<-unlist(c(CDF_SWA_var,CDF_SWHLM_var))
  
  qvarall<-c()
  for(i in (1:length(CDF_varSWAall))){
    d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt0,dlist=standist_d,etype=vardvalueindices1+i*2-1)
    qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=TRUE))
  }
  names(qvarall)<-names(CDF_varSWAall)
  
  tmSWAall<-unlist(c(SWAtm[2:(length(SWAtm)-1)],SWHLM_tm))
  median_tm<-SWAtm[(length(SWAtm))]
  rtmall<-c()
  for (i in 1:length(tmSWAall)) {
    d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew0,dlist=standist_d,etype=tmdvalueindices1+i*2-2)
    rtmall<-c(rtmall,d_rtm*tmSWAall[i]+tmSWAall[i]-d_rtm*median_tm)
    
  }
  names(rtmall)<-names(tmSWAall)
  
  CDF_tmSWAall<-unlist(c(CDF_SWA_tm,CDF_SWHLM_tm))
  
  qtmall<-c()
  for (i in 1:length(CDF_tmSWAall)) {
    d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew0,dlist=standist_d,etype=tmdvalueindices1+i*2-1)
    qtmall<-c(qtmall,mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[i],dqm=d_qtm,sorted=TRUE,beNA=TRUE))
    
  }
  names(qtmall)<-names(CDF_tmSWAall)
  
  fmSWAall<-unlist(c(SWAfm[2:(length(SWAfm)-1)],SWHLM_fm))
  median_fm<-SWAfm[(length(SWAfm))]
  rfmall<-c()
  for (i in 1:length(fmSWAall)) {
    d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt0,dlist=standist_d,etype=fmdvalueindices1+i*2-2)
    rfmall<-c(rfmall,d_rfm*fmSWAall[i]+fmSWAall[i]-d_rfm*median_fm)
    
  }
  names(rfmall)<-names(fmSWAall)
  
  CDF_fmSWAall<-unlist(c(CDF_SWA_fm,CDF_SWHLM_fm))
  
  qfmall<-c()
  for(i in (1:length(CDF_fmSWAall))){
    d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt0,dlist=standist_d,etype=fmdvalueindices1+i*2-1)
    qfmall<-c(qfmall,mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[i],dqm=d_qfm,sorted=TRUE,beNA=TRUE))
  }
  names(qfmall)<-names(CDF_fmSWAall)
  
  rqmomentsall<-c(rmall=rmall,
                  qmall=qmall,
                  
                  rvarall=rvarall,
                  qvarall=qvarall,
                  
                  rtmall=rtmall,
                  qtmall=qtmall,
                  
                  rfmall=rfmall,
                  qfmall=qfmall)
  return(rqmomentsall)
}
calculate_rkurtall<-function(startkurt,nrows,ncols,varSWAall,fmSWAall,SWAvar,SWAfm,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,criterion,stepsize){
  nrows <- nrows
  ncols <- ncols
  rkurtall <- matrix(nrow = nrows, ncol = ncols)
  
  for (i in 1:nrows) {
    for (j in 1:ncols) {
      kurt1 <- startkurt
      
      Kappa1rm<-function(kurt1){
        d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vardvalueindices1+i*2-2)
        
        d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmdvalueindices1+j*2-2)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[length(SWAvar)]
        
        rfmall<-d_rfm*fmSWAall[j]+fmSWAall[j]-d_rfm*SWAfm[length(SWAfm)]
        
        rfmall/(rvarall^2)
      }
      
      step1 <- 0
      
      repeat {
        step1 <- step1 + 1
        
        kurt2 <- Kappa1rm(kurt1)
        
        if ((abs(kurt1 - kurt2)) < criterion || (step1 == stepsize)) {
          if((step1 == stepsize)) {
            print(stepsize)
          }
          break
        }
        kurt1<-kurt2
      }
      rkurtall[i, j]<-kurt1
    }
  }
  return(rkurtall)
}

calculate_qkurtall<-function(startkurt,nrows,ncols,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,dp2varx,percentage,CDF_varSWAall,dp4fmx,CDF_fmSWAall,criterion,stepsize){
  nrows <- nrows
  ncols <- ncols
  qkurtall<-matrix(nrow=nrows,ncol=ncols)
  
  for(i in 1:nrows){
    for(j in 1:ncols){
      kurt1<-startkurt
      
      Kappa1qm<-function(kurt1,beNA){
        if(is.na(kurt1)){
          return(NA)
        }
        d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vardvalueindices1+i*2-1)
        d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmdvalueindices1+j*2-1)
        
        qvarall<-mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        qfmall<-mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[j],dqm=d_qfm,sorted=TRUE,beNA=beNA)
        
        return(qfmall/(qvarall^2))
      }
      
      step1<-0
      
      repeat{
        step1<-step1+1
        
        kurt2<-Kappa1qm(kurt1,beNA=FALSE)
        
        if(is.na(kurt2)||(abs(kurt1-kurt2))<criterion||(step1==stepsize)){
          break
        }
        kurt1<-kurt2
      }
      qkurtall[i,j]<-Kappa1qm(kurt1,beNA=TRUE)
    }
  }
  return(qkurtall)
}


calculate_rskewall<-function(start_skew,nrows,ncols,lengthx,dtype1,standist_d,vardvalueindices1,tmdvalueindices1,varSWAall,SWAvar,tmSWAall,SWAtm,criterion,stepsize){
  nrows <- nrows
  ncols <- ncols
  rskewall<-matrix(nrow=nrows,ncol=ncols)
  
  for(i in 1:nrows){
    for(j in 1:ncols){
      skew1<-start_skew
      
      skew1rm<-function(skew1){
        d_rvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vardvalueindices1+i*2-2)
        d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmdvalueindices1+j*2-2)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[length(SWAvar)]
        rtmall<-d_rtm*tmSWAall[j]+tmSWAall[j]-d_rtm*SWAtm[length(SWAtm)]
        return(rtmall/(rvarall^(3/2)))
      }
      step1<-0
      repeat{
        step1<-step1+1
        skew2<-skew1rm(skew1)
        if((abs(skew1-skew2))<criterion||(step1==stepsize)){
          break
        }
        skew1<-skew2
      }
      rskewall[i,j]<-skew1
    }
  }
  return(rskewall)
}

calculate_qskewall<-function(start_skew,nrows,ncols,lengthx,dtype1,standist_d,vardvalueindices1,tmdvalueindices1,CDF_varSWAall,CDF_tmSWAall,dp2varx,dp3tmx,percentage,criterion,stepsize){
  nrows <- nrows
  ncols <- ncols
  qskewall<-matrix(nrow=nrows,ncol=ncols)
  
  for(i in 1:nrows){
    for(j in 1:ncols){
      skew1<-start_skew
      
      skew1qm<-function(skew1,beNA){
        if(is.na(skew1)){
          return(NA)
        }
        d_qvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vardvalueindices1+i*2-1)
        d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmdvalueindices1+j*2-1)
        qvarall<-mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        qtmall<-mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[j],dqm=d_qtm,sorted=TRUE,beNA=beNA)
        return(qtmall/(qvarall^(3/2)))
      }
      
      step1<-0
      repeat{
        step1<-step1+1
        skew2<-skew1qm(skew1,beNA=FALSE)
        if(is.na(skew2)||(abs(skew1-skew2))<criterion||(step1==stepsize)){
          break
        }
        skew1<-skew2
      }
      qskewall[i,j]<-skew1qm(skew1,beNA=TRUE)
    }
  }
  return(qskewall)
}
