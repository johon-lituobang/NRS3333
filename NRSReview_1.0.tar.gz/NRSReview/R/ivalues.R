#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.




mmmprocessrm<-function(SWA,median,drm=0.375){
  rm1<--drm*median+SWA+drm*SWA
  names(rm1)<-NULL
  output1<-c(rm=rm1)
  return(output1)
}

mmmprocessqm<-function(x,percentage,pc1,dqm=0.567,sorted=TRUE,beNA=FALSE){
  if(sorted){
    x<-x
  }else{
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if (pc1==0.5){
    quatiletarget<-0.5
  }else if (pc1>0.5){
    quatiletarget<-pc1+(pc1-0.5)*dqm
  }else{
    pc1<-1-pc1
    quatiletarget<-pc1+(pc1-0.5)*dqm
    quatiletarget<-1-quatiletarget
  }
  upper1<-(1-percentage)
  lower1<-percentage
  if(quatiletarget>upper1){
    if (beNA){
      return(NA)
    }else{
      quatiletarget=upper1
    }
  }else if(quatiletarget<lower1){
    if (beNA){
      return(NA)
    }else{
      quatiletarget=lower1
    }
  }
  qm1<-quantilefunction(x,quatiletarget,sorted=TRUE)
  output1<-c(qm=qm1)
  return(output1)
}


d_kurt_list<-function(size,dtype,kurt1,dlist){
  dlist<-dlist[dlist[,2] == dtype,]
  if(size%in% dlist[,1]){
    if (kurt1%in% dlist[dlist[,1] == size,3]){
      result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,3])
      tryCatch({
        infn2 <- max(rown2[rown2 <= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
        message(custom_warning)
        infn2<<- min(rown2)
      })
      tryCatch({
        supn2 <- min(rown2[rown2 >= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
        message(custom_warning)
        supn2<<-max(rown2)
      })
      
      if(supn2==infn2){
        result1<-dlist[dlist[,1]==size & dlist[,3]==infn2,]
      }else{
        d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,]
        d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,]
        result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )
    
    rown2<-as.numeric(dlist[dlist[,1] == infn,3])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <-sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    if(supn2==infn2){
      da<-dlist[dlist[,1]==infn & dlist[,3]==infn2,]
    }else{
      d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,]
      d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,]
      
      da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
    
    rown2<-as.numeric(dlist[dlist[,1] == supn,3])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    
    if(supn2==infn2){
      db<-dlist[dlist[,1]==supn & dlist[,3]==infn2,]
    }else{
      d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,]
      d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,]
      
      db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
    if(supn==infn){
      result1<-db
    }else{
    result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}

        
calculate_rkurtall<-function(startkurt,rkurtall_exp,varSWAall,fmSWAall,SWAvar,SWAfm,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,criterion,stepsize){
  nrows <- nrow(rkurtall_exp)
  ncols <- ncol(rkurtall_exp)
  rkurtall <- matrix(nrow = nrows, ncol = ncols)
  
  for (i in 1:nrows) {
    for (j in 1:ncols) {
      kurt1 <- startkurt
      
      Kappa1rm<-function(kurt1){
        d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vardvalueindices1+i*2-2)
        
        d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmdvalueindices1+j*2-2)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[length(SWAvar)]
        
        rfmall<-d_rfm*fmSWAall[j]+fmSWAall[j]-d_rfm*SWAfm[length(SWAfm)]
        
        rfmall/(rvarall^2)
      }
      
      step1 <- 0
      
      repeat {
        step1 <- step1 + 1
        
        kurt2 <- Kappa1rm(kurt1)
        
        if ((abs(kurt1 - kurt2)) < criterion || (step1 == stepsize)) {
          if((step1 == stepsize)) {
            print(stepsize)
          }
          break
        }
        kurt1<-kurt2
      }
      rkurtall[i, j]<-kurt1
    }
  }
  return(rkurtall)
}

calculate_qkurtall<-function(startkurt,qkurtall_exp,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,dp2varx,percentage,CDF_varSWAall,dp4fmx,CDF_fmSWAall,criterion,stepsize){
  nrows<-nrow(qkurtall_exp)
  ncols<-ncol(qkurtall_exp)
  qkurtall<-matrix(nrow=nrows,ncol=ncols)
  
  for(i in 1:nrows){
    for(j in 1:ncols){
      kurt1<-startkurt
      
      Kappa1qm<-function(kurt1,beNA){
        if(is.na(kurt1)){
          return(NA)
        }
        d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vardvalueindices1+i*2-1)
        d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmdvalueindices1+j*2-1)
        
        qvarall<-mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        qfmall<-mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[j],dqm=d_qfm,sorted=TRUE,beNA=beNA)
        
        return(qfmall/(qvarall^2))
      }
      
      step1<-0
      
      repeat{
        step1<-step1+1
        
        kurt2<-Kappa1qm(kurt1,beNA=FALSE)
        
        if(is.na(kurt2)||(abs(kurt1-kurt2))<criterion||(step1==stepsize)){
          break
        }
        kurt1<-kurt2
      }
      
      qkurtall[i,j]<-Kappa1qm(kurt1,beNA=TRUE)
    }
  }
  
  return(qkurtall)
}


calculate_rskewall<-function(start_skew,rskewall_exp,lengthx,dtype1,standist_d,vardvalueindices1,tmdvalueindices1,varSWAall,SWAvar,tmSWAall,SWAtm,criterion,stepsize){
  nrows<-nrow(rskewall_exp)
  ncols<-ncol(rskewall_exp)
  rskewall<-matrix(nrow=nrows,ncol=ncols)
  
  for(i in 1:nrows){
    for(j in 1:ncols){
      skew1<-start_skew
      
      skew1rm<-function(skew1){
        d_rvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vardvalueindices1+i*2-2)
        d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmdvalueindices1+j*2-2)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[length(SWAvar)]
        rtmall<-d_rtm*tmSWAall[j]+tmSWAall[j]-d_rtm*SWAtm[length(SWAtm)]
        return(rtmall/(rvarall^(3/2)))
      }
      step1<-0
      repeat{
        step1<-step1+1
        skew2<-skew1rm(skew1)
        if((abs(skew1-skew2))<criterion||(step1==stepsize)){
          break
        }
        skew1<-skew2
      }
      rskewall[i,j]<-skew1
    }
  }
  return(rskewall)
}

calculate_qskewall<-function(start_skew,qskewall_exp,lengthx,dtype1,standist_d,vardvalueindices1,tmdvalueindices1,CDF_varSWAall,CDF_tmSWAall,dp2varx,dp3tmx,percentage,criterion,stepsize){
  nrows<-nrow(qskewall_exp)
  ncols<-ncol(qskewall_exp)
  qskewall<-matrix(nrow=nrows,ncol=ncols)
  
  for(i in 1:nrows){
    for(j in 1:ncols){
      skew1<-start_skew
      
      skew1qm<-function(skew1,beNA){
        if(is.na(skew1)){
          return(NA)
        }
        d_qvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vardvalueindices1+i*2-1)
        d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmdvalueindices1+j*2-1)
        qvarall<-mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        qtmall<-mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[j],dqm=d_qtm,sorted=TRUE,beNA=beNA)
        return(qtmall/(qvarall^(3/2)))
      }
      
      step1<-0
      repeat{
        step1<-step1+1
        skew2<-skew1qm(skew1,beNA=FALSE)
        if(is.na(skew2)||(abs(skew1-skew2))<criterion||(step1==stepsize)){
          break
        }
        skew1<-skew2
      }
      qskewall[i,j]<-skew1qm(skew1,beNA=TRUE)
    }
  }
  return(qskewall)
}



rqsmoments<-function (x,dtype1=1,releaseall=FALSE,standist_d=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_hlsmall=NULL,orderlist1_hllarge=NULL,percentage=1/24,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  x<-c()
  lengthx<-length(sortedx)
  if(is.null(standist_d)){
    data(d_values)
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }
  max_dim=6
  
  SWA_mean<-SWA(x=sortedx,percentage=percentage,batch=batch,sorted=TRUE,rand = TRUE)
  
  SWHLM_mean<-SWHLM(x=sortedx,max_dim=max_dim,orderlists=orderlist1_hlsmall,percentage=percentage,batch=batch,boot=TRUE)
  SWHLM_mean<-unlist(lapply(SWHLM_mean, remove_first))
  orderlist1_hlsmall<-c()
  orderlist1_sorted20<-c()
  orderlist1_sorted30<-c()
  orderlist1_sorted40<-c()
  
  CDF_SWA_mean <- sapply(SWA_mean[2:(length(SWA_mean)-1)], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_mean) <- paste0("pc_mean", names(SWA_mean)[2:(length(SWA_mean)-1)])
  
  CDF_SWHLM_mean <- sapply(SWHLM_mean, function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_mean) <- paste0("pc_mean", names(SWHLM_mean))
  
  SWAvar<-SWA(x=dp2varx,percentage=1-(1-percentage)^2,batch="auto",sorted=TRUE)
  
  SWHLM_var<-SWHLM(x=dp2varx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^2,batch=batch,boot=TRUE)
  SWHLM_var<-(lapply(SWHLM_var, remove_first))
  SWHLM_var<-unlist(SWHLM_var)
  
  CDF_SWA_var <- sapply(SWAvar[2:(length(SWAvar)-1)], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_var) <- paste0("pc_var", names(SWAvar)[2:(length(SWAvar)-1)])
  
  CDF_SWHLM_var <- sapply(SWHLM_var, function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_var) <- paste0("pc_var", names(SWHLM_var))
  
  SWAtm<-SWA(x=dp3tmx,percentage=1-(1-percentage)^3,batch="auto",sorted=TRUE)
  
  SWHLM_tm<-SWHLM(x=dp3tmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^3,batch=batch,boot=TRUE)
  SWHLM_tm<-(lapply(SWHLM_tm, remove_first))
  SWHLM_tm<-unlist(SWHLM_tm)
  
  CDF_SWA_tm <- sapply(SWHLM_tm[2:(length(SWAtm)-1)], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_tm) <- paste0("pc_tm", names(SWAtm)[2:(length(SWAtm)-1)])
  
  CDF_SWHLM_tm <- sapply(SWHLM_tm, function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_tm) <- paste0("pc_tm", names(SWHLM_tm))

  SWAfm<-SWA(x=dp4fmx,percentage=1-(1-percentage)^4,batch="auto",sorted=TRUE)
  SWHLM_fm<-SWHLM(x=dp4fmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^4,batch=batch,boot=TRUE)
  SWHLM_fm<-(lapply(SWHLM_fm, remove_first))
  SWHLM_fm<-unlist(SWHLM_fm)
  orderlist1_hllarge<-c()
  CDF_SWA_fm <- sapply(SWAfm[2:(length(SWAfm)-1)], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_fm) <- paste0("pc_fm", names(SWAfm)[2:(length(SWAfm)-1)])
  
  CDF_SWHLM_fm <- sapply(SWHLM_fm, function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWHLM_fm) <- paste0("pc_fm", names(SWHLM_fm))
  
  #exp_rm
  start_kurt=9
  start_skew=2
  
  allds_start<-d_kurt_list(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d)
  
  vardvalueindices1<-77
  vardvalueindices2<-128
  fmdvalueindices1<-169
  fmdvalueindices2<-196
  
  var_ds_rm<-allds_start[seq(from=vardvalueindices1, to=vardvalueindices2, by=2)]
  
  varSWAall<-c(SWAvar[2:(length(SWAvar)-1)],SWHLM_var)
  
  rvarall_exp<-var_ds_rm*varSWAall+varSWAall-var_ds_rm*SWAvar[length(SWAvar)]
  
  fmSWAall<-c(SWAfm[2:(length(SWAfm)-1)],SWHLM_fm)
  
  fm_ds_rm<-allds_start[seq(from=fmdvalueindices1, to=fmdvalueindices2, by=2)]
  
  rfmall_exp<-fm_ds_rm*fmSWAall+fmSWAall-fm_ds_rm*SWAfm[length(SWAfm)]
  kurtfunction<- function(x, y) {
    return(x /(y^2))
  }
  rkurtall_exp <- t(outer(as.numeric(rfmall_exp), as.numeric(rvarall_exp), FUN =kurtfunction))
  
  #Weibull_rm
  kurt1<-26
  
  skew1<-3.68
  rkurtall_Weibull<-calculate_rkurtall(startkurt=kurt1,rkurtall_exp,varSWAall,fmSWAall,SWAvar,SWAfm,lengthx,dtype1,standist_d,vardvalueindices1,fmdvalueindices1,criterion,stepsize)
  
  #exp_qm
  
  var_ds_qm<-allds_start[seq(from=vardvalueindices1+1, to=vardvalueindices2, by=2)]
  
  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWHLM_var)
  
  fm_ds_qm<-allds_start[seq(from=fmdvalueindices1+1, to=fmdvalueindices2, by=2)]
  
  CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWHLM_fm)
  
  qvarall_exp<-c()
  for(i in (1:length(CDF_varSWAall))){
    qvarall_exp<-c(qvarall_exp,mmmprocessqm(x=dp2varx,percentage=1-(1-percentage)^2,pc1=CDF_varSWAall[i],dqm=var_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qvarall_exp)<-names(CDF_varSWAall)
  qvarall_exp<-unlist(qvarall_exp)

  qfmall_exp<-c()
  for(i in (1:length(CDF_fmSWAall))){
    qfmall_exp<-c(qfmall_exp,mmmprocessqm(x=dp4fmx,percentage=1-(1-percentage)^4,pc1=CDF_fmSWAall[i],dqm=fm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qfmall_exp)<-names(CDF_fmSWAall)
  
  qkurtall_exp <- t(outer(as.numeric(qfmall_exp), as.numeric(qvarall_exp), FUN =kurtfunction))
  
  #Weibull_qm
  kurt1<-26
  
  skew1<-3.68
  
  qkurtall_Weibull <- calculate_qkurtall(startkurt=kurt1,qkurtall_exp, lengthx, dtype1, standist_d, vardvalueindices1, fmdvalueindices1, dp2varx, percentage, CDF_varSWAall, dp4fmx, CDF_fmSWAall, criterion, stepsize) 
  
  #exp_rm

  tmdvalueindices1<-129
  tmdvalueindices2<-168
  
  tm_ds_rm<-allds_start[seq(from=tmdvalueindices1, to=tmdvalueindices2, by=2)]
  
  tmSWAall<-c(SWAtm[2:(length(SWAtm)-1)],SWHLM_tm)
  
  rtmall_exp<-tm_ds_rm*tmSWAall+tmSWAall-tm_ds_rm*SWAtm[length(SWAtm)]
  
  skewfunction<- function(x, y) {
    return(x /(y^(3/2)))
  }
  rskewall_exp <- t(outer(as.numeric(rtmall_exp), as.numeric(rvarall_exp), FUN =skewfunction))

  #Weibull_rm
  kurt1<-26
  
  skew1<-3.68
  
  rskewall_Weibull<-calculate_rskewall(start_skew=skew1,rskewall_exp, lengthx, dtype1, standist_d, vardvalueindices1, tmdvalueindices1, varSWAall, SWAvar, tmSWAall, SWAtm, criterion, stepsize) 
  
  #exp_qm
  start_kurt=9
  start_skew=2

  tm_ds_qm<-allds_start[seq(from=tmdvalueindices1+1, to=tmdvalueindices2, by=2)]
  
  CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWHLM_tm)
  
  qtmall_exp<-c()
  for(i in (1:length(CDF_tmSWAall))){
    qtmall_exp<-c(qtmall_exp,mmmprocessqm(x=dp3tmx,percentage=1-(1-percentage)^3,pc1=CDF_tmSWAall[i],dqm=tm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qtmall_exp)<-names(CDF_tmSWAall)
  
  qskewall_exp <- t(outer(as.numeric(qtmall_exp), as.numeric(qvarall_exp), FUN =kurtfunction))

  
  #Weibull_qm
  kurt1<-26
  
  skew1<-3.68
  
  qskewall_Weibull<-calculate_qskewall(start_skew=skew1,qskewall_exp, lengthx, dtype1, standist_d, vardvalueindices1, tmdvalueindices1, CDF_varSWAall, CDF_tmSWAall, dp2varx, dp3tmx, percentage, criterion, stepsize)
  
  
  start_kurt=9
  start_skew=2
  meandvalueindices1<-5
  meandvalueindices2<-76
  
  mean_ds_rm<-allds_start[seq(from=meandvalueindices1, to=vardvalueindices2, by=2)]
  
  meanSWAall<-c(SWA_mean[2:(length(SWA_mean)-1)],SWHLM_mean)
  
  rmall_exp<-mean_ds_rm*meanSWAall+meanSWAall-mean_ds_rm*SWA_mean[length(SWA_mean)]
  
  start_kurt=9
  start_skew=2
  
  mean_ds_qm<-allds_start[seq(from=meandvalueindices1+1, to=vardvalueindices2, by=2)]
  
  CDF_meanSWAall<-c(CDF_SWA_mean,CDF_SWHLM_mean)
  
  qmall_exp<-c()
  for(i in (1:length(CDF_meanSWAall))){
    qmall_exp<-c(qmall_exp,mmmprocessqm(x=sortedx,percentage=percentage,pc1=CDF_meanSWAall[i],dqm=mean_ds_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qmall_exp)<-names(CDF_meanSWAall)
  qmall_exp<-unlist(qmall_exp)
  
  
  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))
  
  allresults1_exp<-c(rkurtall_exp=rkurtall_exp,qkurtall_exp=qkurtall_exp,rskewall_exp=rskewall_exp,qskewall_exp=qskewall_exp,rmall_exp=rmall_exp,qmall_exp=qmall_exp,rvarall_exp=rvarall_exp,qvarall_exp=qvarall_exp,rtmall_exp=rtmall_exp,qtmall_exp=qtmall_exp,rfmall_exp=rfmall_exp,qfmall_exp=qfmall_exp)
  allresults1_Weibull<-c(rkurtall_Weibull=rkurtall_Weibull,qkurtall_Weibull=qkurtall_Weibull,rskewall_Weibull=rskewall_Weibull,qskewall_Weibull=qskewall_Weibull)
  if(releaseall){
    finallall<-c(SWA_mean=SWA_mean,
                 SWHLM_mean=SWHLM_mean,
                 CDF_SWA_mean=CDF_SWA_mean,
                 CDF_SWHLM_mean=CDF_SWHLM_mean,
                 SWAvar=SWAvar,
                 SWHLM_var=SWHLM_var,
                 CDF_SWA_var=CDF_SWA_var,
                 CDF_SWHLM_var=CDF_SWHLM_var,
                 SWAtm=SWAtm,
                 SWHLM_tm=SWHLM_tm,
                 CDF_SWA_tm=CDF_SWA_tm,
                 CDF_SWHLM_tm=CDF_SWHLM_tm,
                 SWAfm=SWAfm,
                 SWHLM_fm=SWHLM_fm,
                 CDF_SWA_fm=CDF_SWA_fm,
                 CDF_SWHLM_fm=CDF_SWHLM_fm,
                 sdall=sdall)
    return(c(allresults1_Weibull,allresults1_exp,finallall))
  }else{
    return(c(allresults1_Weibull,allresults1_exp))
  }
}



