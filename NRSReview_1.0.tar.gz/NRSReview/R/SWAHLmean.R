#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

SWAHLM_16<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=1/16,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  
  if(lengthx>40 || boot){
    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)
    
    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hlsorted<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3hl3<-hl3apply1(bootstrappedsample3)
    dp3hl3sorted<-Rfast::Sort(x=dp3hl3,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4hl4<-hl4apply1(bootstrappedsample4)
    dp4hl4sorted<-Rfast::Sort(x=dp4hl4,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
    
    
  }
  SWAHLM2_16<-SWA(x=dp2hlsorted,percentage=31/256,blocknumber=9,sorted=TRUE)
  
  SWAHLM3_16<-SWA(x=dp3hl3sorted,percentage=721/4096,blocknumber=5,sorted=TRUE)

  SWAHLM4_16<-SWA(x=dp4hl4sorted,percentage=14911/65536,blocknumber=5,sorted=TRUE)
  
  finallall<-c(SWAHLM2_16=SWAHLM2_16,
               SWAHLM3_16=SWAHLM3_16,SWAHLM4_16=SWAHLM4_16)
  return(c(finallall))
}


SWAHLM_31256<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=31/256,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  
  if(lengthx>40 || boot){
    
    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)
    
    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hlsorted<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3hl3<-hl3apply1(bootstrappedsample3)
    dp3hl3sorted<-Rfast::Sort(x=dp3hl3,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4hl4<-hl4apply1(bootstrappedsample4)
    dp4hl4sorted<-Rfast::Sort(x=dp4hl4,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
    
    
  }
  SWAHLM2_31256<-SWA(x=dp2hlsorted,percentage=14911/65536,blocknumber=5,sorted=TRUE)
  
  SWAHLM3_31256<-SWA(x=dp3hl3sorted,percentage=5386591/16777216,blocknumber=3,sorted=TRUE)
  
  SWAHLM4_31256<-SWA(x=dp4hl4sorted,percentage=1732076671/4294967296,blocknumber=3,sorted=TRUE)
  
  finallall<-c(SWAHLM2_31256=SWAHLM2_31256,
               SWAHLM3_31256=SWAHLM3_31256,SWAHLM4_31256=SWAHLM4_31256)
  return(c(finallall))
}

SWAHLM_741<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=721/4096,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  
  if(lengthx>40 || boot){
    
    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)
    
    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hlsorted<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3hl3<-hl3apply1(bootstrappedsample3)
    dp3hl3sorted<-Rfast::Sort(x=dp3hl3,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
  }
  SWAHLM2_741<-SWA(x=dp2hlsorted,percentage=5386591/16777216,blocknumber=3,sorted=TRUE)
  
  SWAHLM3_741<-SWA(x=dp3hl3sorted,percentage=30276117361/68719476736,blocknumber=3,sorted=TRUE)
  
  finallall<-c(SWAHLM2_741=SWAHLM2_741,
               SWAHLM3_741=SWAHLM3_741)
  return(c(finallall))
}

SWAHLM_312<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=14911/65536,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  
  if(lengthx>40 || boot){
    
    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)
    
    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hlsorted<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
  }
  SWAHLM2_312<-SWA(x=dp2hlsorted,percentage=1732076671/4294967296,blocknumber=3,sorted=TRUE)
  
  finallall<-c(SWAHLM2_312=SWAHLM2_312)
  return(c(finallall))
}

SWAHLmean<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,orderlist1_sorted5=NULL,orderlist1_sorted6=NULL,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hlsorted<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3hl3<-hl3apply1(bootstrappedsample3)
    dp3hl3sorted<-Rfast::Sort(x=dp3hl3,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4hl4<-hl4apply1(bootstrappedsample4)
    dp4hl4sorted<-Rfast::Sort(x=dp4hl4,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
    
    length1<-min(c(length(dp2hl),length(dp3hl3)))
    dp2hl215<-dp2hl[1:round(length1*(1-((2*log(2)-log(3))/(3*log(2)-log(7)))+floor((2*log(2)-log(3))/(3*log(2)-log(7)))))]
    
    dp2hl315<-dp3hl3[(round(length1*(1-((2*log(2)-log(3))/(3*log(2)-log(7)))+floor((2*log(2)-log(3))/(3*log(2)-log(7)))))+1):length1]
    
    dp1215<-c(dp2hl215,dp2hl315)
    dp1215<-Rfast::Sort(x=dp1215,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample5<-bootbatch1(orderlist11 = orderlist1_sorted5,sortedx=sortedx,dimension=5)
    dp4hl5<-hl5apply1(bootstrappedsample5)
    dp4hl5sorted<-Rfast::Sort(x=dp4hl5,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample5<-c()
    
    bootstrappedsample6<-bootbatch1(orderlist11 = orderlist1_sorted6,sortedx=sortedx,dimension=6)
    dp4hl6<-hl6apply1(bootstrappedsample6)
    dp4hl6sorted<-Rfast::Sort(x=dp4hl6,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    
    length2<-min(c(length(dp4hl5),length(dp4hl6)))
    dp2hl519<-dp4hl5[1:round(length2*(1-((log(2))/(3*log(2)-log(7)))+floor((log(2))/(3*log(2)-log(7)))))]
    
    dp2hl619<-dp4hl6[(round(length2*(1-((log(2))/(3*log(2)-log(7)))+floor((log(2))/(3*log(2)-log(7)))))+1):length2]
    
    dp1519<-c(dp2hl519,dp2hl619)
    dp1519<-Rfast::Sort(x=dp1519,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample6<-c()
    
  }

  sq4hl<-c(quantilefunction(x=dp1215,quatiletarget=1/4,sorted=TRUE),quantilefunction(x=dp1215,quatiletarget=3/4,sorted=TRUE))
  mHLM1<-mediansorted(sortedx = dp1519,lengthx = length(dp1519))
  
  thl5<-trimmed_mean(x=dp4hl5sorted,percentage=15961/32768,sorted=TRUE)
  
  whl5<-Winsorized_mean(x=dp4hl5sorted, percentage=15961/32768,sorted=TRUE)
  
  thl28<-trimmed_mean(x=dp2hlsorted,percentage=15/64,sorted=TRUE)
  
  whl28<-Winsorized_mean(x=dp2hlsorted, percentage=15/64,sorted=TRUE)
  bwhl28<-Block_Winsorized_mean(x=dp2hlsorted, percentage=15/64,sorted=TRUE)
  
  thl38<-trimmed_mean(x=dp2hlsorted,percentage=169/512,sorted=TRUE)
  
  whl38<-Winsorized_mean(x=dp2hlsorted, percentage=169/512,sorted=TRUE)

  thl48<-trimmed_mean(x=dp2hlsorted,percentage=1695/4096,sorted=TRUE)
  
  whl48<-Winsorized_mean(x=dp2hlsorted, percentage=1695/4096,sorted=TRUE)

  sq4hl2<-c(quantilefunction(x=dp2hlsorted,quatiletarget=1/4,sorted=TRUE),quantilefunction(x=dp2hlsorted,quatiletarget=3/4,sorted=TRUE))
  
  hl<-SWA(x=dp2hlsorted,percentage=1/8,blocknumber=8,batch=batch,sorted=TRUE,rand=TRUE)
  
  hl3<-SWA(x=dp3hl3sorted,percentage=1/8,blocknumber=8,batch=batch,sorted=TRUE,rand=TRUE)
  
  hl4<-SWA(x=dp4hl4sorted,percentage=1/8,blocknumber=8,batch=batch,sorted=TRUE,rand=TRUE)
  
  hl5<-SWA(x=dp4hl5sorted,percentage=1/8,blocknumber=8,batch=batch,sorted=TRUE,rand=TRUE)
  hl6<-SWA(x=dp4hl6sorted,percentage=1/8,blocknumber=8,batch=batch,sorted=TRUE,rand=TRUE)
  
  finallall<-c(MHHLM8=sum(sq4hl)/2,
               mHLM8=mHLM1,THLM58=thl5,WHLM58=whl5,THLM48=thl48,WHLM48=whl48,THLM38=thl38,WHLM38=whl38,THLM28=thl28,BWHLM28=bwhl28,WHLM28=whl28,MHHLM2=sum(sq4hl2)/2,hlSWA=hl,
               hl3SWA=hl3,
               hl4SWA=hl4,
               hl5SWA=hl5,hl6SWA=hl6)
  return(c(finallall))
}


trimmed_mean <- function(x, percentage,sorted=FALSE) {
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n <- length(x_ordered)
  k <- round(n*percentage)
  c(TM=matrixStats::sum2(x_ordered[(k+1):(n-k)])/(n-2*k))
}
Winsorized_mean <- function(x, percentage,sorted=FALSE) {
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n <- length(x_ordered)
  k <- round(n*percentage)
  (WM=(matrixStats::sum2(x_ordered[(k+1):(n-k)])+x_ordered[(k+1)]*k+x_ordered[(n-k)]*k)/(n))
}
Block_Winsorized_mean <- function(x, percentage,sorted=FALSE) {
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n <- length(x_ordered)
  k <- round(n*percentage)
  (BWM=(matrixStats::sum2(x_ordered[(k+1):(n-k)])+matrixStats::sum2(x_ordered[(k+1):(2*k)])+matrixStats::sum2(x_ordered[(n-2*k+1):(n-k)]))/(n))
}
median_of_means <- function(x,korder=2) {
  n_blocks=ceiling(length(x)/korder)
  if (korder <= 1) {
    return(median(x))
  }
  data_mixed <- sample(x)
  index_vec <- rep(1:n_blocks, each = ceiling(length(x) / n_blocks))[1:length(x)]
  data_groups <- split(data_mixed, index_vec)
  block_means <- sapply(data_groups, mean)
  return(c(MoM=median(block_means,na.rm = TRUE)))
}
mHLM<-function(x,orderlist1_sorted=NULL,dimension=4,boot=TRUE,quasi=TRUE,largesize=1.8*10^4){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  lengthx<-length(sortedx)
  if(lengthx>40 ||boot){
    if(!quasi&&is.null(orderlist1_sorted)){
      unibatchran<-matrix(randtoolbox::SFMT(largesize*3*dimension),ncol=dimension)
      uni_sorted <- na.omit(Rfast::rowSort(unibatchran, descend = FALSE, stable = FALSE, parallel = TRUE)) 
      unibatchran<-c()
      orderlist1_sorted<-createorderlist(quni1=uni_sorted,size=lengthx,interval=16,dimension=4)
      orderlist1_sorted<-orderlist1_sorted[1:largesize,]
    }else if(quasi&&is.null(orderlist1_sorted)){
      quasiunisobol_1<-randtoolbox::sobol(n=largesize*3, dim = dimension, init = TRUE, scrambling = 0, seed = NULL, normal = FALSE,
                                      mixed = FALSE, method = "C", start = 1)
      quasiuni_sorted <- na.omit(Rfast::rowSort(quasiunisobol_1, descend = FALSE, stable = FALSE, parallel = TRUE)) 
      orderlist1_sorted<-createorderlist(quni1=quasiuni_sorted,size=lengthx,interval=16,dimension=4)
      orderlist1_sorted<-orderlist1_sorted[1:largesize,]
    }
    
    bootstrappedsample1<-bootbatch1(orderlist11=orderlist1_sorted,sortedx=sortedx,dimension=dimension)
    
    dphlall<-apply_hl(bootstrappedsample1)
    dphlallsorted<-Rfast::Sort(x=dphlall,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample1<-c()
    finallall<-c(mHLM_boot=mediansorted(sortedx=dphlallsorted,lengthx =largesize ))
  }else{
    combinationsample1<-t(as.data.frame(Rfast::comb_n(sortedx,dimension)))
    combinationsample1<-as.matrix(combinationsample1)
    dphlall<-apply_hl(combinationsample1)
    dphlallsorted<-Rfast::Sort(x=dphlall,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    combinationsample1<-c()
    finallall<-c(mHLM=mediansorted(sortedx=dphlallsorted,lengthx =length(dphlallsorted)))
  }
  return(c(finallall))
}
