#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

SWAHLmean<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,orderlist1_sorted5=NULL,interval=8,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)||is.null(orderlist1_sorted5)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      data(quasiuni_5_104)
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_2_104,size=lengthx,interval=8,dimension=2)
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_3_104,size=lengthx,interval=8,dimension=3)
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_4_104,size=lengthx,interval=8,dimension=4)
      orderlist1_sorted5<-createorderlist(quni1=quasiuni_5_104,size=lengthx,interval=8,dimension=5)
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hl<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3hl3<-hl3apply1(bootstrappedsample3)
    dp3hl3<-Rfast::Sort(x=dp3hl3,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4hl4<-hl4apply1(bootstrappedsample4)
    dp4hl4<-Rfast::Sort(x=dp4hl4,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()

    bootstrappedsample5<-bootbatch1(orderlist11 = orderlist1_sorted5,sortedx=sortedx,dimension=5)
    dp4hl5<-hl5apply1(bootstrappedsample5)
    dp4hl5<-Rfast::Sort(x=dp4hl5,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample5<-c()

  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2hl<-hlapply1(combinationsample2)
    dp2hl<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3hl3<-hl3apply1(combinationsample3)
    dp3hl3<-Rfast::Sort(x=dp3hl3,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4hl4<-hl4apply1(combinationsample4)
    dp4hl4<-Rfast::Sort(x=dp4hl4,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

    combinationsample5<-t(as.data.frame(Rfast::comb_n(sortedx,5)))

    dp4hl5<-hl5apply1(combinationsample5)
    dp4hl5<-Rfast::Sort(x=dp4hl5,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample5<-c()

  }

  hl<-SWA(x=dp2hl,interval=interval,batch=batch,sorted=TRUE)

  hl3<-SWA(x=dp3hl3,interval=interval,batch=batch,sorted=TRUE)

  hl4<-SWA(x=dp4hl4,interval=interval,batch=batch,sorted=TRUE)

  hl5<-SWA(x=dp4hl5,interval=interval,batch=batch,sorted=TRUE)

  finallall<-c(hl=hl,
               hl3=hl3,
               hl4=hl4,
               hl5=hl5)
  return(c(finallall))
}

Hodges_Lehmann<-function(x,orderlist1_sorted2=NULL,interval=8,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)){
      data(quasiuni_2_104)

      orderlist1_sorted2<-createorderlist(quni1=quasiuni_2_104,size=lengthx,interval=8,dimension=2)

    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hl<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2hl<-hlapply1(combinationsample2)
    dp2hl<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()
  }
  hl<-SWA(x=dp2hl,interval=interval,batch=batch,sorted=TRUE)
  finallall<-c(hl=hl)
  return(c(finallall))
}

THL<-function(x,orderlist1_sorted2=NULL,interval=4,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  
  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)){
      data(quasiuni_2_104)
      
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_2_104,size=lengthx,interval=8,dimension=2)
      
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)
    
    dp2hl<-hlapply1(bootstrappedsample2)
    dp2hl<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2hl<-hlapply1(combinationsample2)
    dp2hl<-Rfast::Sort(x=dp2hl,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
  }
  thl<-trimmed_mean(x=dp2hl,percentage=1/interval,sorted=TRUE)
  finallall<-c(thl=thl)
  return(c(finallall))
}

trimmed_mean <- function(x, percentage,sorted=FALSE) {
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n <- length(x_ordered)
  k <- round(n*percentage)
  matrixStats::sum2(x_ordered[(k+1):(n-k)])/(n-2*k)
}
