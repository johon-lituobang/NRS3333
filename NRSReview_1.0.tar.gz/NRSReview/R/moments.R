#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


unbiasedmoments<-function (x){
  n<-length(x)
  moments1<-moments(x)
  m1<-moments1$mean
  var1<-moments1$var
  tm1<-moments1$tm
  fm1<-moments1$fm
  var2<-var1*(n/(n-1))
  tm2<-(tm1)*(n^2/((n-1)*(n-2)))
  ufm1<--3*var1^2*(2*n-3)*n/((n-1)*(n-2)*(n-3))+(n^2-2*n+3)*fm1*n/((n-1)*(n-2)*(n-3))
  listall<-c(mean=m1,var=var2,tm=tm2,fm=ufm1)
  (listall)
}
standardizedmoments<-function (x,releaseall=FALSE){
  unbiasedmoments1<-unbiasedmoments(x)
  all1<-c(mean=unbiasedmoments1[1],var=unbiasedmoments1[2],skew=unbiasedmoments1[3]/((unbiasedmoments1[2])^(3/2)),kurt=unbiasedmoments1[4]/((unbiasedmoments1[2])^(2)))
  if(releaseall){
    c(unbiasedmoments1,all1)
  }else{
    (all1)
  }
}

