#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

SWA<-function (x,interval=8,batch="auto",sorted=FALSE){
  if(sorted){
    x<-x
  }else{
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  if (batch=="auto" ){
    batch<-ceiling(500000/lengthx)+1
  }
  if(interval!=8){
    return("interval must be 8 ")
  }
  Ksamples<-lengthx/interval
  IntKsamples<-floor(Ksamples)
  target1<-IntKsamples*interval

  if (Ksamples%%1!=0 ){
    allmatrix<-matrix(sample(x,size=(target1)*batch,replace=FALSE),nrow=batch)
    batchresults<-apply(allmatrix,1,SWAall,IntKsamples=IntKsamples,target1=target1,sorted=FALSE)
    return(matrixStats::rowMeans2(batchresults,useNames=TRUE))
  }
  else{
    Groupmean<-SWAall(x,IntKsamples,target1,sorted=sorted)
    return(Groupmean)}
}

SWA9<-function (x,interval=9,batch="auto",sorted=FALSE){
  if(sorted){
    x<-x
  }else{
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  if (batch=="auto" ){
    batch<-ceiling(500000/lengthx)+1
  }
  if(interval!=9){
    return("interval must be 9 ")
  }
  Ksamples<-lengthx/interval
  IntKsamples<-floor(Ksamples)
  target1<-IntKsamples*interval
  smass<-function(x,IntKsamples,target1,sorted=FALSE){
    if(sorted){
      x_ordered<-x
    }else{
      x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    }
    if ((target1/IntKsamples)==9){
      onelist<-(c(x_ordered[1:(1*(IntKsamples))],x_ordered[(target1-1*IntKsamples+1):(target1)]))
      twolist<-(c(x_ordered[(IntKsamples+1):(2*(IntKsamples))],x_ordered[(target1-2*IntKsamples+1):(target1-IntKsamples)]))
      threelist<-(c(x_ordered[(2*(IntKsamples)+1):(3*(IntKsamples))],x_ordered[(6*(IntKsamples)+1):(target1-2*IntKsamples)]))
      fourlist<-(c(x_ordered[(3*(IntKsamples)+1):(4*(IntKsamples))],x_ordered[(5*(IntKsamples)+1):(target1-3*IntKsamples)]))
      fivelist<-(x_ordered[(4*(IntKsamples)+1):(5*(IntKsamples))])

      sonelist<-sum(onelist)
      stwolist<-sum(twolist)
      sthreelist<-sum(threelist)
      sfourlist<-sum(fourlist)
      sfivelist<-sum(fivelist)

      winsor<-(c(x_ordered[(IntKsamples+1)],x_ordered[((target1-IntKsamples))]))
      winsor1<-sum(winsor)*IntKsamples
      wm1<-(stwolist+sthreelist+sfourlist+sfivelist+winsor1)/(IntKsamples*(9))

      Groupmean<-c(sm=(sfivelist+stwolist)/(IntKsamples*3),wm=wm1)

      return(Groupmean)
    }
    else{
      return("Not supported yet.")
    }
  }
  if (Ksamples%%1!=0 ){
    allmatrix<-matrix(sample(x,size=(target1)*batch,replace=FALSE),nrow=batch)
    batchresults<-apply(allmatrix,1,smass,IntKsamples=IntKsamples,target1=target1,sorted=FALSE)
    return(matrixStats::rowMeans2(batchresults,useNames=TRUE))
  }
  else{
    Groupmean<-smass(x,IntKsamples,target1,sorted=sorted)
    return(Groupmean)}
}
