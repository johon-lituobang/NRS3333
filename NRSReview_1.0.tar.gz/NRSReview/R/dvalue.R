#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


d_adjust_kurt<-function(size,dtype,kurt1,dlist,etype){
  dlist<-dlist[dlist[,2] == dtype,]
  indextypelist<-colnames(dlist)
  indextype<-which(indextypelist==(etype))
  if(size%in% dlist[,1]){
    if (kurt1%in% dlist[dlist[,1] == size,3]){
      result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,indextype]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,3])
      infn2<-max(rown2[rown2 < kurt1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
        #print(c("The kurtosis is out of range supported.",kurt1))
      }
      supn2<-min(rown2[rown2 > kurt1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
        #print(c("The kurtosis is out of range supported.",kurt1))
      }
      d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,indextype]
      d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,indextype]
      if(d1==d2){
        result1<-d1
      }else{
        result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }

    rown2<-as.numeric(dlist[dlist[,1] == infn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,indextype]
    d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,indextype]

    if(d1==d2){
      da<-d1
    }else{
      da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }

    rown2<-as.numeric(dlist[dlist[,1] == supn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,indextype]
    d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,indextype]

    if(d1==d2){
      db<-d1
    }else{
      db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }

    if(da==db){
      result1<-da
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}

d_adjust_skew<-function(size,dtype,skew1,dlist,etype){
  skew1<-abs(skew1)
  dlist<-dlist[dlist[,2] == dtype,]
  indextypelist<-colnames(dlist)
  indextype<-which(indextypelist==(etype))
  if(size%in% dlist[,1]){
    if (skew1%in% dlist[dlist[,1] == size,4]){
      result1<-dlist[dlist[,1] == size & dlist[,4]==skew1,indextype]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,4])
      infn2<-max(rown2[rown2 < skew1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
      }
      supn2<-min(rown2[rown2 > skew1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
      }
      d1<-dlist[dlist[,1]==size & dlist[,4]==infn2,indextype]
      d2<-dlist[dlist[,1]==size & dlist[,4]==supn2,indextype]
      if(d1==d2){
        result1<-d1
      }else{
        result1<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }

    rown2<-as.numeric(dlist[dlist[,1] == infn,4])
    infn2<-max(rown2[rown2 < skew1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > skew1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==infn & dlist[,4]==infn2,indextype]
    d2<-dlist[dlist[,1]==infn & dlist[,4]==supn2,indextype]

    if(d1==d2){
      da<-d1
    }else{
      da<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }

    rown2<-as.numeric(dlist[dlist[,1] == supn,4])
    infn2<-max(rown2[rown2 < skew1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > skew1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==supn & dlist[,4]==infn2,indextype]
    d2<-dlist[dlist[,1]==supn & dlist[,4]==supn2,indextype]

    if(d1==d2){
      db<-d1
    }else{
      db<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }

    if(da==db){
      result1<-da
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}
