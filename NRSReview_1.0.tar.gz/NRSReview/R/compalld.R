#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

compd<-function(expectanalytic=NULL,expecttrue=NULL,SWA1=NULL,median1=NULL,mx1=NULL,quatileexpectanalytic=NULL,
                quatileexpecttrue=NULL){
  
  if (mx1>0.5){
    dqm1analytic<-(quatileexpectanalytic-mx1)/(mx1-0.5)
    dqm1true<-(quatileexpecttrue-mx1)/(mx1-0.5)
  }else if(mx1==0.5){
    dqm1analytic<-0
    dqm1true<-0
  }else{
    quatileexpectanalytic<-1-quatileexpectanalytic
    quatileexpecttrue<-1-quatileexpecttrue
    mx1<-1-mx1
    dqm1analytic<-(quatileexpectanalytic-mx1)/(mx1-0.5)
    dqm1true<-(quatileexpecttrue-mx1)/(mx1-0.5)
  }
  drm1analytic<-(expectanalytic-SWA1)/(SWA1-median1)
  drm1true<-(expecttrue-SWA1)/(SWA1-median1)
  listd<-c(drm1analytic=drm1analytic,drm1true=drm1true,dqm1analytic=dqm1analytic,dqm1true=dqm1true)
  return(listd)
}

compalld<-function(allSWA){
  (compd(expectanalytic=allSWA[1],expecttrue=allSWA[2],SWA1=allSWA[3],median1=allSWA[4],mx1=allSWA[5],quatileexpectanalytic=allSWA[6],
        quatileexpecttrue=allSWA[7]))
}

compdmmm<-function(expectanalytic,expecttrue,x,SWA,median,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  
  quatileexpectanalytic<-CDF(x=sortedx,xevaluated=expectanalytic,sorted=TRUE)
  quatileexpecttrue<-CDF(x=sortedx,xevaluated=expecttrue,sorted=TRUE)
  mx1<-CDF(x=sortedx,xevaluated=SWA,sorted=TRUE)
  listd<-c(expectanalytic=expectanalytic,expecttrue=expecttrue,SWA=SWA,median=median,mx1=mx1,quatileexpectanalytic=quatileexpectanalytic,quatileexpecttrue=quatileexpecttrue)
  (listd)
}

compalld_all<-function(target, samplemoments,SWAall,SWHLM_all,sortedx){
  medianindex<-length(SWAall)
    
  calc_comp<-function(swa,swhlm=NULL){
    swa_value<-if(is.null(swhlm)) swa else swhlm
    dprocess<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=swa_value,median=SWAall[medianindex],sorted=TRUE)
    d_all<-compalld(dprocess)
    return(list(dprocess=dprocess,d_all=d_all))
  }
  
  swa_indices<-(2:(medianindex-1))
  results<-lapply(SWAall[swa_indices],calc_comp)
  names(results)<-paste0("",names(SWAall)[swa_indices])
  
  if(!is.null(SWHLM_all)){
    swhlm_results<-lapply(SWHLM_all,calc_comp)
    names(swhlm_results)<-paste0("",names(SWHLM_all))
    results<-c(results, swhlm_results)
  }
  
  all_results<-unlist(lapply(results,"[[","dprocess"))
  dall_results<-unlist(lapply(results,"[[","d_all"))
  
  list(all=all_results,dall=dall_results)
}

remove_first <- function(vec) {
  return(vec[-1])
}
compalldmoments<-function (x,targetm,targetvar,targettm,targetfm,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_hlsmall=NULL,orderlist1_hllarge=NULL,percentage=1/24,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  max_dim=6
  lengthx<-length(sortedx)

  samplemoments<-(unbiasedmoments(sortedx))

  SWA_mean<-SWA(x=sortedx,percentage=percentage,batch=batch,sorted=TRUE,rand = TRUE)
  
  SWHLM_mean<-SWHLM(x=sortedx,max_dim=max_dim,orderlists=orderlist1_hlsmall,percentage=percentage,batch=batch,boot=TRUE)
  SWHLM_mean<-unlist(lapply(SWHLM_mean, remove_first))
  meand1<-compalld_all(target=targetm,samplemoments=samplemoments[1],SWAall=SWA_mean,SWHLM_all=SWHLM_mean,sortedx=sortedx)

  if(lengthx>40 || boot){

  bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)

  dp2varx<-varapply1(bootstrappedsample2)
  dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAvar<-SWA(x=dp2varx,percentage=1-(1-percentage)^2,batch="auto",sorted=TRUE)
  
  SWHLM_var<-SWHLM(x=dp2varx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^2,batch=batch,boot=TRUE)
  SWHLM_var<-(lapply(SWHLM_var, remove_first))
  SWHLM_var<-unlist(SWHLM_var)

  vard1<-compalld_all(target=targetvar,samplemoments=samplemoments[2],SWAall=SWAvar,SWHLM_all=SWHLM_var,sortedx=dp2varx)
  
  bootstrappedsample2<-c()
  
  dp2varx<-c()
  
  bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
  dp3tmx<-tmapply1(bootstrappedsample3)
  dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAtm<-SWA(x=dp3tmx,percentage=1-(1-percentage)^3,batch="auto",sorted=TRUE)
  
  SWHLM_tm<-SWHLM(x=dp3tmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^3,batch=batch,boot=TRUE)
  SWHLM_tm<-(lapply(SWHLM_tm, remove_first))
  SWHLM_tm<-unlist(SWHLM_tm)
  
  tmd1<-compalld_all(target=targettm,samplemoments=samplemoments[3],SWAall=SWAtm,SWHLM_all=SWHLM_tm,sortedx=dp3tmx)
  
  bootstrappedsample3<-c()
  
  dp3tmx<-c()
  
  bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
  dp4tmx<-fmapply1(bootstrappedsample4)
  dp4tmx<-Rfast::Sort(x=dp4tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAfm<-SWA(x=dp4tmx,percentage=1-(1-percentage)^4,batch="auto",sorted=TRUE)
  SWHLM_fm<-SWHLM(x=dp4tmx,max_dim=max_dim,orderlists=orderlist1_hllarge,percentage=1-(1-percentage)^4,batch=batch,boot=TRUE)
  SWHLM_fm<-(lapply(SWHLM_fm, remove_first))
  SWHLM_fm<-unlist(SWHLM_fm)
  
  fmd1<-compalld_all(target=targetfm,samplemoments=samplemoments[4],SWAall=SWAfm,SWHLM_all=SWHLM_fm,sortedx=dp4tmx)
  
  bootstrappedsample4<-c()
  
  dp4tmx<-c()

  }
  mean1<-meand1$all
  var1<-vard1$all
  tm1<-tmd1$all
  fm1<-fmd1$all

  all1<-c(mean1=mean1,var1=var1,tm1=tm1,fm1=fm1)
  dall1<-c(meand1=(meand1$dall),vard1=(vard1$dall),tmd1=(tmd1$dall),fmd1=(fmd1$dall))
  allcombine<-unlist(c(dall1,all1))
  return(allcombine)
}

