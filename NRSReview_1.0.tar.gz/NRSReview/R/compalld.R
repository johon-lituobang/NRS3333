#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

compalld<-function(allSWA){
  as.data.frame(compd(expectanalytic=allSWA[1],expecttrue=allSWA[2],expectboot=allSWA[3],SWA1=allSWA[4],median1=allSWA[5],mx1=allSWA[6],quatileexpectanalytic=allSWA[7],
        quatileexpecttrue=allSWA[8],quatileexpectboot=allSWA[9]))
}

compdmmm<-function(expectanalytic,expecttrue,x,SWA,median,isboot=TRUE,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  
  quatileexpectanalytic<-CDF(x=sortedx,xevaluated=expectanalytic,sorted=TRUE)
  quatileexpecttrue<-CDF(x=sortedx,xevaluated=expecttrue,sorted=TRUE)
  if(isboot){
    expectboot=matrixStats::mean2(x)
    quatileexpectboot<-CDF(x=sortedx,xevaluated=expectboot,sorted=TRUE)
  }else{
    expectboot=expecttrue
    quatileexpectboot<-quatileexpecttrue
  }
  mx1<-CDF(x=sortedx,xevaluated=SWA,sorted=TRUE)
  listd<-c(expectanalytic=expectanalytic,expecttrue=expecttrue,expectboot=expectboot,SWA=SWA,median=median,mx1=mx1,quatileexpectanalytic=quatileexpectanalytic,quatileexpecttrue=quatileexpecttrue,quatileexpectboot=quatileexpectboot)
  (listd)
}
compalld_mean<-function (target,samplemoments,SWAall,SWAHLM_all,sortedx){
  BM3<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[2],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dBM3<-compalld(BM3)

  SQM1<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[3],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dSQM<-compalld(SQM1)

  BM2<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[4],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dBM2<-compalld(BM2)

  WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[5],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dWM<-compalld(WM)

  BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[6],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dBWM<-compalld(BWM)

  TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[7],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dTM<-compalld(TM)

  
  SWAHLM2_16_BM3<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[2],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dSWAHLM2_16_BM3<-compalld(SWAHLM2_16_BM3)
  
  SWAHLM2_16_SQM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[3],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_16_SQM<-compalld(SWAHLM2_16_SQM)
  
  SWAHLM2_16_BM2<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[4],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_16_BM2<-compalld(SWAHLM2_16_BM2)
  
  SWAHLM2_16_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[5],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_16_WM<-compalld(SWAHLM2_16_WM)
  
  SWAHLM2_16_BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[6],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_16_BWM<-compalld(SWAHLM2_16_BWM)
  
  SWAHLM2_16_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[7],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_16_TM<-compalld(SWAHLM2_16_TM)
  
  SWAHLM2_16_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[8],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_16_median<-compalld(SWAHLM2_16_median)
  
  
  
  SWAHLM3_16_MH<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[10],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_16_MH<-compalld(SWAHLM3_16_MH)
  
  
  SWAHLM3_16_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[11],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_16_WM<-compalld(SWAHLM3_16_WM)
  
  SWAHLM3_16_BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[12],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_16_BWM<-compalld(SWAHLM3_16_BWM)
  
  SWAHLM3_16_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[13],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_16_TM<-compalld(SWAHLM3_16_TM)
  
  SWAHLM3_16_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[14],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_16_median<-compalld(SWAHLM3_16_median)
  
  SWAHLM4_16_MH<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[16],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_16_MH<-compalld(SWAHLM4_16_MH)
  
  SWAHLM4_16_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[17],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_16_WM<-compalld(SWAHLM4_16_WM)
  
  SWAHLM4_16_BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[18],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_16_BWM<-compalld(SWAHLM4_16_BWM)
  
  SWAHLM4_16_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[19],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_16_TM<-compalld(SWAHLM4_16_TM)
  
  SWAHLM4_16_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[20],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_16_median<-compalld(SWAHLM4_16_median)
  
  
  
  
  all<-c(BM3=BM3,SQM1=SQM1,BM2=BM2,WM=WM,BWM=BWM,TM=TM,
         SWAHLM2_16_BM3=SWAHLM2_16_BM3,SWAHLM2_16_SQM=SWAHLM2_16_SQM,
         SWAHLM2_16_BM2=SWAHLM2_16_BM2,SWAHLM2_16_WM=SWAHLM2_16_WM,
         SWAHLM2_16_BWM=SWAHLM2_16_BWM,SWAHLM2_16_TM=SWAHLM2_16_TM,
         SWAHLM2_16_median=SWAHLM2_16_median,SWAHLM3_16_MH=SWAHLM3_16_MH,
         SWAHLM3_16_WM=SWAHLM3_16_WM,SWAHLM3_16_BWM=SWAHLM3_16_BWM,
         SWAHLM3_16_TM=SWAHLM3_16_TM,SWAHLM3_16_median=SWAHLM3_16_median,
         SWAHLM4_16_MH=SWAHLM4_16_MH,SWAHLM4_16_WM=SWAHLM4_16_WM,
         SWAHLM4_16_BWM=SWAHLM4_16_BWM,SWAHLM4_16_TM=SWAHLM4_16_TM,
         SWAHLM4_16_median=SWAHLM4_16_median
  )
  dall<-c(dBM3=dBM3,dSQM=dSQM,dBM2=dBM2,dWM=dWM,dBWM=dBWM,dTM=dTM,
          dSWAHLM2_16_BM3=dSWAHLM2_16_BM3,dSWAHLM2_16_SQM=dSWAHLM2_16_SQM,
          dSWAHLM2_16_BM2=dSWAHLM2_16_BM2,dSWAHLM2_16_WM=dSWAHLM2_16_WM,
          dSWAHLM2_16_BWM=dSWAHLM2_16_BWM,dSWAHLM2_16_TM=dSWAHLM2_16_TM,
          dSWAHLM2_16_median=dSWAHLM2_16_median,dSWAHLM3_16_MH=dSWAHLM3_16_MH,
          dSWAHLM3_16_WM=dSWAHLM3_16_WM,dSWAHLM3_16_BWM=dSWAHLM3_16_BWM,
          dSWAHLM3_16_TM=dSWAHLM3_16_TM,dSWAHLM3_16_median=dSWAHLM3_16_median,
          dSWAHLM4_16_MH=dSWAHLM4_16_MH,dSWAHLM4_16_WM=dSWAHLM4_16_WM,
          dSWAHLM4_16_BWM=dSWAHLM4_16_BWM,dSWAHLM4_16_TM=dSWAHLM4_16_TM,
          dSWAHLM4_16_median=dSWAHLM4_16_median
          
  )
  list(all=all,dall=dall)
}

compalld_var<-function (target,samplemoments,SWAall,SWAHLM_all,sortedx){
  BM3<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[2],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dBM3<-compalld(BM3)
  
  SQM1<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[3],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSQM<-compalld(SQM1)
  
  BM2<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[4],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dBM2<-compalld(BM2)
  
  WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[5],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dWM<-compalld(WM)
  
  BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[6],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dBWM<-compalld(BWM)
  
  TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[7],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dTM<-compalld(TM)
  
  SWAHLM2_MH<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[2],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_MH<-compalld(SWAHLM2_MH)
  
  SWAHLM2_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[3],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_WM<-compalld(SWAHLM2_WM)
  
  SWAHLM2_BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[4],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_BWM<-compalld(SWAHLM2_BWM)
  
  SWAHLM2_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[5],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_TM<-compalld(SWAHLM2_TM)
  
  SWAHLM2_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[6],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_median<-compalld(SWAHLM2_median)
  
  SWAHLM3_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[8],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_WM<-compalld(SWAHLM3_WM)
  
  SWAHLM3_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[9],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_TM<-compalld(SWAHLM3_TM)
  
  
  
  SWAHLM3_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[10],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_median<-compalld(SWAHLM3_median)
  
  
  SWAHLM4_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[12],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_WM<-compalld(SWAHLM4_WM)
  
  SWAHLM4_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[13],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_TM<-compalld(SWAHLM4_TM)
  
  SWAHLM4_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[14],median=SWAall[8],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM4_median<-compalld(SWAHLM4_median)
  
  all<-c(BM3=BM3,SQM1=SQM1,BM2=BM2,WM=WM,BWM=BWM,TM=TM,
         SWAHLM2_MH=SWAHLM2_MH,SWAHLM2_WM=SWAHLM2_WM,
         SWAHLM2_BWM=SWAHLM2_BWM,SWAHLM2_TM=SWAHLM2_TM,
         SWAHLM2_median=SWAHLM2_median,SWAHLM3_WM=SWAHLM3_WM,
         SWAHLM3_TM=SWAHLM3_TM,SWAHLM3_median=SWAHLM3_median,
         SWAHLM4_WM=SWAHLM4_WM,SWAHLM4_TM=SWAHLM4_TM,
         SWAHLM4_median=SWAHLM4_median
  )
  dall<-c(dBM3=dBM3,dSQM=dSQM,dBM2=dBM2,dWM=dWM,dBWM=dBWM,dTM=dTM,
          dSWAHLM2_MH=dSWAHLM2_MH,dSWAHLM2_WM=dSWAHLM2_WM,
          dSWAHLM2_BWM=dSWAHLM2_BWM,dSWAHLM2_TM=dSWAHLM2_TM,
          dSWAHLM2_median=dSWAHLM2_median,dSWAHLM3_WM=dSWAHLM3_WM,
          dSWAHLM3_TM=dSWAHLM3_TM,dSWAHLM3_median=dSWAHLM3_median,
          dSWAHLM4_WM=dSWAHLM4_WM,dSWAHLM4_TM=dSWAHLM4_TM,
          dSWAHLM4_median=dSWAHLM4_median
          
  )
  list(all=all,dall=dall)
}
compalld_tm<-function (target,samplemoments,SWAall,SWAHLM_all,sortedx){
  MH<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[2],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dMH<-compalld(MH)
  
  WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[3],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dWM<-compalld(WM)
  
  BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[4],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dBWM<-compalld(BWM)
  
  TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[5],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dTM<-compalld(TM)
  
  SWAHLM2_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[2],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_WM<-compalld(SWAHLM2_WM)
  
  SWAHLM2_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[3],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_TM<-compalld(SWAHLM2_TM)
  
  SWAHLM2_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[4],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_median<-compalld(SWAHLM2_median)
  
  SWAHLM3_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[6],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_WM<-compalld(SWAHLM3_WM)
  
  SWAHLM3_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[7],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_TM<-compalld(SWAHLM3_TM)
  
  SWAHLM3_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[8],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM3_median<-compalld(SWAHLM3_median)
  
  all<-c(MH=MH,WM=WM,BWM=BWM,TM=TM,
         SWAHLM2_WM=SWAHLM2_WM,
         SWAHLM2_TM=SWAHLM2_TM,
         SWAHLM2_median=SWAHLM2_median,SWAHLM3_WM=SWAHLM3_WM,
         SWAHLM3_TM=SWAHLM3_TM,SWAHLM3_median=SWAHLM3_median
  )
  dall<-c(dMH=dMH,dWM=dWM,dBWM=dBWM,
          dTM=dTM,dSWAHLM2_WM=dSWAHLM2_WM,
          dSWAHLM2_TM=dSWAHLM2_TM,dSWAHLM2_median=dSWAHLM2_median,
          dSWAHLM3_WM=dSWAHLM3_WM,dSWAHLM3_TM=dSWAHLM3_TM,
          dSWAHLM3_median=dSWAHLM3_median
          
  )
  list(all=all,dall=dall)
}
compalld_fm<-function (target,samplemoments,SWAall,SWAHLM_all,sortedx){
  
  MH1<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[2],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dMH<-compalld(MH1)
  
  WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[3],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dWM<-compalld(WM)
  
  BWM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[4],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dBWM<-compalld(BWM)
  
  TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[5],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dTM<-compalld(TM)
  
  SWAHLM2_WM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[2],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_WM<-compalld(SWAHLM2_WM)
  
  SWAHLM2_TM<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[3],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_TM<-compalld(SWAHLM2_TM)
  
  SWAHLM2_median<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAHLM_all[4],median=SWAall[6],isboot=TRUE,sorted=TRUE)
  
  dSWAHLM2_median<-compalld(SWAHLM2_median)
  
  all<-c(MH1=MH1,WM=WM,BWM=BWM,TM=TM,
         SWAHLM2_WM=SWAHLM2_WM,
         SWAHLM2_TM=SWAHLM2_TM,
         SWAHLM2_median=SWAHLM2_median
  )
  dall<-c(dMH=dMH,dWM=dWM,dBWM=dBWM,dTM=dTM,
          dSWAHLM2_WM=dSWAHLM2_WM,
          dSWAHLM2_TM=dSWAHLM2_TM,
          dSWAHLM2_median=dSWAHLM2_median
  )
  list(all=all,dall=dall)
}

compalldmoments<-function (x,targetm,targetvar,targettm,targetfm,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=1/16,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  samplemoments<-(unbiasedmoments(sortedx))

  SWA_mean<-SWA(x=sortedx,percentage=1/16,blocknumber=16,batch="auto",sorted=TRUE)
  SWAHLM_mean<-SWAHLM_16(x=sortedx,orderlist1_sorted2=orderlist1_sorted20,orderlist1_sorted3=orderlist1_sorted30,orderlist1_sorted4=orderlist1_sorted40,percentage=1/16,batch="auto",boot=TRUE)
  
  meand1<-compalld_mean(target=targetm,samplemoments=samplemoments[1],SWAall=SWA_mean,SWAHLM_all=SWAHLM_mean,sortedx=sortedx)
  
  if(lengthx>40 || boot){

  bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)

  dp2varx<-varapply1(bootstrappedsample2)
  dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAvar<-SWA(x=dp2varx,percentage=31/256,blocknumber=9,batch="auto",sorted=TRUE)

  SWAHLM_var<-SWAHLM_31256(x=dp2varx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=31/256,batch="auto",boot=TRUE)
  
  vard1<-compalld_var(target=targetvar,samplemoments=samplemoments[2],SWAall=SWAvar,SWAHLM_all=SWAHLM_var,sortedx=dp2varx)
  
  bootstrappedsample2<-c()
  
  dp2varx<-c()

  bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
  dp3tmx<-tmapply1(bootstrappedsample3)
  dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAtm<-SWA(x=dp3tmx,percentage=721/4096,blocknumber=5,batch="auto",sorted=TRUE)
  
  SWAHLM_tm<-SWAHLM_741(x=dp3tmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=721/4096,batch="auto",boot=TRUE)
  
  tmd1<-compalld_tm(target=targettm,samplemoments=samplemoments[3],SWAall=SWAtm,SWAHLM_all=SWAHLM_tm,sortedx=dp3tmx)
  
  bootstrappedsample3<-c()
  
  dp3tmx<-c()

  bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
  dp4tmx<-fmapply1(bootstrappedsample4)
  dp4tmx<-Rfast::Sort(x=dp4tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAfm<-SWA(x=dp4tmx,percentage=14911/65536,blocknumber=5,batch=2,sorted=TRUE)
  SWAHLM_fm<-SWAHLM_312(x=dp4tmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=14911/65536,batch="auto",boot=TRUE)
  
  fmd1<-compalld_fm(target=targetfm,samplemoments=samplemoments[4],SWAall=SWAfm,SWAHLM_all=SWAHLM_fm,sortedx=dp4tmx)
  
  bootstrappedsample4<-c()
  
  dp4tmx<-c()

  }else{
    
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    SWAvar<-SWA(x=dp2varx,percentage=31/256,blocknumber=9,batch="auto",sorted=TRUE)
    
    SWAHLM_var<-SWAHLM_31256(x=dp2varx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=31/256,batch="auto",boot=TRUE)
    
    vard1<-compalld_var(target=targetvar,samplemoments=samplemoments[2],SWAall=SWAvar,SWAHLM_all=SWAHLM_var,sortedx=dp2varx)
    
    combinationsample2<-c()
    
    dp2varx<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    SWAtm<-SWA(x=dp3tmx,percentage=721/4096,blocknumber=5,batch="auto",sorted=TRUE)
    
    SWAHLM_tm<-SWAHLM_741(x=dp3tmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=721/4096,batch="auto",boot=TRUE)
    
    tmd1<-compalld_tm(target=targettm,samplemoments=samplemoments[3],SWAall=SWAtm,SWAHLM_all=SWAHLM_tm,sortedx=dp3tmx)
    
    combinationsample3<-c()
    
    dp3tmx<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    dp4tmx<-fmapply1(combinationsample4)
    dp4tmx<-Rfast::Sort(x=dp4tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    SWAfm<-SWA(x=dp4tmx,percentage=14911/65536,blocknumber=5,batch=2,sorted=TRUE)
    SWAHLM_fm<-SWAHLM_312(x=dp4tmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=14911/65536,batch="auto",boot=TRUE)
    
    fmd1<-compalld_fm(target=targetfm,samplemoments=samplemoments[4],SWAall=SWAfm,SWAHLM_all=SWAHLM_fm,sortedx=dp4tmx)
    
    combinationsample4<-c()
    
    dp4tmx<-c()
    
  }
  mean1<-meand1$all
  var1<-vard1$all
  tm1<-tmd1$all
  fm1<-fmd1$all

  all1<-c(mean1=mean1,var1=var1,tm1=tm1,fm1=fm1)
  dall1<-cbind(meand1=as.data.frame(meand1$dall),vard1=as.data.frame(vard1$dall),tmd1=as.data.frame(tmd1$dall),fmd1=as.data.frame(fmd1$dall))
  allcombine<-unlist(c(dall1,all1))
  return(allcombine)
}


