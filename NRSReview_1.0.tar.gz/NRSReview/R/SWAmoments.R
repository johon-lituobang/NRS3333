#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


SWAmoments<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=1/16,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_sorted2,size=lengthx,interval=16,dimension=2)
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_sorted3,size=lengthx,interval=16,dimension=3)
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_sorted4,size=lengthx,interval=16,dimension=4)
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }

  SWA_mean<-SWA(x=sortedx,percentage=1/16,blocknumber=16,batch="auto",sorted=TRUE)
  
  SWAvar<-SWA(x=dp2varx,percentage=31/256,blocknumber=9,batch="auto",sorted=TRUE)
  
  SWAtm<-SWA(x=dp3tmx,percentage=721/4096,blocknumber=5,batch="auto",sorted=TRUE)
  
  SWAfm<-SWA(x=dp4fmx,percentage=14911/65536,blocknumber=5,batch=2,sorted=TRUE)
  
  finallall<-c(SWA_mean=SWA_mean,
               SWAvar=SWAvar,
               SWAtm=SWAtm,
               SWAfm=SWAfm)
  return(c(finallall))
}

medianstandardizedmoments<-function (x,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,batch="auto",boot=TRUE){
  SWAmoments1<-SWAmoments(x=x,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,batch=batch,boot=boot)
  names(SWAmoments1)<-NULL
  SWAstandardizedmoments1<-c(median=SWAmoments1[8],mvar=SWAmoments1[16],mskew=SWAmoments1[22]/((SWAmoments1[16])^(3/2)),mkurt=SWAmoments1[28]/((SWAmoments1[16])^2))
  SWAstandardizedmoments1
}
