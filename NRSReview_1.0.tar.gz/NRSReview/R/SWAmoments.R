#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


SWAmoments<-function (x,check=TRUE,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,interval=8,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_2_104,size=lengthx,interval=8,dimension=2)
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_3_104,size=lengthx,interval=8,dimension=3)
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_4_104,size=lengthx,interval=8,dimension=4)
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }

  mmm1raw<-SWA(x=sortedx,interval=interval,batch=batch,sorted=TRUE)

  varmoraw<-SWA(x=dp2varx,interval=interval,batch=batch,sorted=TRUE)

  tmmoraw<-SWA(x=dp3tmx,interval=interval,batch=batch,sorted=TRUE)

  fmmoraw<-SWA(x=dp4fmx,interval=interval,batch=batch,sorted=TRUE)

  if(check){
    unbiasedmoments1<-unbiasedmoments(sortedx)
    sd4<-c(sqrt(unbiasedmoments1[2]),sd(dp2varx),sd(dp3tmx),sd(dp4fmx))
    errors1<-abs(mmm1raw[1]-unbiasedmoments1[1])/sd4[1]
    errors2<-abs(varmoraw[1]-unbiasedmoments1[2])/sd4[2]
    errors3<-abs(tmmoraw[1]-unbiasedmoments1[3])/sd4[3]
    errors4<-abs(fmmoraw[1]-unbiasedmoments1[4])/sd4[4]
    print("The standardized differences of the bootstrapped moments and unbiased sample moments are")
    print(c(errors1,errors2,errors3,errors4))
  }
  
  
  finallall<-c(mmm1raw=mmm1raw,
               varmoraw=varmoraw,
               tmmoraw=tmmoraw,
               fmmoraw=fmmoraw)
  return(c(finallall))
}

medianstandardizedmoments<-function (x,check=TRUE,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,interval=8,batch="auto",boot=TRUE){
  SWAmoments1<-SWAmoments(x=x,check=check,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,interval=interval,batch=batch,boot=boot)
  names(SWAmoments1)<-NULL
  SWAstandardizedmoments1<-c(median=SWAmoments1[8],mvar=SWAmoments1[16],mskew=SWAmoments1[24]/((SWAmoments1[16])^(3/2)),mkurt=SWAmoments1[32]/((SWAmoments1[16])^2))
  SWAstandardizedmoments1
}

