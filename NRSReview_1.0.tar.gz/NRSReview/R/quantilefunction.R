#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

quantilefunction<-function(x,quatiletarget,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  h1<-(lengthx+1/3)*quatiletarget+1/3
  h1f<-floor(h1)
  h1c<-ceiling(h1)
  sortedquantile1<-sortedx[h1f]
  sortedquantile2<-sortedx[h1c]
  result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
  names(result)<-quatiletarget
  (result)
}

