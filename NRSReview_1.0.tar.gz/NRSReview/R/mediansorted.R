#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

mediansorted<-function(sortedx,lengthx){
  if (lengthx%%2==0){
    median1<-(sortedx[lengthx/2]+sortedx[(lengthx/2)+1])/2
  }
  else{median1<-sortedx[(lengthx+1)/2]}
  names(median1)<-NULL
  median1
}

