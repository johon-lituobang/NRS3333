#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

CDF<-function(x,xevaluated,sorted=FALSE){
  if(!sorted){
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n<-length(x)
  quantileTargets<-((1:n)-1)/(n-1)
  
  interpolation_function<-approxfun(x,quantileTargets,method="linear",rule=2)
  approxQuantileTarget<-interpolation_function(xevaluated)
  
  approxQuantileTarget
}

quantilefunction<-function(x,quatiletarget,sorted=FALSE){
  if(!sorted){
    x <- Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  h1<-(lengthx-1)*quatiletarget+1
  h1f<-as.numeric(floor(h1))
  h1c<-as.numeric(ceiling(h1))
  sortedquantile1<-x[h1f]
  sortedquantile2<-x[h1c]
  result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
  names(result)<-quatiletarget
  (result)
}

median_of_means <- function(x,korder=2) {
  n_blocks=ceiling(length(x)/korder)
  if (korder <= 1) {
    return(median(x))
  }
  data_mixed <- sample(x)
  index_vec <- rep(1:n_blocks, each = ceiling(length(x) / n_blocks))[1:length(x)]
  data_groups <- split(data_mixed, index_vec)
  block_means <- sapply(data_groups, mean)
  return(c(MoM=median(block_means,na.rm = TRUE)))
}
