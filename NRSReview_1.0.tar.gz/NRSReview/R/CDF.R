#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

CDF<-function(x,xevaluated,sorted=FALSE){
  if(!sorted){
    x<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n<-length(x)
  quantileTargets<-((1:n)-1)/(n-1)
  
  interpolation_function<-approxfun(x,quantileTargets,method="linear",rule=2)
  approxQuantileTarget<-interpolation_function(xevaluated)
  
  approxQuantileTarget
}

quantilefunction<-function(x,quatiletarget,sorted=FALSE){
  if(!sorted){
    x <- Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  h1<-(lengthx-1)*quatiletarget+1
  h1f<-as.numeric(floor(h1))
  h1c<-as.numeric(ceiling(h1))
  sortedquantile1<-x[h1f]
  sortedquantile2<-x[h1c]
  result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
  names(result)<-quatiletarget
  (result)
}

d_adjust_kurt<-function(size,dtype,kurt1,dlist,etype){
  dlist<-dlist[dlist[,2] == dtype,]
  dlist<-dlist[,c(1:4,etype)]
  if(size%in% dlist[,1]){
    if (kurt1%in% dlist[dlist[,1] == size,3]){
      result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,5]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,3])
      tryCatch({
        infn2 <- max(rown2[rown2 <= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
        message(custom_warning)
        infn2 <<- min(rown2)
      })
      
      tryCatch({
        supn2 <- min(rown2[rown2 >= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
        message(custom_warning)
        supn2 <<- max(rown2)
      })
      
      if(supn2==infn2){
        result1<-dlist[dlist[,1]==size & dlist[,3]==infn2,5]
      }else{
        d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,5]
        d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,5]
        result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )
    
    rown2<-as.numeric(dlist[dlist[,1] == infn,3])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    
    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,5]
    d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,5]
    
    if(supn2==infn2){
      da<-d1
    }else{
      da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
    
    rown2<-as.numeric(dlist[dlist[,1] == supn,3])
    
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    
    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,5]
    d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,5]
    
    if(supn2==infn2){
      db<-d1
    }else{
      db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
    
    if(da==db){
      result1<-da
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}

d_adjust_skew<-function(size,dtype,skew1,dlist,etype){
  skew1<-abs(skew1)
  dlist<-dlist[dlist[,2] == dtype,]
  dlist<-dlist[,c(1:4,etype)]
  if(size%in% dlist[,1]){
    if (skew1%in% dlist[dlist[,1] == size,4]){
      result1<-dlist[dlist[,1] == size & dlist[,4]==skew1,5]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,4])
      
      tryCatch({
        infn2 <- max(rown2[rown2 <= skew1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
        message(custom_warning)
        infn2 <<- min(rown2)
      })
      
      tryCatch({
        supn2 <- min(rown2[rown2 >= skew1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
        message(custom_warning)
        supn2 <<- max(rown2)
      })
      d1<-dlist[dlist[,1]==size & dlist[,4]==infn2,5]
      d2<-dlist[dlist[,1]==size & dlist[,4]==supn2,5]
      if(supn2==infn2){
        result1<-d1
      }else{
        result1<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )
    
    rown2<-as.numeric(dlist[dlist[,1] == infn,4])
    tryCatch({
      infn2 <- max(rown2[rown2 <= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    d1<-dlist[dlist[,1]==infn & dlist[,4]==infn2,5]
    d2<-dlist[dlist[,1]==infn & dlist[,4]==supn2,5]
    
    if(supn2==infn2){
      da<-d1
    }else{
      da<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }
    
    rown2<-as.numeric(dlist[dlist[,1] == supn,4])
    tryCatch({
      infn2 <- max(rown2[rown2 <= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    
    d1<-dlist[dlist[,1]==supn & dlist[,4]==infn2,5]
    d2<-dlist[dlist[,1]==supn & dlist[,4]==supn2,5]
    
    if(supn2==infn2){
      db<-d1
    }else{
      db<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }
    
    if(da==db){
      result1<-da
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}

median_of_means <- function(x,korder=2) {
  n_blocks=ceiling(length(x)/korder)
  if (korder <= 1) {
    return(median(x))
  }
  data_mixed <- sample(x)
  index_vec <- rep(1:n_blocks, each = ceiling(length(x) / n_blocks))[1:length(x)]
  data_groups <- split(data_mixed, index_vec)
  block_means <- sapply(data_groups, mean)
  return(c(MoM=median(block_means,na.rm = TRUE)))
}
