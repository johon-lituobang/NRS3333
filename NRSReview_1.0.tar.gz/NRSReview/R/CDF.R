#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

CDF <- function(x,xevaluated,sorted=FALSE){
  if(!sorted){
    x <- Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  n <- length(x)
  quantileTargets <- ((1:n)-1) / (n-1)
  
  insert_indices <- findInterval(xevaluated,x,rightmost.closed=TRUE)
  
  left_slope <- (xevaluated-x[insert_indices]) / (x[insert_indices+1]-x[insert_indices])
  right_slope <- 1-left_slope
  
  approxQuantileTarget <- quantileTargets[insert_indices]*right_slope + quantileTargets[insert_indices+1]*left_slope
  
  approxQuantileTarget[insert_indices==0] <- 0
  approxQuantileTarget[insert_indices==n] <- 1
  
  approxQuantileTarget
}

quantilefunction<-function(x,quatiletarget,sorted=FALSE){
  if(!sorted){
    x <- Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  h1<-(lengthx-1)*quatiletarget+1
  h1f<-as.numeric(floor(h1))
  h1c<-as.numeric(ceiling(h1))
  sortedquantile1<-x[h1f]
  sortedquantile2<-x[h1c]
  result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
  names(result)<-quatiletarget
  (result)
}
