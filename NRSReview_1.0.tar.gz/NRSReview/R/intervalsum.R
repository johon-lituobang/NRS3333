#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

intervalsum<-function (x_ordered,IntKsamples,target1,interval=8){
  if(interval!=8){
    return("interval must be 8 ")
  }
  list1<-(c(x_ordered[1:(1*(IntKsamples))],x_ordered[(7*IntKsamples+1):(target1)]))
  list2<-(c(x_ordered[(IntKsamples+1):(2*(IntKsamples))],x_ordered[(6*IntKsamples+1):(7*IntKsamples)]))
  list3<-(c(x_ordered[(2*(IntKsamples)+1):(3*(IntKsamples))],x_ordered[(5*(IntKsamples)+1):(6*IntKsamples)]))
  list4<-c(x_ordered[(3*(IntKsamples)+1):(5*(IntKsamples))])

  sumlist1<-matrixStats::sum2(list1)
  sumlist2<-matrixStats::sum2(list2)
  sumlist3<-matrixStats::sum2(list3)
  sumlist4<-matrixStats::sum2(list4)

  all1<-c(sumlist1=sumlist1,sumlist2=sumlist2,sumlist3=sumlist3,sumlist4=sumlist4)
  (all1)
}