#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


mmmprocessrm<-function(SWA,median,drm=0.375){
  rm1<--drm*median+SWA+drm*SWA
  names(rm1)<-NULL
  output1<-c(rm=rm1)
  return(output1)
}

mmmprocessqm<-function(x,percentage,pc1,dqm=0.567,sorted=TRUE,beNA=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if (pc1==0.5){
    quatiletarget<-0.5
  }else if (pc1>0.5){
    quatiletarget<-pc1+(pc1-0.5)*dqm
  }else{
    pc1<-1-pc1
    quatiletarget<-pc1+(pc1-0.5)*dqm
    quatiletarget<-1-quatiletarget
  }
  upper1<-(1-percentage)
  lower1<-percentage
  if(quatiletarget>upper1){
    if (beNA){
      return(NA)
    }else{
      quatiletarget=upper1
    }
  }else if(quatiletarget<lower1){
    if (beNA){
      return(NA)
    }else{
      quatiletarget=lower1
    }
  }
  qm1<-quantilefunction(sortedx,quatiletarget,sorted=TRUE)
  output1<-c(qm=qm1)
  return(output1)
}

quantilefunction<-function(x,quatiletarget,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  h1<-(lengthx+1/3)*quatiletarget+1/3
  h1f<-as.numeric(floor(h1))
  h1c<-as.numeric(ceiling(h1))
  sortedquantile1<-sortedx[h1f]
  sortedquantile2<-sortedx[h1c]
  result<-sortedquantile1+(h1-h1f)*(sortedquantile2-sortedquantile1)
  names(result)<-quatiletarget
  (result)
}

d_adjust_kurt<-function(size,dtype,kurt1,dlist,etype){
  dlist<-dlist[dlist[,2] == dtype,]
  dlist<-dlist[,c(1:4,etype)]
  if(size%in% dlist[,1]){
    if (kurt1%in% dlist[dlist[,1] == size,3]){
      result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,5]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,3])
      infn2<-max(rown2[rown2 < kurt1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
        #print(c("The kurtosis is out of range supported.",kurt1))
      }
      supn2<-min(rown2[rown2 > kurt1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
        #print(c("The kurtosis is out of range supported.",kurt1))
      }
      d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,5]
      d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,5]
      if(d1==d2){
        result1<-d1
      }else{
        result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }

    rown2<-as.numeric(dlist[dlist[,1] == infn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,5]
    d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,5]

    if(d1==d2){
      da<-d1
    }else{
      da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }

    rown2<-as.numeric(dlist[dlist[,1] == supn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,5]
    d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,5]

    if(d1==d2){
      db<-d1
    }else{
      db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }

    if(da==db){
      result1<-da
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}

d_kurt_list<-function(size,dtype,kurt1,dlist){
  dlist<-dlist[dlist[,2] == dtype,]
  if(size%in% dlist[,1]){
    if (kurt1%in% dlist[dlist[,1] == size,3]){
      result1<-dlist[dlist[,1] == size & dlist[,3]==kurt1,]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,3])
      infn2<-max(rown2[rown2 < kurt1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
        #print(c("The kurtosis is out of range supported.",kurt1))
      }
      supn2<-min(rown2[rown2 > kurt1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
        #print(c("The kurtosis is out of range supported.",kurt1))
      }
      d1<-dlist[dlist[,1]==size & dlist[,3]==infn2,]
      d2<-dlist[dlist[,1]==size & dlist[,3]==supn2,]
      result1<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    }
  }else{
    rown<-as.numeric(dlist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }
    
    rown2<-as.numeric(dlist[dlist[,1] == infn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }
    
    d1<-dlist[dlist[,1]==infn & dlist[,3]==infn2,]
    d2<-dlist[dlist[,1]==infn & dlist[,3]==supn2,]
    
    da<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    
    rown2<-as.numeric(dlist[dlist[,1] == supn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }
    
    d1<-dlist[dlist[,1]==supn & dlist[,3]==infn2,]
    d2<-dlist[dlist[,1]==supn & dlist[,3]==supn2,]
    
    db<-(((d2-d1)*((kurt1-infn2)/(supn2-infn2)))+d1)
    
    result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
  }
  return(result1)
}

d_adjust_skew<-function(size,dtype,skew1,dlist,etype){
  skew1<-abs(skew1)
  dlist<-dlist[dlist[,2] == dtype,]
  dlist<-dlist[,c(1:4,etype)]
  if(size%in% dlist[,1]){
    if (skew1%in% dlist[dlist[,1] == size,4]){
      result1<-dlist[dlist[,1] == size & dlist[,4]==skew1,5]
    }else{
      rown2<-as.numeric(dlist[dlist[,1] == size,4])
      infn2<-max(rown2[rown2 < skew1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
      }
      supn2<-min(rown2[rown2 > skew1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
      }
      d1<-dlist[dlist[,1]==size & dlist[,4]==infn2,5]
      d2<-dlist[dlist[,1]==size & dlist[,4]==supn2,5]
      if(d1==d2){
        result1<-d1
      }else{
        result1<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
      }
    }
  }else{
    rown<-as.numeric(dlist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }

    rown2<-as.numeric(dlist[dlist[,1] == infn,4])
    infn2<-max(rown2[rown2 < skew1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > skew1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==infn & dlist[,4]==infn2,5]
    d2<-dlist[dlist[,1]==infn & dlist[,4]==supn2,5]

    if(d1==d2){
      da<-d1
    }else{
      da<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }

    rown2<-as.numeric(dlist[dlist[,1] == supn,4])
    infn2<-max(rown2[rown2 < skew1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > skew1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    d1<-dlist[dlist[,1]==supn & dlist[,4]==infn2,5]
    d2<-dlist[dlist[,1]==supn & dlist[,4]==supn2,5]

    if(d1==d2){
      db<-d1
    }else{
      db<-(((d2-d1)*((skew1-infn2)/(supn2-infn2)))+d1)
    }

    if(da==db){
      result1<-da
    }else{
      result1<-(((db-da)*((size-infn)/(supn-infn)))+da)
    }
  }
  return(result1)
}


rqmean_exp<-function (x,standist_d=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,percentage=1/16,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  
  if(lengthx>40 || boot){
    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)
    
    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample3<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    
    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample4<-c()
    
  }
  SWA_mean<-SWA(x=sortedx,percentage=1/16,blocknumber=16,batch="auto",sorted=TRUE)
  SWAHLM_mean<-SWAHLM_16(x=sortedx,orderlist1_sorted2=orderlist1_sorted20,orderlist1_sorted3=orderlist1_sorted30,orderlist1_sorted4=orderlist1_sorted40,percentage=1/16,batch="auto",boot=TRUE)
  
  CDF_SWA_mean <- sapply(SWA_mean[2:7], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_mean) <- paste0("pc_mean", names(SWA_mean)[2:7])
  
  CDF_SWAHLM_mean <- sapply(SWAHLM_mean[c(2:8,10:14,16:20)], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_mean) <- paste0("pc_mean", names(SWAHLM_mean)[c(2:8,10:14,16:20)])
  
  start_kurt=9
  start_skew=2
  
  allds_start<-d_kurt_list(size=lengthx,dtype=1,kurt1=start_kurt,dlist=standist_d)
  
  meand1<-cbind(allds_start[5:50])
  
  meand1_rm<-meand1[seq(from=1, to=46, by=2)]
  
  meanSWAall<-c(SWA_mean[2:7],SWAHLM_mean[2:8],SWAHLM_mean[10:14],SWAHLM_mean[16:20])

  rmall_exp<-meand1_rm*meanSWAall+meanSWAall-meand1_rm*SWA_mean[8]
  
  start_kurt=9
  start_skew=2
  
  meand1_qm<-meand1[seq(from=2, to=46, by=2)]
  
  CDF_meanSWAall<-c(CDF_SWA_mean,CDF_SWAHLM_mean)
  
  qmall_exp<-c()
  for(i in (1:23)){
    qmall_exp<-c(qmall_exp,mmmprocessqm(x=sortedx,percentage=1/16,pc1=CDF_meanSWAall[i],dqm=meand1_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qmall_exp)<-names(CDF_meanSWAall)
  qmall_exp<-unlist(qmall_exp)
  c(rmall_exp,qmall_exp)
}               

rqsmoments<-function (x,dtype1=1,releaseall=FALSE,standist_d=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=1/16,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)
  if(is.null(standist_d)){
    data(d_values)
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      largesize1<-2048*9
      
      orderlist1_sorted20<-createorderlist(quni1=quasiuni_sorted2,size=lengthx,interval=16,dimension=2)
      orderlist1_sorted20<-orderlist1_sorted20[1:largesize1,]
      orderlist1_sorted30<-createorderlist(quni1=quasiuni_sorted3,size=lengthx,interval=16,dimension=3)
      orderlist1_sorted30<-orderlist1_sorted30[1:largesize1,]
      orderlist1_sorted40<-createorderlist(quni1=quasiuni_sorted4,size=lengthx,interval=16,dimension=4)
      orderlist1_sorted40<-orderlist1_sorted40[1:largesize1,]
      
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_sorted2,size=largesize1,interval=16,dimension=2)
      orderlist1_sorted2<-orderlist1_sorted2[1:largesize1,]
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_sorted3,size=largesize1,interval=16,dimension=3)
      orderlist1_sorted3<-orderlist1_sorted3[1:largesize1,]
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_sorted4,size=largesize1,interval=16,dimension=4)
      orderlist1_sorted4<-orderlist1_sorted4[1:largesize1,]
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }
  SWA_mean<-SWA(x=sortedx,percentage=1/16,blocknumber=16,batch="auto",sorted=TRUE)
  SWAHLM_mean<-SWAHLM_16(x=sortedx,orderlist1_sorted2=orderlist1_sorted20,orderlist1_sorted3=orderlist1_sorted30,orderlist1_sorted4=orderlist1_sorted40,percentage=1/16,batch="auto",boot=TRUE)
  
  CDF_SWA_mean <- sapply(SWA_mean[2:7], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_mean) <- paste0("pc_mean", names(SWA_mean)[2:7])
  
  CDF_SWAHLM_mean <- sapply(SWAHLM_mean[c(2:8,10:14,16:20)], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_mean) <- paste0("pc_mean", names(SWAHLM_mean)[c(2:8,10:14,16:20)])
  
  SWAvar<-SWA(x=dp2varx,percentage=31/256,blocknumber=9,batch="auto",sorted=TRUE)
  SWAHLM_var<-SWAHLM_31256(x=dp2varx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=31/256,batch="auto",boot=TRUE)
  
  CDF_SWA_var <- sapply(SWAvar[2:7], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_var) <- paste0("pc_var", names(SWAvar)[2:7])
  
  CDF_SWAHLM_var <- sapply(SWAHLM_var[c(2:6,8:10,12:14)], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_var) <- paste0("pc_var", names(SWAHLM_var)[c(2:6,8:10,12:14)])
  
  SWAtm<-SWA(x=dp3tmx,percentage=721/4096,blocknumber=5,batch="auto",sorted=TRUE)
  
  SWAHLM_tm<-SWAHLM_741(x=dp3tmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=721/4096,batch="auto",boot=TRUE)

  CDF_SWA_tm <- sapply(SWAtm[2:5], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_tm) <- paste0("pc_tm", names(SWAtm)[2:5])
  
  CDF_SWAHLM_tm <- sapply(SWAHLM_tm[c(2:4,6:8)], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_tm) <- paste0("pc_tm", names(SWAHLM_tm)[c(2:4,6:8)])

  SWAfm<-SWA(x=dp4fmx,percentage=14911/65536,blocknumber=5,batch=2,sorted=TRUE)
  SWAHLM_fm<-SWAHLM_312(x=dp4fmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=14911/65536,batch="auto",boot=TRUE)
  
  CDF_SWA_fm <- sapply(SWAfm[2:5], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_fm) <- paste0("pc_fm", names(SWAfm)[2:5])
  
  CDF_SWAHLM_fm <- sapply(SWAHLM_fm[c(2:4)], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_fm) <- paste0("pc_fm", names(SWAHLM_fm)[c(2:4)])
  
  #exp_rm
  start_kurt=9
  start_skew=2
  
  allds_start<-d_kurt_list(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d)
  
  var_fm_ds_start<-cbind(allds_start[51:84],allds_start[105:118])
  
  var_fm_ds_rm<-var_fm_ds_start[seq(from=1, to=48, by=2)]
  
  varSWAall<-c(SWAvar[2:7],SWAHLM_var[2:6],SWAHLM_var[8:10],SWAHLM_var[12:14])
  
  rvarall_exp<-var_fm_ds_rm[1:17]*varSWAall+varSWAall-var_fm_ds_rm[1:17]*SWAvar[8]
  
  fmSWAall<-c(SWAfm[2:5],SWAHLM_fm[2:4])
  
  rfmall_exp<-var_fm_ds_rm[18:24]*fmSWAall+fmSWAall-var_fm_ds_rm[18:24]*SWAfm[6]
  kurtfunction<- function(x, y) {
    return(x /(y^2))
  }
  rkurtall_exp <- t(outer(as.numeric(rfmall_exp), as.numeric(rvarall_exp), FUN =kurtfunction))
  
  #Weibull_rm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  rkurtall <- matrix(nrow = 17, ncol = 7)
  
  for (i in 1:17) {
    for (j in 1:7) {
      kurt1<-26
      
      Kappa1rm<-function(kurt1){
        d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=50+i*2-1)
        
        d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=104+j*2-1)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[8]
        
        rfmall<-d_rfm*fmSWAall[j]+fmSWAall[j]-d_rfm*SWAfm[6]
        
        rfmall/(rvarall^2)
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        kurt2<-Kappa1rm(kurt1)
        
        if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){
          
          break
        }
        kurt1<-kurt2
      }
      rkurtall[i, j] <- kurt1
    }
  }
  rkurtall_Weibull<-rkurtall
  
  #exp_qm
  start_kurt=9
  start_skew=2
  
  var_fm_ds_qm<-var_fm_ds_start[seq(from=2, to=48, by=2)]
  
  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWAHLM_var)
  
  qvarall_exp<-c()
  for(i in (1:17)){
    qvarall_exp<-c(qvarall_exp,mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=var_fm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qvarall_exp)<-names(CDF_varSWAall)
  qvarall_exp<-unlist(qvarall_exp)
  CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWAHLM_fm)
  
  qfmall_exp<-c()
  for(i in (1:7)){
    qfmall_exp<-c(qfmall_exp,mmmprocessqm(x=dp4fmx,percentage=14911/65536,pc1=CDF_fmSWAall[i],dqm=var_fm_ds_qm[17+i],sorted=TRUE,beNA=TRUE))
  }
  names(qfmall_exp)<-names(CDF_fmSWAall)
  
  qkurtall_exp <- t(outer(as.numeric(qfmall_exp), as.numeric(qvarall_exp), FUN =kurtfunction))
  
  #Weibull_qm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  qkurtall <- matrix(nrow = 17, ncol = 7)
  
  for (i in 1:17) {
    for (j in 1:7) {
      kurt1<-26
      Kappa1qm<-function(kurt1,beNA){
        if(is.na(kurt1)){
          return(NA)
        }
        d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=50+i*2)
        
        d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=104+j*2)
        
        qvarall<-mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        
        qfmall<-mmmprocessqm(x=dp4fmx,percentage=14911/65536,pc1=CDF_fmSWAall[j],dqm=d_qfm,sorted=TRUE,beNA=beNA)
        
        qfmall/(qvarall^2)
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        kurt2<-Kappa1qm(kurt1,beNA=FALSE)
        
        if (is.na(kurt2)||(abs(kurt1-kurt2))<criterion || (step1 == stepsize)){
          
          break
        }
        kurt1<-kurt2
      }
      
      qkurtall[i, j] <- Kappa1qm(kurt1,beNA=TRUE)
    }
  }
  qkurtall_Weibull<-qkurtall
  
  #exp_rm
  start_skew=2
  
  tm_ds_all<-c(allds_start[85:104])
  tm_ds_rm<-unlist(tm_ds_all[seq(from=1, to=20, by=2)])
  
  tmSWAall<-c(SWAtm[2:5],SWAHLM_tm[2:4],SWAHLM_tm[6:8])
  
  rtmall_exp<-tm_ds_rm[1:10]*tmSWAall+tmSWAall-tm_ds_rm[1:10]*SWAtm[6]
  skewfunction<- function(x, y) {
    return(x /(y^(3/2)))
  }
  rskewall_exp <- t(outer(as.numeric(rtmall_exp), as.numeric(rvarall_exp), FUN =skewfunction))

  #Weibull_rm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  rskewall <- matrix(nrow = 17, ncol = 10)
  
  for (i in 1:17) {
    for (j in 1:10) {
      skew1<-3.68267203509023
      
      skew1rm<-function(skew1){
        d_rvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=50+i*2-1)
        
        d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=84+j*2-1)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[8]
        
        rtmall<-d_rtm*tmSWAall[j]+tmSWAall[j]-d_rtm*SWAtm[6]
        
        rtmall/(rvarall^(3/2))
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        skew2<-skew1rm(skew1)
        
        if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){
          
          break
        }
        skew1<-skew2
      }
      rskewall[i, j] <- skew1
    }
  }
  rskewall_Weibull<-rskewall
  
  #exp_qm
  start_kurt=9
  start_skew=2
  
  var_fm_ds_qm<-var_fm_ds_start[seq(from=2, to=48, by=2)]
  
  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWAHLM_var)
  
  qvarall_exp<-c()
  for(i in (1:17)){
    qvarall_exp<-c(qvarall_exp,mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=var_fm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qvarall_exp)<-names(CDF_varSWAall)
  
  tm_ds_qm<-unlist(tm_ds_all[seq(from=2, to=20, by=2)])
  CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWAHLM_tm)
  
  qtmall_exp<-c()
  for(i in (1:10)){
    qtmall_exp<-c(qtmall_exp,mmmprocessqm(x=dp3tmx,percentage=721/4096,pc1=CDF_tmSWAall[i],dqm=tm_ds_qm[i],sorted=TRUE,beNA=TRUE))
  }
  names(qtmall_exp)<-names(CDF_tmSWAall)
  
  qskewall_exp <- t(outer(as.numeric(qtmall_exp), as.numeric(qvarall_exp), FUN =kurtfunction))

  
  #Weibull_qm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  qskewall <- matrix(nrow = 17, ncol = 10)
  
  for (i in 1:17) {
    for (j in 1:10) {
      skew1<-3.68267203509023
      
      skew1qm<-function(skew1,beNA){
        if(is.na(skew1)){
          return(NA)
        }
        d_qvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=50+i*2)
        
        d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=84+j*2)
        
        qvarall<-mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        
        qtmall<-mmmprocessqm(x=dp3tmx,percentage=721/4096,pc1=CDF_tmSWAall[j],dqm=d_qtm,sorted=TRUE,beNA=beNA)
        
        qtmall/(qvarall^(3/2))
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        skew2<-skew1qm(skew1,beNA=FALSE)
        
        if (is.na(skew2)||(abs(skew1-skew2))<criterion || (step1 == stepsize)){
          
          break
        }
        skew1<-skew2
      }
      
      qskewall[i, j] <- skew1qm(skew1,beNA=TRUE)
    }
  }
  qskewall_Weibull<-qskewall
  
  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))
  
  allresults1_exp<-c(rfmall_exp=rfmall_exp,rvarall_exp=rvarall_exp,rkurtall_exp=rkurtall_exp,qfmall_exp=qfmall_exp,qvarall_exp=qvarall_exp,qkurtall_exp=qkurtall_exp,rtmall_exp=rtmall_exp,rskewall_exp=rskewall_exp,qtmall_exp=qtmall_exp,qskewall_exp=qskewall_exp)
  allresults1_Weibull<-c(rkurtall_Weibull=rkurtall_Weibull,qkurtall_Weibull=qkurtall_Weibull,rskewall_Weibull=rskewall_Weibull,qskewall_Weibull=qskewall_Weibull)
  if(releaseall){
    finallall<-c(SWA_mean=SWA_mean,
                 SWAHLM_mean=SWAHLM_mean,
                 CDF_SWA_mean=CDF_SWA_mean,
                 CDF_SWAHLM_mean=CDF_SWAHLM_mean,
                 SWAvar=SWAvar,
                 SWAHLM_var=SWAHLM_var,
                 CDF_SWA_var=CDF_SWA_var,
                 CDF_SWAHLM_var=CDF_SWAHLM_var,
                 SWAtm=SWAtm,
                 SWAHLM_tm=SWAHLM_tm,
                 CDF_SWA_tm=CDF_SWA_tm,
                 CDF_SWAHLM_tm=CDF_SWAHLM_tm,
                 SWAfm=SWAfm,
                 SWAHLM_fm=SWAHLM_fm,
                 CDF_SWA_fm=CDF_SWA_fm,
                 CDF_SWAHLM_fm=CDF_SWAHLM_fm,
                 sdall=sdall)
    return(c(allresults1_Weibull,allresults1_exp,finallall))
  }else{
    return(c(allresults1_Weibull,allresults1_exp))
  }
}
rqmoments<-function (x,iall1=NULL,dtype1=1,releaseall=FALSE,standist_d=NULL,standist_I=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=1/16,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  if(is.null(standist_d)||is.null(standist_I)){
    data(d_values)
    data(I_values)
    standist_I<-I_values
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    
      if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
        data(quasiuni_2_104)
        data(quasiuni_3_104)
        data(quasiuni_4_104)
        largesize1<-2048*9
        
        orderlist1_sorted20<-createorderlist(quni1=quasiuni_sorted2,size=lengthx,interval=16,dimension=2)
        orderlist1_sorted20<-orderlist1_sorted20[1:largesize1,]
        orderlist1_sorted30<-createorderlist(quni1=quasiuni_sorted3,size=lengthx,interval=16,dimension=3)
        orderlist1_sorted30<-orderlist1_sorted30[1:largesize1,]
        orderlist1_sorted40<-createorderlist(quni1=quasiuni_sorted4,size=lengthx,interval=16,dimension=4)
        orderlist1_sorted40<-orderlist1_sorted40[1:largesize1,]
        
        orderlist1_sorted2<-createorderlist(quni1=quasiuni_sorted2,size=largesize1,interval=16,dimension=2)
        orderlist1_sorted2<-orderlist1_sorted2[1:largesize1,]
        orderlist1_sorted3<-createorderlist(quni1=quasiuni_sorted3,size=largesize1,interval=16,dimension=3)
        orderlist1_sorted3<-orderlist1_sorted3[1:largesize1,]
        orderlist1_sorted4<-createorderlist(quni1=quasiuni_sorted4,size=largesize1,interval=16,dimension=4)
        orderlist1_sorted4<-orderlist1_sorted4[1:largesize1,]
    }    
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)
    
    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample3<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    
    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample4<-c()
    
  }
  
  ikurtselect_Weibull<-iall1[1:238]
  iskewselect_Weibull<-iall1[239:578]
  
  #Weibull
  
  ikurt1<-26
  
  iskew1<-3.68
  
  IkurtI_values<-standist_I[,c(1:4,5:242)]
  IskewI_values<-standist_I[,c(1:4,243:582)]
  
  Kappa1_SE<-function(kurt1){
    
    Ikurt1<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=IkurtI_values)
    
    if(is.null(dim(Ikurt1))){
      na_cols <- which(is.na(ikurtselect_Weibull))
      Ikurt1$I1[5:242][na_cols]<-NA
      Ikurt1$I2[5:242][na_cols]<-NA
      ikurt11<-ikurtselect_Weibull[which.min(Ikurt1$I1[5:242])]
      ikurt12<-ikurtselect_Weibull[which.min(Ikurt1$I2[5:242])]
      if(ikurt11==ikurt12){
        ikurt110<-ikurt12
      }else{
      ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
      }
    }else{
      na_cols <- which(is.na(ikurtselect_Weibull))
      Ikurt1[5:242][na_cols]<-NA
      ikurt110<-ikurtselect_Weibull[which.min(Ikurt1[5:242])]
    }
    
    ikurt110
  }
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    ikurt2<-Kappa1_SE(ikurt1)
    
    if ((abs(ikurt1-ikurt2))<criterion || (step1 == stepsize)){
      
      break
    }
    ikurt1<-ikurt2
  }
  ikurt1<-as.numeric(ikurt1)
  Skew1_SE<-function(start_skew1){
    Iskew1<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew1,Ilist=IskewI_values)
    if(typeof(Iskew1)=="list"){
      na_cols <- which(is.na(iskewselect_Weibull))
      Iskew1$I1[5:344][na_cols]<-NA
      Iskew1$I2[5:344][na_cols]<-NA
      iskew11<-iskewselect_Weibull[which.min(Iskew1$I1[5:344])]
      iskew12<-iskewselect_Weibull[which.min(Iskew1$I2[5:344])]
      if(iskew11==iskew12){
        iskew110<-iskew12
      }else{
      iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
      }
    }else{
      na_cols <- which(is.na(iskewselect_Weibull))
      Iskew1[5:344][na_cols]<-NA
      iskew110<-iskewselect_Weibull[which.min(Iskew1[5:344])]
    }
    iskew110
  }
  
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    iskew2<-Skew1_SE(iskew1)
    
    if ((abs(iskew1-iskew2))<criterion || (step1 == stepsize)){
      
      break
    }
    iskew1<-iskew2
  }
  iskew1<-as.numeric(iskew1)
  #Weibull_rm
  SWA_mean=iall1[1225:1232]
  SWAHLM_mean=iall1[1233:1252]
  CDF_SWA_mean=iall1[1253:1258]
  CDF_SWAHLM_mean=iall1[1259:1275]
  SWAvar=iall1[1276:1283]
  SWAHLM_var=iall1[1284:1297]
  CDF_SWA_var=iall1[1298:1303]
  CDF_SWAHLM_var=iall1[1304:1314]
  SWAtm=iall1[1315:1320]
  SWAHLM_tm=iall1[1321:1328]
  CDF_SWA_tm=iall1[1329:1332]
  CDF_SWAHLM_tm=iall1[1333:1338]
  SWAfm=iall1[1339:1344]
  SWAHLM_fm=iall1[1345:1348]
  CDF_SWA_fm=iall1[1349:1352]
  CDF_SWAHLM_fm=iall1[1353:1355]
  
  meanSWAall<-unlist(c(SWA_mean[2:7],SWAHLM_mean[c(2:8,10:14,16:20)]))
  
  rmall<-c()
  for (i in 1:23) {
    d_rm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=4+i*2-1)
    rmall<-c(rmall,d_rm*meanSWAall[i]+meanSWAall[i]-d_rm*SWA_mean[8])
    
  }
  names(rmall)<-names(meanSWAall)
  #Weibull_qm
  mean_CDF_SWAall<-unlist(c(CDF_SWA_mean,CDF_SWAHLM_mean))
  
  qmall<-c()
  for (i in 1:23) {
    d_qm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=4+i*2)
    qmall<-c(qmall,mmmprocessqm(x=sortedx,percentage=1/16,pc1=mean_CDF_SWAall[i],dqm=d_qm,sorted=TRUE,beNA=TRUE))
    
  }
  names(qmall)<-names(mean_CDF_SWAall)
  
  #Weibull_rvar
  
  varSWAall<-unlist(c(SWAvar[2:7],SWAHLM_var[2:6],SWAHLM_var[8:10],SWAHLM_var[12:14]))
  
  rvarall<-c()
  for (i in 1:17) {
    d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=50+i*2-1)
    rvarall<-c(rvarall,d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[8])
    
  }
  names(rvarall)<-names(varSWAall)
  
  #Weibull_qvar
  
  CDF_varSWAall<-unlist(c(CDF_SWA_var,CDF_SWAHLM_var))
  
  qvarall<-c()
  for(i in (1:17)){
    d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=50+i*2)
    qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=TRUE))
  }
  names(qvarall)<-names(CDF_varSWAall)
  
  #Weibull_rtm
  
  tmSWAall<-unlist(c(SWAtm[2:5],SWAHLM_tm[2:4],SWAHLM_tm[6:8]))
  
  rtmall<-c()
  for (i in 1:10) {
    d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=84+i*2-1)
    rtmall<-c(rtmall,d_rtm*tmSWAall[i]+tmSWAall[i]-d_rtm*SWAtm[6])
    
  }
  names(rtmall)<-names(tmSWAall)
  #Weibull_qtm
  CDF_tmSWAall<-unlist(c(CDF_SWA_tm,CDF_SWAHLM_tm))
  
  qtmall<-c()
  for (i in 1:10) {
    d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=84+i*2)
    qtmall<-c(qtmall,mmmprocessqm(x=dp3tmx,percentage=721/4096,pc1=CDF_tmSWAall[i],dqm=d_qtm,sorted=TRUE,beNA=TRUE))
    
  }
  names(qtmall)<-names(CDF_tmSWAall)
  
  
  #Weibull_rfm
  
  fmSWAall<-unlist(c(SWAfm[2:5],SWAHLM_fm[2:4]))
  
  rfmall<-c()
  for (i in 1:7) {
    d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=104+i*2-1)
    rfmall<-c(rfmall,d_rfm*fmSWAall[i]+fmSWAall[i]-d_rfm*SWAfm[6])
    
  }
  names(rfmall)<-names(fmSWAall)
  
  
  #Weibull_qfm
  
  CDF_fmSWAall<-unlist(c(CDF_SWA_fm,CDF_SWAHLM_fm))
  
  qfmall<-c()
  for(i in (1:7)){
    d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=104+i*2)
    qfmall<-c(qfmall,mmmprocessqm(x=dp4fmx,percentage=14911/65536,pc1=CDF_fmSWAall[i],dqm=d_qfm,sorted=TRUE,beNA=TRUE))
  }
  names(qfmall)<-names(CDF_fmSWAall)
  
  imomentsall<-c(rmall=rmall,
                 qmall=qmall,
                 
                 rvarall=rvarall,
                 qvarall=qvarall,
                 
                 rtmall=rtmall,
                 qtmall=qtmall,
                 
                 rfmall=rfmall,
                 qfmall=qfmall)
  return(unlist(c(unlist(imomentsall),ikurt=ikurt1,iskew=iskew1)))
}


  

imoments<-function (x,dtype1=1,releaseall=FALSE,standist_d=NULL,standist_I=NULL,standist_Imoments=NULL,orderlist1_sorted20=NULL,orderlist1_sorted30=NULL,orderlist1_sorted40=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,percentage=1/16,batch="auto",stepsize=1000,criterion=1e-10,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  
  lengthx<-length(sortedx)
  if(is.null(standist_d)||is.null(standist_I)||is.null(standist_Imoments)){
    data(d_values)
    data(I_values)
    data(Imoments_values)
    standist_Imoments<-Imoments_values
    standist_I<-I_values
    standist_d<-d_values
  }
  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      largesize1<-2048*9
      
      orderlist1_sorted20<-createorderlist(quni1=quasiuni_sorted2,size=lengthx,interval=16,dimension=2)
      orderlist1_sorted20<-orderlist1_sorted20[1:largesize1,]
      orderlist1_sorted30<-createorderlist(quni1=quasiuni_sorted3,size=lengthx,interval=16,dimension=3)
      orderlist1_sorted30<-orderlist1_sorted30[1:largesize1,]
      orderlist1_sorted40<-createorderlist(quni1=quasiuni_sorted4,size=lengthx,interval=16,dimension=4)
      orderlist1_sorted40<-orderlist1_sorted40[1:largesize1,]
      
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_sorted2,size=largesize1,interval=16,dimension=2)
      orderlist1_sorted2<-orderlist1_sorted2[1:largesize1,]
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_sorted3,size=largesize1,interval=16,dimension=3)
      orderlist1_sorted3<-orderlist1_sorted3[1:largesize1,]
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_sorted4,size=largesize1,interval=16,dimension=4)
      orderlist1_sorted4<-orderlist1_sorted4[1:largesize1,]
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted20,sortedx=sortedx,dimension=2)
    
    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample2<-c()
    
    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted30,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample3<-c()
    
    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted40,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))
    
    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample2<-c()
    
    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))
    
    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample3<-c()
    
    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))
    
    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    
    combinationsample4<-c()
    
  }
  SWA_mean<-SWA(x=sortedx,percentage=1/16,blocknumber=16,batch="auto",sorted=TRUE)
  SWAHLM_mean<-SWAHLM_16(x=sortedx,orderlist1_sorted2=orderlist1_sorted20,orderlist1_sorted3=orderlist1_sorted30,orderlist1_sorted4=orderlist1_sorted40,percentage=1/16,batch="auto",boot=TRUE)
  
  CDF_SWA_mean <- sapply(SWA_mean[2:7], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_mean) <- paste0("pc_mean", names(SWA_mean)[2:7])
  
  CDF_SWAHLM_mean <- sapply(SWAHLM_mean[c(2:8,10:14,16:20)], function(val) CDF(x = sortedx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_mean) <- paste0("pc_mean", names(SWAHLM_mean)[c(2:8,10:14,16:20)])
  
  SWAvar<-SWA(x=dp2varx,percentage=31/256,blocknumber=9,batch="auto",sorted=TRUE)
  SWAHLM_var<-SWAHLM_31256(x=dp2varx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=31/256,batch="auto",boot=TRUE)
  
  CDF_SWA_var <- sapply(SWAvar[2:7], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_var) <- paste0("pc_var", names(SWAvar)[2:7])
  
  CDF_SWAHLM_var <- sapply(SWAHLM_var[c(2:6,8:10,12:14)], function(val) CDF(x = dp2varx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_var) <- paste0("pc_var", names(SWAHLM_var)[c(2:6,8:10,12:14)])
  
  SWAtm<-SWA(x=dp3tmx,percentage=721/4096,blocknumber=5,batch="auto",sorted=TRUE)
  
  SWAHLM_tm<-SWAHLM_741(x=dp3tmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=721/4096,batch="auto",boot=TRUE)
  
  CDF_SWA_tm <- sapply(SWAtm[2:5], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_tm) <- paste0("pc_tm", names(SWAtm)[2:5])
  
  CDF_SWAHLM_tm <- sapply(SWAHLM_tm[c(2:4,6:8)], function(val) CDF(x = dp3tmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_tm) <- paste0("pc_tm", names(SWAHLM_tm)[c(2:4,6:8)])
  
  SWAfm<-SWA(x=dp4fmx,percentage=14911/65536,blocknumber=5,batch=2,sorted=TRUE)
  SWAHLM_fm<-SWAHLM_312(x=dp4fmx,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,percentage=14911/65536,batch="auto",boot=TRUE)
  
  CDF_SWA_fm <- sapply(SWAfm[2:5], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWA_fm) <- paste0("pc_fm", names(SWAfm)[2:5])
  
  CDF_SWAHLM_fm <- sapply(SWAHLM_fm[c(2:4)], function(val) CDF(x = dp4fmx, xevaluated = val, sorted = TRUE))
  names(CDF_SWAHLM_fm) <- paste0("pc_fm", names(SWAHLM_fm)[c(2:4)])
  
  #exp_rm
  start_kurt=9
  start_skew=2
  
  allds_start<-d_kurt_list(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d)
  
  var_fm_ds_start<-cbind(allds_start[51:84],allds_start[105:118])
  
  var_fm_ds_rm<-var_fm_ds_start[seq(from=1, to=48, by=2)]
  
  varSWAall<-c(SWAvar[2:7],SWAHLM_var[2:6],SWAHLM_var[8:10],SWAHLM_var[12:14])
  
  rvarall_exp<-var_fm_ds_rm[1:17]*varSWAall+varSWAall-var_fm_ds_rm[1:17]*SWAvar[8]
  
  fmSWAall<-c(SWAfm[2:5],SWAHLM_fm[2:4])
  
  rfmall_exp<-var_fm_ds_rm[18:24]*fmSWAall+fmSWAall-var_fm_ds_rm[18:24]*SWAfm[6]
  kurtfunction<- function(x, y) {
    return(x /(y^2))
  }
  rkurtall_exp <- t(outer(as.numeric(rfmall_exp), as.numeric(rvarall_exp), FUN =kurtfunction))
  
  #Weibull_rm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  rkurtall <- matrix(nrow = 17, ncol = 7)
  
  for (i in 1:17) {
    for (j in 1:7) {
      kurt1<-26

      Kappa1rm<-function(kurt1){
        d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=50+i*2-1)
        
        d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=104+j*2-1)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[8]
        
        rfmall<-d_rfm*fmSWAall[j]+fmSWAall[j]-d_rfm*SWAfm[6]
        
        rfmall/(rvarall^2)
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        kurt2<-Kappa1rm(kurt1)
        
        if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){
          
          break
        }
        kurt1<-kurt2
      }
      rkurtall[i, j] <- kurt1
    }
  }
  rkurtall_Weibull<-rkurtall
  
  #exp_qm
  start_kurt=9
  start_skew=2
  
  var_fm_ds_qm<-var_fm_ds_start[seq(from=2, to=48, by=2)]
  
  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWAHLM_var)
  
  qvarall_exp<-c()
  for(i in (1:17)){
    qvarall_exp<-c(qvarall_exp,mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=var_fm_ds_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qvarall_exp)<-names(CDF_varSWAall)
  qvarall_exp<-unlist(qvarall_exp)
  CDF_fmSWAall<-c(CDF_SWA_fm,CDF_SWAHLM_fm)
  
  qfmall_exp<-c()
  for(i in (1:7)){
    qfmall_exp<-c(qfmall_exp,mmmprocessqm(x=dp4fmx,percentage=14911/65536,pc1=CDF_fmSWAall[i],dqm=var_fm_ds_qm[17+i],sorted=TRUE,beNA=FALSE))
  }
  names(qfmall_exp)<-names(CDF_fmSWAall)
  
  qkurtall_exp <- t(outer(as.numeric(qfmall_exp), as.numeric(qvarall_exp), FUN =kurtfunction))
  
  #Weibull_qm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  qkurtall <- matrix(nrow = 17, ncol = 7)
  
  for (i in 1:17) {
    for (j in 1:7) {
      kurt1<-26
      
      Kappa1qm<-function(kurt1,beNA){
        if(is.na(kurt1)){
          return(NA)
        }
        d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=50+i*2)
        
        d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=104+j*2)
        
        qvarall<-mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        
        qfmall<-mmmprocessqm(x=dp4fmx,percentage=14911/65536,pc1=CDF_fmSWAall[j],dqm=d_qfm,sorted=TRUE,beNA=beNA)
        
        qfmall/(qvarall^2)
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        kurt2<-Kappa1qm(kurt1,beNA=FALSE)
        
        if (is.na(kurt2)||(abs(kurt1-kurt2))<criterion || (step1 == stepsize)){
          
          break
        }
        kurt1<-kurt2
      }
      
      qkurtall[i, j] <- Kappa1qm(kurt1,beNA=TRUE)
    }
  }
  qkurtall_Weibull<-qkurtall
  
  #exp_rm
  start_skew=2
  
  tm_ds_all<-c(allds_start[85:104])
  tm_ds_rm<-unlist(tm_ds_all[seq(from=1, to=20, by=2)])
  
  tmSWAall<-c(SWAtm[2:5],SWAHLM_tm[2:4],SWAHLM_tm[6:8])
  
  rtmall_exp<-tm_ds_rm[1:10]*tmSWAall+tmSWAall-tm_ds_rm[1:10]*SWAtm[6]
  skewfunction<- function(x, y) {
    return(x /(y^(3/2)))
  }
  rskewall_exp <- t(outer(as.numeric(rtmall_exp), as.numeric(rvarall_exp), FUN =skewfunction))
  
  #Weibull_rm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  rskewall <- matrix(nrow = 17, ncol = 10)
  
  for (i in 1:17) {
    for (j in 1:10) {
      skew1<-3.68267203509023
      
      skew1rm<-function(skew1){
        d_rvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=50+i*2-1)
        
        d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=84+j*2-1)
        
        rvarall<-d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[8]
        
        rtmall<-d_rtm*tmSWAall[j]+tmSWAall[j]-d_rtm*SWAtm[6]
        
        rtmall/(rvarall^(3/2))
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        skew2<-skew1rm(skew1)
        
        if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){
          
          break
        }
        skew1<-skew2
      }
      rskewall[i, j] <- skew1
    }
  }
  rskewall_Weibull<-rskewall
  
  #exp_qm
  start_kurt=9
  start_skew=2
  
  var_fm_ds_qm<-var_fm_ds_start[seq(from=2, to=48, by=2)]
  
  CDF_varSWAall<-c(CDF_SWA_var,CDF_SWAHLM_var)
  
  qvarall_exp<-c()
  for(i in (1:17)){
    qvarall_exp<-c(qvarall_exp,mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=var_fm_ds_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qvarall_exp)<-names(CDF_varSWAall)
  
  tm_ds_qm<-unlist(tm_ds_all[seq(from=2, to=20, by=2)])
  CDF_tmSWAall<-c(CDF_SWA_tm,CDF_SWAHLM_tm)
  
  qtmall_exp<-c()
  for(i in (1:10)){
    qtmall_exp<-c(qtmall_exp,mmmprocessqm(x=dp3tmx,percentage=721/4096,pc1=CDF_tmSWAall[i],dqm=tm_ds_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qtmall_exp)<-names(CDF_tmSWAall)
  
  qskewall_exp <- t(outer(as.numeric(qtmall_exp), as.numeric(qvarall_exp), FUN =kurtfunction))
  
  
  #Weibull_qm
  kurt1<-26
  
  skew1<-3.68267203509023
  
  qskewall <- matrix(nrow = 17, ncol = 10)
  
  for (i in 1:17) {
    for (j in 1:10) {
      skew1<-3.68267203509023
      
      skew1qm<-function(skew1,beNA){
        if(is.na(skew1)){
          return(NA)
        }
        d_qvar<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=50+i*2)
        
        d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=84+j*2)
        
        qvarall<-mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=beNA)
        
        qtmall<-mmmprocessqm(x=dp3tmx,percentage=721/4096,pc1=CDF_tmSWAall[j],dqm=d_qtm,sorted=TRUE,beNA=beNA)
        
        qtmall/(qvarall^(3/2))
      }
      step1 <- 0
      
      repeat {
        step1 <-step1 + 1
        
        skew2<-skew1qm(skew1,beNA=FALSE)
        
        if (is.na(skew2)||(abs(skew1-skew2))<criterion || (step1 == stepsize)){
          
          break
        }
        skew1<-skew2
      }
      
      qskewall[i, j] <- skew1qm(skew1,beNA=TRUE)
    }
  }
  qskewall_Weibull<-qskewall
  
  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))
  
  
  start_kurt=9
  start_skew=2
  
  alldsmean_start<-d_kurt_list(size=lengthx,dtype=1,kurt1=start_kurt,dlist=standist_d)
  
  meand1<-cbind(allds_start[5:50])
  
  meand1_rm<-meand1[seq(from=1, to=46, by=2)]
  
  meanSWAall<-c(SWA_mean[2:7],SWAHLM_mean[2:8],SWAHLM_mean[10:14],SWAHLM_mean[16:20])
  
  rmall_exp<-meand1_rm*meanSWAall+meanSWAall-meand1_rm*SWA_mean[8]
  
  start_kurt=9
  start_skew=2
  
  meand1_qm<-meand1[seq(from=2, to=46, by=2)]
  
  CDF_meanSWAall<-c(CDF_SWA_mean,CDF_SWAHLM_mean)
  
  qmall_exp<-c()
  for(i in (1:23)){
    qmall_exp<-c(qmall_exp,mmmprocessqm(x=sortedx,percentage=1/16,pc1=CDF_meanSWAall[i],dqm=meand1_qm[i],sorted=TRUE,beNA=FALSE))
  }
  names(qmall_exp)<-names(CDF_meanSWAall)
  qmall_exp<-unlist(qmall_exp)
  
  allresults1_exp<-c(rmall_exp=rmall_exp,qmall_exp=qmall_exp,rvarall_exp=rvarall_exp,qvarall_exp=qvarall_exp,rtmall_exp=rtmall_exp,qtmall_exp=qtmall_exp,rfmall_exp=rfmall_exp,qfmall_exp=qfmall_exp,rskewall_exp=rskewall_exp,qskewall_exp=qskewall_exp,rkurtall_exp=rkurtall_exp,qkurtall_exp=qkurtall_exp)
  allresults1_exp<-unlist(allresults1_exp)
  allresults1_Weibull<-c(rkurtall_Weibull=rkurtall_Weibull,qkurtall_Weibull=qkurtall_Weibull,rskewall_Weibull=rskewall_Weibull,qskewall_Weibull=qskewall_Weibull)
  
  
  ikurtselect_Weibull<-c(rkurtall_Weibull=rkurtall_Weibull,qkurtall_Weibull=qkurtall_Weibull)
  iskewselect_Weibull<-c(rskewall_Weibull=rskewall_Weibull,qskewall_Weibull=qskewall_Weibull)
  
  #Weibull
  
  ikurt1<-26
  
  iskew1<-3.68
  
  IkurtI_values<-(standist_I[,c(1:4,5:242)])
  IskewI_values<-standist_I[,c(1:4,243:582)]
  
  Kappa1_SE<-function(kurt1){
    
    Ikurt1<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=as.data.frame(IkurtI_values))
    
    if(is.null(dim(Ikurt1))){
      if(length(Ikurt1)==4){
      na_cols <- which(is.na(ikurtselect_Weibull))
      Ikurt1$I1[5:242][na_cols]<-NA
      Ikurt1$I2[5:242][na_cols]<-NA
      ikurt11<-ikurtselect_Weibull[which.min(Ikurt1$I1[5:242])]
      ikurt12<-ikurtselect_Weibull[which.min(Ikurt1$I2[5:242])]
      if(ikurt11==ikurt12){
        ikurt110<-ikurt12
      }else{
        ikurt110<-(((ikurt12-ikurt11)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt11)
      }
      }else{
        na_cols <- which(is.na(ikurtselect_Weibull))
        Ikurt1$I11[5:242][na_cols]<-NA
        Ikurt1$I21[5:242][na_cols]<-NA
        Ikurt1$I12[5:242][na_cols]<-NA
        Ikurt1$I22[5:242][na_cols]<-NA
        ikurt111<-ikurtselect_Weibull[which.min(Ikurt1$I11[5:242])]
        ikurt121<-ikurtselect_Weibull[which.min(Ikurt1$I21[5:242])]
        ikurt112<-ikurtselect_Weibull[which.min(Ikurt1$I12[5:242])]
        ikurt122<-ikurtselect_Weibull[which.min(Ikurt1$I22[5:242])]
        if(ikurt121==ikurt111){
          ikurt11a<-ikurt111
        }else{
          ikurt11a<-(((ikurt121-ikurt111)*((kurt1-Ikurt1$infn2)/(Ikurt1$supn2-Ikurt1$infn2)))+ikurt111)
        }
        if(ikurt122==ikurt112){
          ikurt11b<-ikurt112
        }else{
          ikurt11b<-(((ikurt122-ikurt112)*((kurt1-Ikurt1$infn3)/(Ikurt1$supn3-Ikurt1$infn3)))+ikurt112)
        }
        
        if(ikurt11a==ikurt11b){
          ikurt110<-ikurt11a
        }else{
          ikurt110<-(((ikurt11b-ikurt11a)*((kurt1-Ikurt1$infn)/(Ikurt1$supn-Ikurt1$infn)))+ikurt11b)
        }
      }
    }else{
      na_cols <- which(is.na(ikurtselect_Weibull))
      Ikurt1[5:242][na_cols]<-NA
      ikurt110<-ikurtselect_Weibull[which.min(Ikurt1[5:242])]
    }
    
    ikurt110
  }
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    ikurt2<-Kappa1_SE(ikurt1)
    
    if ((abs(ikurt1-ikurt2))<criterion || (step1 == stepsize)){
      
      break
    }
    ikurt1<-ikurt2
  }
  
  Skew1_SE<-function(start_skew1){
    Iskew1<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew1,Ilist=IskewI_values)
    if(typeof(Iskew1)=="list"){
      if(length(Iskew1)==4){
        na_cols <- which(is.na(iskewselect_Weibull))
        Iskew1$I1[5:344][na_cols]<-NA
        Iskew1$I2[5:344][na_cols]<-NA
        iskew11<-iskewselect_Weibull[which.min(Iskew1$I1[5:344])]
        iskew12<-iskewselect_Weibull[which.min(Iskew1$I2[5:344])]
        if(iskew11==iskew12){
          iskew110<-iskew12
        }else{
          iskew110<-(((iskew12-iskew11)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew11)
        }
      }else{
        na_cols <- which(is.na(iskewselect_Weibull))
        Iskew1$I11[5:344][na_cols]<-NA
        Iskew1$I21[5:344][na_cols]<-NA
        Iskew1$I12[5:344][na_cols]<-NA
        Iskew1$I22[5:344][na_cols]<-NA
        
        iskew111<-iskewselect_Weibull[which.min(Iskew1$I11[5:344])]
        iskew121<-iskewselect_Weibull[which.min(Iskew1$I21[5:344])]
        iskew112<-iskewselect_Weibull[which.min(Iskew1$I12[5:344])]
        iskew122<-iskewselect_Weibull[which.min(Iskew1$I22[5:344])]
        if(iskew121==iskew111){
          iskew11a<-iskew111
        }else{
          iskew11a<-(((iskew121-iskew111)*((start_skew1-Iskew1$infn2)/(Iskew1$supn2-Iskew1$infn2)))+iskew111)
        }
        if(iskew122==iskew112){
          iskew11b<-iskew112
        }else{
          iskew11b<-(((iskew122-iskew112)*((start_skew1-Iskew1$infn3)/(Iskew1$supn3-Iskew1$infn3)))+iskew112)
        }
        
        if(iskew11a==iskew11b){
          iskew110<-iskew11a
        }else{
          iskew110<-(((iskew11b-iskew11a)*((start_skew1-Iskew1$infn)/(Iskew1$supn-Iskew1$infn)))+iskew11b)
        }
      }
      
    }else{
      na_cols <- which(is.na(iskewselect_Weibull))
      Iskew1[5:344][na_cols]<-NA
      iskew110<-iskewselect_Weibull[which.min(Iskew1[5:344])]
    }
    iskew110
  }
  
  
  step1 <- 0
  
  repeat {
    step1 <-step1 + 1
    
    iskew2<-Skew1_SE(iskew1)
    
    if ((abs(iskew1-iskew2))<criterion || (step1 == stepsize)){
      
      break
    }
    iskew1<-iskew2
  }
  
  #Weibull_rm
  
  meanSWAall<-unlist(c(SWA_mean[2:7],SWAHLM_mean[c(2:8,10:14,16:20)]))
  
  rmall<-c()
  for (i in 1:23) {
    d_rm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=4+i*2-1)
    rmall<-c(rmall,d_rm*meanSWAall[i]+meanSWAall[i]-d_rm*SWA_mean[8])
  }
  names(rmall)<-names(meanSWAall)
  #Weibull_qm
  mean_CDF_SWAall<-unlist(c(CDF_SWA_mean,CDF_SWAHLM_mean))
  
  qmall<-c()
  for (i in 1:23) {
    d_qm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=4+i*2)
    qmall<-c(qmall,mmmprocessqm(x=sortedx,percentage=1/16,pc1=mean_CDF_SWAall[i],dqm=d_qm,sorted=TRUE,beNA=TRUE))
  }
  names(qmall)<-names(mean_CDF_SWAall)
  
  #Weibull_rvar
  
  varSWAall<-unlist(c(SWAvar[2:7],SWAHLM_var[2:6],SWAHLM_var[8:10],SWAHLM_var[12:14]))
  
  rvarall<-c()
  for (i in 1:17) {
    d_rvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=50+i*2-1)
    rvarall<-c(rvarall,d_rvar*varSWAall[i]+varSWAall[i]-d_rvar*SWAvar[8])
  }
  names(rvarall)<-names(varSWAall)
  
  #Weibull_qvar
  
  CDF_varSWAall<-unlist(c(CDF_SWA_var,CDF_SWAHLM_var))
  
  qvarall<-c()
  for(i in (1:17)){
    d_qvar<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=50+i*2)
    qvarall<-c(qvarall,mmmprocessqm(x=dp2varx,percentage=31/256,pc1=CDF_varSWAall[i],dqm=d_qvar,sorted=TRUE,beNA=TRUE))
  }
  names(qvarall)<-names(CDF_varSWAall)
  
  #Weibull_rtm
  
  tmSWAall<-unlist(c(SWAtm[2:5],SWAHLM_tm[2:4],SWAHLM_tm[6:8]))
  
  rtmall<-c()
  for (i in 1:10) {
    d_rtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=84+i*2-1)
    rtmall<-c(rtmall,d_rtm*tmSWAall[i]+tmSWAall[i]-d_rtm*SWAtm[6])
  }
  names(rtmall)<-names(tmSWAall)
  #Weibull_qtm
  CDF_tmSWAall<-unlist(c(CDF_SWA_tm,CDF_SWAHLM_tm))
  
  qtmall<-c()
  for (i in 1:10) {
    d_qtm<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,dlist=standist_d,etype=84+i*2)
    qtmall<-c(qtmall,mmmprocessqm(x=dp3tmx,percentage=721/4096,pc1=CDF_tmSWAall[i],dqm=d_qtm,sorted=TRUE,beNA=TRUE))
  }
  names(qtmall)<-names(CDF_tmSWAall)
  
  
  #Weibull_rfm
  
  fmSWAall<-unlist(c(SWAfm[2:5],SWAHLM_fm[2:4]))
  
  rfmall<-c()
  for (i in 1:7) {
    d_rfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=104+i*2-1)
    rfmall<-c(rfmall,d_rfm*fmSWAall[i]+fmSWAall[i]-d_rfm*SWAfm[6])
  }
  names(rfmall)<-names(fmSWAall)
  
  
  #Weibull_qfm
  
  CDF_fmSWAall<-unlist(c(CDF_SWA_fm,CDF_SWAHLM_fm))
  
  qfmall<-c()
  for(i in (1:7)){
    d_qfm<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,dlist=standist_d,etype=104+i*2)
    qfmall<-c(qfmall,mmmprocessqm(x=dp4fmx,percentage=14911/65536,pc1=CDF_fmSWAall[i],dqm=d_qfm,sorted=TRUE,beNA=TRUE))
  }
  names(qfmall)<-names(CDF_fmSWAall)
  
  
  imeanselect1<-c(rmall=rmall,
                  qmall=qmall)
  ivarselect1<-c(rvarall=rvarall,
                 qvarall=qvarall)
  itmselect1<-c(rtmall=rtmall,
                qtmall=qtmall)
  ifmselect1<-c(rfmall=rfmall,
                qfmall=qfmall)
  
  ImeanImoments<-standist_Imoments[,c(1:4,5:50)]
  
  Imean1<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,Ilist=ImeanImoments)
  if(typeof(Imean1)=="list"){
    if(length(Imean1)==4){
      na_cols <- which(is.na(imeanselect1))
      Imean1$I1[5:46][na_cols]<-NA
      Imean1$I2[5:46][na_cols]<-NA
      imean11<-imeanselect1[which.min(Imean1$I1[5:46])]
      imean12<-imeanselect1[which.min(Imean1$I2[5:46])]
      if(imean11==imean12){
        imean110<-imean12
      }else{
        imean110<-(((imean12-imean11)*((iskew1-Imean1$infn2)/(Imean1$supn2-Imean1$infn2)))+imean11)
      }
    }else{
      na_cols <- which(is.na(imeanselect1))
      Imean1$I11[5:46][na_cols]<-NA
      Imean1$I21[5:46][na_cols]<-NA
      Imean1$I12[5:46][na_cols]<-NA
      Imean1$I22[5:46][na_cols]<-NA
      
      imean111<-imeanselect1[which.min(Imean1$I11[5:46])]
      imean121<-imeanselect1[which.min(Imean1$I21[5:46])]
      imean112<-imeanselect1[which.min(Imean1$I12[5:46])]
      imean122<-imeanselect1[which.min(Imean1$I22[5:46])]
      if(imean121==imean111){
        imean11a<-imean111
      }else{
        imean11a<-(((imean121-imean111)*((iskew1-Imean1$infn2)/(Imean1$supn2-Imean1$infn2)))+imean111)
      }
      if(imean122==imean112){
        imean11b<-imean112
      }else{
        imean11b<-(((imean122-imean112)*((iskew1-Imean1$infn3)/(Imean1$supn3-Imean1$infn3)))+imean112)
      }
      
      if(imean11a==imean11b){
        imean110<-imean11a
      }else{
        imean110<-(((imean11b-imean11a)*((iskew1-Imean1$infn)/(Imean1$supn-Imean1$infn)))+imean11b)
      }
    }
    
  }else{
    na_cols <- which(is.na(imeanselect1))
    Imean1[5:46][na_cols]<-NA
    imean110<-imeanselect1[which.min(Imean1[5:46])]
  }
  
  IvarImoments<-standist_Imoments[,c(1:4,51:84)]
  
  Ivar1<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,Ilist=IvarImoments)
  if(typeof(Ivar1)=="list"){
    if(length(Ivar1)==4){
      na_cols <- which(is.na(ivarselect1))
      Ivar1$I1[5:38][na_cols]<-NA
      Ivar1$I2[5:38][na_cols]<-NA
      ivar11<-ivarselect1[which.min(Ivar1$I1[5:38])]
      ivar12<-ivarselect1[which.min(Ivar1$I2[5:38])]
      if(ivar11==ivar12){
        ivar110<-ivar12
      }else{
        ivar110<-(((ivar12-ivar11)*((ikurt1-Ivar1$infn2)/(Ivar1$supn2-Ivar1$infn2)))+ivar11)
      }
    }else{
      na_cols <- which(is.na(ivarselect1))
      Ivar1$I11[5:38][na_cols]<-NA
      Ivar1$I21[5:38][na_cols]<-NA
      Ivar1$I12[5:38][na_cols]<-NA
      Ivar1$I22[5:38][na_cols]<-NA
      ivar111<-ivarselect1[which.min(Ivar1$I11[5:38])]
      ivar121<-ivarselect1[which.min(Ivar1$I21[5:38])]
      ivar112<-ivarselect1[which.min(Ivar1$I12[5:38])]
      ivar122<-ivarselect1[which.min(Ivar1$I22[5:38])]
      if(ivar121==ivar111){
        ivar11a<-ivar111
      }else{
        ivar11a<-(((ivar121-ivar111)*((ikurt1-Ivar1$infn2)/(Ivar1$supn2-Ivar1$infn2)))+ivar111)
      }
      if(ivar122==ivar112){
        ivar11b<-ivar112
      }else{
        ivar11b<-(((ivar122-ivar112)*((ikurt1-Ivar1$infn3)/(Ivar1$supn3-Ivar1$infn3)))+ivar112)
      }
      
      if(ivar11a==ivar11b){
        ivar110<-ivar11a
      }else{
        ivar110<-(((ivar11b-ivar11a)*((ikurt1-Ivar1$infn)/(Ivar1$supn-Ivar1$infn)))+ivar11b)
      }
    }
    
  }else{
    na_cols <- which(is.na(ivarselect1))
    Ivar1[5:38][na_cols]<-NA
    ivar110<-ivarselect1[which.min(Ivar1[5:38])]
  }
  
  
  ItmImoments<-standist_Imoments[,c(1:4,85:104)]
  
  Itm1<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=iskew1,Ilist=ItmImoments)
  if(typeof(Itm1)=="list"){
    if(length(Itm1)==4){
      na_cols <- which(is.na(itmselect1))
      Itm1$I1[5:24][na_cols]<-NA
      Itm1$I2[5:24][na_cols]<-NA
      itm11<-itmselect1[which.min(Itm1$I1[5:24])]
      itm12<-itmselect1[which.min(Itm1$I2[5:24])]
      if(itm11==itm12){
        itm110<-itm12
      }else{
        itm110<-(((itm12-itm11)*((iskew1-Itm1$infn2)/(Itm1$supn2-Itm1$infn2)))+itm11)
      }
    }else{
      na_cols <- which(is.na(itmselect1))
      Itm1$I11[5:24][na_cols]<-NA
      Itm1$I21[5:24][na_cols]<-NA
      Itm1$I12[5:24][na_cols]<-NA
      Itm1$I22[5:24][na_cols]<-NA
      
      itm111<-itmselect1[which.min(Itm1$I11[5:24])]
      itm121<-itmselect1[which.min(Itm1$I21[5:24])]
      itm112<-itmselect1[which.min(Itm1$I12[5:24])]
      itm122<-itmselect1[which.min(Itm1$I22[5:24])]
      if(itm111==itm121){
        itm1a<-itm111
      }else{
        itm1a<-(((itm121-itm111)*((iskew1-Itm1$infn2)/(Itm1$supn2-Itm1$infn2)))+itm111)
      }
      if(itm122==itm112){
        itm1b<-itm112
      }else{
        itm1b<-(((itm122-itm112)*((iskew1-Itm1$infn3)/(Itm1$supn3-Itm1$infn3)))+itm112)
      }
      
      if(itm1a==itm1b){
        itm110<-itm1a
      }else{
        itm110<-(((itm1b-itm1a)*((iskew1-Itm1$infn)/(Itm1$supn-Itm1$infn)))+itm1b)
      }
    }
    
  }else{
    na_cols <- which(is.na(itmselect1))
    Itm1[5:24][na_cols]<-NA
    itm110<-itmselect1[which.min(Itm1[5:24])]
  }
  
  IfmImoments<-standist_Imoments[,c(1:4,105:118)]
  
  Ifm1<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=ikurt1,Ilist=IfmImoments)
  if(typeof(Ifm1)=="list"){
    
    if(length(Ifm1)==4){
      na_cols <- which(is.na(ifmselect1))
      Ifm1$I1[5:18][na_cols]<-NA
      Ifm1$I2[5:18][na_cols]<-NA
      ifm11<-ifmselect1[which.min(Ifm1$I1[5:18])]
      ifm12<-ifmselect1[which.min(Ifm1$I2[5:18])]
      if(ifm11==ifm12){
        ifm110<-ifm12
      }else{
        ifm110<-(((ifm12-ifm11)*((ikurt1-Ifm1$infn2)/(Ifm1$supn2-Ifm1$infn2)))+ifm11)
      }
    }else{
      na_cols <- which(is.na(ifmselect1))
      Ifm1$I11[5:18][na_cols]<-NA
      Ifm1$I21[5:18][na_cols]<-NA
      Ifm1$I12[5:18][na_cols]<-NA
      Ifm1$I22[5:18][na_cols]<-NA
      ifm111<-ifmselect1[which.min(Ifm1$I11[5:18])]
      ifm121<-ifmselect1[which.min(Ifm1$I21[5:18])]
      ifm112<-ifmselect1[which.min(Ifm1$I12[5:18])]
      ifm122<-ifmselect1[which.min(Ifm1$I22[5:18])]
      if(ifm121==ifm111){
        ifm11a<-ifm111
      }else{
        ifm11a<-(((ifm121-ifm111)*((ikurt1-Ifm1$infn2)/(Ifm1$supn2-Ifm1$infn2)))+ifm111)
      }
      if(ifm122==ifm112){
        ifm11b<-ifm112
      }else{
        ifm11b<-(((ifm122-ifm112)*((ikurt1-Ifm1$infn3)/(Ifm1$supn3-Ifm1$infn3)))+ifm112)
      }
      
      if(ifm11a==ifm11b){
        ifm110<-ifm11a
      }else{
        ifm110<-(((ifm11b-ifm11a)*((ikurt1-Ifm1$infn)/(Ifm1$supn-Ifm1$infn)))+ifm11b)
      }
    }
    
  }else{
    na_cols <- which(is.na(ifmselect1))
    Ifm1[5:18][na_cols]<-NA
    ifm110<-ifmselect1[which.min(Ifm1[5:18])]
  }
  
  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))
  imomentsall<-c(imean1=imean110,ivar1=ivar110,itm1=itm110,ifm1=ifm110,iskew1=iskew1,ikurt1=ikurt1)
  
  if(releaseall){
    
    rqmomentsall<-c(rmall=rmall,
                    qmall=qmall,
                    rvarall=rvarall,
                    qvarall=qvarall,
                    rtmall=rtmall,
                    qtmall=qtmall,
                    rfmall=rfmall,
                    qfmall=qfmall)
    finallall<-c(rqmoments_exp=allresults1_exp,rqmoments_Weilbull=allresults1_Weibull,SWA_mean=SWA_mean,
                 SWAHLM_mean=SWAHLM_mean,
                 CDF_SWA_mean=CDF_SWA_mean,
                 CDF_SWAHLM_mean=CDF_SWAHLM_mean,
                 SWAvar=SWAvar,
                 SWAHLM_var=SWAHLM_var,
                 CDF_SWA_var=CDF_SWA_var,
                 CDF_SWAHLM_var=CDF_SWAHLM_var,
                 SWAtm=SWAtm,
                 SWAHLM_tm=SWAHLM_tm,
                 CDF_SWA_tm=CDF_SWA_tm,
                 CDF_SWAHLM_tm=CDF_SWAHLM_tm,
                 SWAfm=SWAfm,
                 SWAHLM_fm=SWAHLM_fm,
                 CDF_SWA_fm=CDF_SWA_fm,
                 CDF_SWAHLM_fm=CDF_SWAHLM_fm,
                 sdall=sdall)
    return(c(imomentsall,rqmomentsall,finallall))
  }else{
    return(c(imomentsall))
  }
}
