#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.



I_adjust_kurt<-function(size,dtype,kurt1,Ilist){
  Ilist<-Ilist[Ilist[,2] == dtype,]
  if(size%in% Ilist[,1]){
    if (kurt1%in% Ilist[Ilist[,1] == size,3]){
      result1<-Ilist[Ilist[,1] == size & Ilist[,3]==kurt1,]
    }else{
      rown2<-as.numeric(Ilist[Ilist$samplesize == size,3])
      infn2<-max(rown2[rown2 < kurt1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
      }
      supn2<-min(rown2[rown2 > kurt1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
      }
      I1<-Ilist[Ilist[,1]==size & Ilist[,3]==infn2,]
      I2<-Ilist[Ilist[,1]==size & Ilist[,3]==supn2,]
      result1<-list(I1=I1,I2=I2,infn2=infn2,supn2=supn2)
    }
  }else{
    rown<-as.numeric(Ilist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }

    rown2<-as.numeric(Ilist[Ilist[,1] == infn,3])
    infn2<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    I11<-Ilist[Ilist[,1]==infn & Ilist[,3]==infn2,]
    I21<-Ilist[Ilist[,1]==infn & Ilist[,3]==supn2,]

    da<-c(I11,I21,infn2,supn2)

    rown2<-as.numeric(Ilist[Ilist[,1] == supn,3])
    infn3<-max(rown2[rown2 < kurt1])
    if(is.infinite(infn3)){
      infn3<-min(rown2)
    }
    supn3<-min(rown2[rown2 > kurt1])
    if(is.infinite(supn3)){
      supn3<-max(rown2)
    }

    I12<-Ilist[Ilist[,1]==supn & Ilist[,3]==infn3,]
    I22<-Ilist[Ilist[,1]==supn & Ilist[,3]==supn3,]

    db<-c(I12,I22,infn3,supn3)

    result1<-list(I11=I11,I21=I21,I12=I12,I22=I22,infn2=infn2,supn2=supn2,infn3=infn3,supn3=supn3,infn=infn,supn=supn)
  }
  return(result1)
}

I_adjust_skew<-function(size,dtype,skew1,Ilist){
  skew1=abs(skew1)
  Ilist<-Ilist[Ilist[,2] == dtype,]
  if(size%in% Ilist[,1]){
    if (skew1%in% Ilist[Ilist[,1] == size,4]){
      result1<-Ilist[Ilist[,1] == size & Ilist[,4]==skew1,]
    }else{
      rown2<-as.numeric(Ilist[Ilist[,1] == size,4])
      infn2<-max(rown2[rown2 < skew1])
      if(is.infinite(infn2)){
        infn2<-min(rown2)
      }
      supn2<-min(rown2[rown2 > skew1])
      if(is.infinite(supn2)){
        supn2<-max(rown2)
      }
      I1<-Ilist[Ilist[,1]==size & Ilist[,4]==infn2,]
      I2<-Ilist[Ilist[,1]==size & Ilist[,4]==supn2,]
      result1<-list(I1=I1,I2=I2,infn2=infn2,supn2=supn2)
    }
  }else{
    rown<-as.numeric(Ilist[,1])
    infn<-max(rown[rown < size])
    if(is.infinite(infn)){
      infn<-min(rown)
    }
    supn<-min(rown[rown > size])
    if(is.infinite(supn)){
      supn<-max(rown)
    }

    rown2<-as.numeric(Ilist[Ilist[,1] == infn,4])
    infn2<-max(rown2[rown2 < skew1])
    if(is.infinite(infn2)){
      infn2<-min(rown2)
    }
    supn2<-min(rown2[rown2 > skew1])
    if(is.infinite(supn2)){
      supn2<-max(rown2)
    }

    I11<-Ilist[Ilist[,1]==infn & Ilist[,4]==infn2,]
    I21<-Ilist[Ilist[,1]==infn & Ilist[,4]==supn2,]
    
    da<-c(I11,I21,infn2,supn2)
    
    rown2<-as.numeric(Ilist[Ilist[,1] == supn,4])
    infn3<-max(rown2[rown2 < skew1])
    if(is.infinite(infn3)){
      infn3<-min(rown2)
    }
    supn3<-min(rown2[rown2 > skew1])
    if(is.infinite(supn3)){
      supn3<-max(rown2)
    }
    
    I12<-Ilist[Ilist[,1]==supn & Ilist[,4]==infn3,]
    I22<-Ilist[Ilist[,1]==supn & Ilist[,4]==supn3,]
    
    db<-c(I12,I22,infn3,supn3)
    
    result1<-list(I11=I11,I21=I21,I12=I12,I22=I22,infn2=infn2,supn2=supn2,infn3=infn3,supn3=supn3,infn=infn,supn=supn)
  }
  return(result1)
}
