#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.




I_adjust_kurt<-function(size,dtype,kurt1,Ilist){
  Ilist<-Ilist[Ilist[,2] == dtype,]
  if(size%in% Ilist[,1]){
    if (kurt1%in% Ilist[Ilist[,1] == size,3]){
      result1<-unlist(Ilist[Ilist[,1] == size & Ilist[,3]==kurt1,])
    }else{
      rown2<-as.numeric(Ilist[Ilist$samplesize == size,3])
      tryCatch({
        infn2 <- max(rown2[rown2 <= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
        message(custom_warning)
        infn2 <<- min(rown2)
      })
      tryCatch({
        supn2 <- min(rown2[rown2 >= kurt1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
        message(custom_warning)
        supn2 <<- max(rown2)
      })
      I1<-Ilist[Ilist[,1]==size & Ilist[,3]==infn2,]
      I2<-Ilist[Ilist[,1]==size & Ilist[,3]==supn2,]
      result1<-list(I1=I1,I2=I2,infn2=infn2,supn2=supn2)
    }
  }else{
    rown<-as.numeric(Ilist[,1])
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )

    rown2<-as.numeric(Ilist[Ilist[,1] == infn,3])
    tryCatch({
      infn2 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })

    tryCatch({
      supn2 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })

    I11<-Ilist[Ilist[,1]==infn & Ilist[,3]==infn2,]
    I21<-Ilist[Ilist[,1]==infn & Ilist[,3]==supn2,]

    da<-c(I11,I21,infn2,supn2)

    rown2<-as.numeric(Ilist[Ilist[,1] == supn,3])

    tryCatch({
      infn3 <- max(rown2[rown2 <= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too small (%f), out of range supported.", kurt1)
      message(custom_warning)
      infn3 <<- min(rown2)
    })

    tryCatch({
      supn3 <- min(rown2[rown2 >= kurt1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The kurtosis is too large (%f), out of range supported.", kurt1)
      message(custom_warning)
      supn3 <<- max(rown2)
    })

    I12<-Ilist[Ilist[,1]==supn & Ilist[,3]==infn3,]
    I22<-Ilist[Ilist[,1]==supn & Ilist[,3]==supn3,]

    db<-c(I12,I22,infn3,supn3)

    result1<-list(I11=I11,I21=I21,I12=I12,I22=I22,infn2=infn2,supn2=supn2,infn3=infn3,supn3=supn3,infn=infn,supn=supn)
  }
  return(result1)
}

I_adjust_skew<-function(size,dtype,skew1,Ilist){
  skew1=abs(skew1)
  Ilist<-Ilist[Ilist[,2] == dtype,]
  if(size%in% Ilist[,1]){
    if (skew1%in% Ilist[Ilist[,1] == size,4]){
      result1<-unlist(Ilist[Ilist[,1] == size & Ilist[,4]==skew1,])
    }else{
      rown2<-as.numeric(Ilist[Ilist[,1] == size,4])
      tryCatch({
        infn2 <- max(rown2[rown2 <= skew1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
        message(custom_warning)
        infn2 <<- min(rown2)
      })
      tryCatch({
        supn2 <- min(rown2[rown2 >= skew1])
      },
      warning = function(w) {
        custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
        message(custom_warning)
        supn2 <<- max(rown2)
      })
      I1<-Ilist[Ilist[,1]==size & Ilist[,4]==infn2,]
      I2<-Ilist[Ilist[,1]==size & Ilist[,4]==supn2,]
      result1<-list(I1=I1,I2=I2,infn2=infn2,supn2=supn2)
    }
  }else{
    rown<-as.numeric(Ilist[,1])
    tryCatch(
      {
        infn <- max(rown[rown <= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too small (%f), out of range supported.", size)
        message(custom_warning)
        infn <<- min(rown)
      }
    )
    tryCatch(
      {
        supn<-min(rown[rown >= size])
      },
      warning = function(w) {
        custom_warning <- sprintf("The sample size is too large (%f), out of range supported.", size)
        message(custom_warning)
        supn <<- max(rown)
      }
    )

    rown2<-as.numeric(Ilist[Ilist[,1] == infn,4])
    tryCatch({
      infn2 <- max(rown2[rown2 <= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
      message(custom_warning)
      infn2 <<- min(rown2)
    })
    tryCatch({
      supn2 <- min(rown2[rown2 >= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
      message(custom_warning)
      supn2 <<- max(rown2)
    })
    I11<-Ilist[Ilist[,1]==infn & Ilist[,4]==infn2,]
    I21<-Ilist[Ilist[,1]==infn & Ilist[,4]==supn2,]

    da<-c(I11,I21,infn2,supn2)

    rown2<-as.numeric(Ilist[Ilist[,1] == supn,4])
    tryCatch({
      infn3 <- max(rown2[rown2 <= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too small (%f), out of range supported.", skew1)
      message(custom_warning)
      infn3 <<- min(rown2)
    })
    tryCatch({
      supn3 <- min(rown2[rown2 >= skew1])
    },
    warning = function(w) {
      custom_warning <- sprintf("The skewness is too large (%f), out of range supported.", skew1)
      message(custom_warning)
      supn3 <<- max(rown2)
    })

    I12<-Ilist[Ilist[,1]==supn & Ilist[,4]==infn3,]
    I22<-Ilist[Ilist[,1]==supn & Ilist[,4]==supn3,]

    db<-c(I12,I22,infn3,supn3)

    result1<-list(I11=I11,I21=I21,I12=I12,I22=I22,infn2=infn2,supn2=supn2,infn3=infn3,supn3=supn3,infn=infn,supn=supn)
  }
  return(result1)
}

