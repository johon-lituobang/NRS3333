#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

mmmraw<-function(x,interval=8,batch="auto",sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  SWA1<-SWA(x=sortedx,interval=interval,batch=batch,sorted=TRUE)
  if(SWA1[2]==Inf){
    return(print("BM is infinity, due to the double precision floating point limits. Usually, the solution is transforming your original data."))
  }
  lengthx<-length(x)
  mx1BM38<-CDF(x=sortedx,xevaluated=SWA1[2],sorted=TRUE)
  mx1sqm8<-CDF(x=sortedx,xevaluated=SWA1[3],sorted=TRUE)
  mx1BM28<-CDF(x=sortedx,xevaluated=SWA1[4],sorted=TRUE)
  mx1wm8<-CDF(x=sortedx,xevaluated=SWA1[5],sorted=TRUE)
  mx1bwm8<-CDF(x=sortedx,xevaluated=SWA1[6],sorted=TRUE)
  mx1tm8<-CDF(x=sortedx,xevaluated=SWA1[7],sorted=TRUE)
  output1<-c(mean=SWA1[1],BM38=SWA1[2],sqm8=SWA1[3],BM28=SWA1[4],wm8=SWA1[5],bwm8=SWA1[6],tm8=SWA1[7],median1=SWA1[8],mx1BM38=mx1BM38,mx1sqm8=mx1sqm8,mx1BM28=mx1BM28,mx1wm8=mx1wm8,mx1bwm8=mx1bwm8,mx1tm8=mx1tm8)
  return(output1)
}

mmmprocessrm<-function(x,interval=8,SWA,median,mx1,drm=0.375){
  rm1<--drm*median+SWA+drm*SWA
  names(rm1)<-NULL
  output1<-c(rm=rm1)
  return(output1)
}

mmmprocessqm<-function(x,interval=8,SWA,median,mx1,dqm=0.567,sorted=TRUE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if (mx1==0.5){
    quatiletarget<-0.5
  }else if (mx1>0.5){
    quatiletarget<-mx1+(mx1-0.5)*dqm
  }else{
    mx1<-1-mx1
    quatiletarget<-mx1+(mx1-0.5)*dqm
    quatiletarget<-1-quatiletarget
  }
  upper1<-(1-1/interval)
  lower1<-1/interval
  if(quatiletarget>upper1){
    quatiletarget=upper1
  }else if(quatiletarget<lower1){
    quatiletarget=lower1
  }
  qm1<-quantilefunction(sortedx,quatiletarget,sorted=TRUE)
  output1<-c(qm=qm1)
  return(output1)
}


