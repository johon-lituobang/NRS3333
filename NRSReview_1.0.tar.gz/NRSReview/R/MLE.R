#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

mom<-function (x, bend = 1.172,medianx=NULL,madx=NULL) {
  indicator1<-(x>medianx+bend*madx)
  indicator2<-(x<medianx-bend*madx)
  indicator <- rep(TRUE,length(x))
  indicator[indicator1]<-FALSE
  indicator[indicator2]<-FALSE
  result <- mean(x[indicator])
  return(result)
}
HuberPsi<-function(x,bend=1.172){
  result<-ifelse(abs(x)<=bend,x,bend*sign(x))
  return(result)
}
onestep<-function (x, bend = 1.172) {
  medianx<-median(x)
  madx<-mad(x)
  firstloc = mom(x, bend = bend,medianx=medianx,madx=madx)
  indicator <- (x - firstloc)/mad(x,constant=1)
  result<-medianx + madx * (sum(HuberPsi(x=indicator, bend=bend)))/(length(x[abs(indicator) <= bend]))
  return(c(onestep=result))
}
Huber_estimator<-function (x, bend = 1.5, tol = 1e-20){
  n <- length(x)
  est1 <- median(x)
  mad1 <- mad(x)
  step1<-0
  repeat {
    step1<-step1+1
    x2 <-pmin(pmax(est1-bend*mad1,x),est1+bend*mad1)
    est2 <- mean(x2)
    if (abs(est1-est2) < tol||step1>100)
      break
    est1 <- est2
  }
  names(est1)<-"Huber M-estimator"
  return(est1)
}

Weibull_RMLE<-function(x,alpha1=0.6,alpha2=1){
  tryCatch({
  if(is.na(alpha1)){
    all2<-c(alpha=NA,lambda=NA)
    
    return(all2)
  }
  f.acc <- function(alpha){
    lambda1<-median(x)/((log(2))^(1/alpha))
    median((1-((x/lambda1)^alpha))*(log((x/lambda1)^alpha)))+0.51
  }
  xL<- alpha1
  xR <- alpha2
  eps <- 1e-6
  max_iter <- 100
  iter <- 1
  while ((abs(xL-xR) > eps) && (iter < max_iter)){
    xM <- (xL+xR)/2
    if (f.acc(xM)*f.acc(xR) < 0){
      xL <- xM
    }else{
      xR <- xM
    }
    iter <- iter +1
  }
  alpha<-xM
  lambda<-median(x)/((log(2))^(1/alpha))

  all2<-c(alpha=alpha,lambda=lambda)
  return(all2)
  },error = function(e) {
    cat("Error: ", conditionMessage(e), "\n")
    all2<-c(alpha=NA,lambda=NA)
    return(all2)
  })
}

Weibull_quantile_estimator<-function(x,alpha1=1/3,alpha2=2/3,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  alpha<-(log(-log(1-alpha2))-log(-log(1-alpha1)))/(log(quantilefunction(sortedx,alpha2,sorted = TRUE))-log(quantilefunction(sortedx,alpha1,sorted = TRUE)))

  lambda<-quantilefunction(sortedx,0.5,sorted=TRUE)/((-log(1-0.5))^(1/alpha))

  all2<-c(alpha=alpha,lambda=lambda)

  return(all2)
}

Weibull_median_MAD_estimator<-function(x){
  logx<-log(x)
  medlogx<-median(logx)
  alld1<-logx-medlogx
  sigma1<-1.3037*median(abs(alld1))
  mu1<-medlogx-sigma1*log(log(2))

  alpha<-1/sigma1
  lambda<-exp(mu1)

  all2<-c(alpha=alpha,lambda=lambda)

  return(all2)
}

Weibull_moments<-function(alpha,lambda){
  mean<-lambda*gamma(1 + 1/alpha)

  variance<--lambda^2*(gamma(1 + 1/alpha))^2 + lambda^2*gamma(1 + 2/alpha)

  thirdmoment<-2*(lambda^3)*(gamma(1 + 1/alpha))^3-3*((lambda)^3)*gamma(1 + 1/alpha)*gamma(1 + 2/alpha)+(lambda^3)*gamma(1+3/alpha)

  fourthmoment<--3*(lambda^4)*gamma(1 + 1/alpha)^4+6*(lambda^4)*((gamma(1 + 1/alpha))^2)*gamma(1 + 2/alpha)-4*(lambda^4)*(gamma(1 + 1/alpha))*(gamma(1+3/alpha))+(lambda^4)*(gamma(1+4/alpha))
  c(mean=mean,var=variance,tm=thirdmoment,fm=fourthmoment)
}
